﻿namespace MyShop
{
    partial class frmDataOfTovar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabInfo = new System.Windows.Forms.TabControl();
            this.tabName = new System.Windows.Forms.TabPage();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtNameTovar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabDescr = new System.Windows.Forms.TabPage();
            this.txtDescr = new System.Windows.Forms.TextBox();
            this.tabCeny = new System.Windows.Forms.TabPage();
            this.dgCeny = new System.Windows.Forms.DataGridView();
            this.iddocC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtovC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cena0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSaveSCODE = new System.Windows.Forms.Button();
            this.txtSCODE = new System.Windows.Forms.TextBox();
            this.lblSCODE = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postav = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iddoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idpost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCena = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCODE = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnViewDoc = new System.Windows.Forms.Button();
            this.btnAddBasket = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tabInfo.SuspendLayout();
            this.tabName.SuspendLayout();
            this.tabDescr.SuspendLayout();
            this.tabCeny.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCeny)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabInfo);
            this.groupBox1.Controls.Add(this.btnSaveSCODE);
            this.groupBox1.Controls.Add(this.txtSCODE);
            this.groupBox1.Controls.Add(this.lblSCODE);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.dg1);
            this.groupBox1.Controls.Add(this.lblCena);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lblKol);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblCODE);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(460, 449);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация о товаре:";
            // 
            // tabInfo
            // 
            this.tabInfo.Controls.Add(this.tabName);
            this.tabInfo.Controls.Add(this.tabDescr);
            this.tabInfo.Controls.Add(this.tabCeny);
            this.tabInfo.Location = new System.Drawing.Point(9, 34);
            this.tabInfo.Name = "tabInfo";
            this.tabInfo.SelectedIndex = 0;
            this.tabInfo.Size = new System.Drawing.Size(445, 128);
            this.tabInfo.TabIndex = 14;
            // 
            // tabName
            // 
            this.tabName.BackColor = System.Drawing.SystemColors.Window;
            this.tabName.Controls.Add(this.txtFullName);
            this.tabName.Controls.Add(this.txtNameTovar);
            this.tabName.Controls.Add(this.label2);
            this.tabName.Controls.Add(this.label6);
            this.tabName.Location = new System.Drawing.Point(4, 22);
            this.tabName.Name = "tabName";
            this.tabName.Padding = new System.Windows.Forms.Padding(3);
            this.tabName.Size = new System.Drawing.Size(437, 102);
            this.tabName.TabIndex = 0;
            this.tabName.Text = "Наименование";
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(64, 44);
            this.txtFullName.Multiline = true;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.ReadOnly = true;
            this.txtFullName.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFullName.Size = new System.Drawing.Size(363, 48);
            this.txtFullName.TabIndex = 15;
            // 
            // txtNameTovar
            // 
            this.txtNameTovar.Location = new System.Drawing.Point(64, 18);
            this.txtNameTovar.Name = "txtNameTovar";
            this.txtNameTovar.ReadOnly = true;
            this.txtNameTovar.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNameTovar.Size = new System.Drawing.Size(362, 20);
            this.txtNameTovar.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Краткое:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Полное:";
            // 
            // tabDescr
            // 
            this.tabDescr.BackColor = System.Drawing.SystemColors.Window;
            this.tabDescr.Controls.Add(this.txtDescr);
            this.tabDescr.Location = new System.Drawing.Point(4, 22);
            this.tabDescr.Name = "tabDescr";
            this.tabDescr.Padding = new System.Windows.Forms.Padding(3);
            this.tabDescr.Size = new System.Drawing.Size(437, 102);
            this.tabDescr.TabIndex = 1;
            this.tabDescr.Text = "Описание";
            // 
            // txtDescr
            // 
            this.txtDescr.Location = new System.Drawing.Point(6, 6);
            this.txtDescr.Multiline = true;
            this.txtDescr.Name = "txtDescr";
            this.txtDescr.ReadOnly = true;
            this.txtDescr.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescr.Size = new System.Drawing.Size(425, 90);
            this.txtDescr.TabIndex = 0;
            // 
            // tabCeny
            // 
            this.tabCeny.Controls.Add(this.dgCeny);
            this.tabCeny.Location = new System.Drawing.Point(4, 22);
            this.tabCeny.Name = "tabCeny";
            this.tabCeny.Padding = new System.Windows.Forms.Padding(3);
            this.tabCeny.Size = new System.Drawing.Size(437, 102);
            this.tabCeny.TabIndex = 2;
            this.tabCeny.Text = "Цены";
            this.tabCeny.UseVisualStyleBackColor = true;
            // 
            // dgCeny
            // 
            this.dgCeny.AllowUserToAddRows = false;
            this.dgCeny.AllowUserToDeleteRows = false;
            this.dgCeny.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgCeny.ColumnHeadersHeight = 20;
            this.dgCeny.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iddocC,
            this.idtovC,
            this.DataC,
            this.Cena0,
            this.CenaR});
            this.dgCeny.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgCeny.Location = new System.Drawing.Point(3, 3);
            this.dgCeny.MultiSelect = false;
            this.dgCeny.Name = "dgCeny";
            this.dgCeny.ReadOnly = true;
            this.dgCeny.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgCeny.Size = new System.Drawing.Size(431, 96);
            this.dgCeny.TabIndex = 0;
            // 
            // iddocC
            // 
            this.iddocC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.iddocC.DataPropertyName = "iddoc";
            this.iddocC.HeaderText = "iddocC";
            this.iddocC.Name = "iddocC";
            this.iddocC.ReadOnly = true;
            this.iddocC.Visible = false;
            // 
            // idtovC
            // 
            this.idtovC.DataPropertyName = "idtov";
            this.idtovC.HeaderText = "idtovC";
            this.idtovC.Name = "idtovC";
            this.idtovC.ReadOnly = true;
            this.idtovC.Visible = false;
            // 
            // DataC
            // 
            this.DataC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataC.DataPropertyName = "data";
            this.DataC.HeaderText = "Дата установки цены";
            this.DataC.Name = "DataC";
            this.DataC.ReadOnly = true;
            // 
            // Cena0
            // 
            this.Cena0.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Cena0.DataPropertyName = "Cena0";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N2";
            this.Cena0.DefaultCellStyle = dataGridViewCellStyle1;
            this.Cena0.HeaderText = "Цена поспупления (без НДС)";
            this.Cena0.Name = "Cena0";
            this.Cena0.ReadOnly = true;
            // 
            // CenaR
            // 
            this.CenaR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CenaR.DataPropertyName = "CenaR";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.Format = "N2";
            this.CenaR.DefaultCellStyle = dataGridViewCellStyle2;
            this.CenaR.HeaderText = "Цена реализации";
            this.CenaR.Name = "CenaR";
            this.CenaR.ReadOnly = true;
            // 
            // btnSaveSCODE
            // 
            this.btnSaveSCODE.Enabled = false;
            this.btnSaveSCODE.Location = new System.Drawing.Point(358, 222);
            this.btnSaveSCODE.Name = "btnSaveSCODE";
            this.btnSaveSCODE.Size = new System.Drawing.Size(82, 25);
            this.btnSaveSCODE.TabIndex = 13;
            this.btnSaveSCODE.Text = "Сохранить";
            this.btnSaveSCODE.UseVisualStyleBackColor = true;
            this.btnSaveSCODE.Click += new System.EventHandler(this.btnSaveSCODE_Click);
            // 
            // txtSCODE
            // 
            this.txtSCODE.Location = new System.Drawing.Point(115, 172);
            this.txtSCODE.Multiline = true;
            this.txtSCODE.Name = "txtSCODE";
            this.txtSCODE.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSCODE.Size = new System.Drawing.Size(324, 50);
            this.txtSCODE.TabIndex = 12;
            this.txtSCODE.TextChanged += new System.EventHandler(this.txtSCODE_TextChanged);
            // 
            // lblSCODE
            // 
            this.lblSCODE.AutoSize = true;
            this.lblSCODE.Location = new System.Drawing.Point(23, 172);
            this.lblSCODE.Name = "lblSCODE";
            this.lblSCODE.Size = new System.Drawing.Size(62, 13);
            this.lblSCODE.TabIndex = 11;
            this.lblSCODE.Text = "Штрих-код:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Документ поступления:";
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dg1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dg1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Data,
            this.Nomer,
            this.Postav,
            this.iddoc,
            this.idpost});
            this.dg1.Location = new System.Drawing.Point(0, 304);
            this.dg1.MultiSelect = false;
            this.dg1.Name = "dg1";
            this.dg1.ReadOnly = true;
            this.dg1.RowHeadersWidth = 30;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.Size = new System.Drawing.Size(459, 144);
            this.dg1.TabIndex = 8;
            this.dg1.DoubleClick += new System.EventHandler(this.dg1_DoubleClick);
            // 
            // Data
            // 
            this.Data.DataPropertyName = "data";
            dataGridViewCellStyle4.Format = "d";
            dataGridViewCellStyle4.NullValue = null;
            this.Data.DefaultCellStyle = dataGridViewCellStyle4;
            this.Data.HeaderText = "Дата";
            this.Data.Name = "Data";
            this.Data.ReadOnly = true;
            this.Data.Width = 80;
            // 
            // Nomer
            // 
            this.Nomer.DataPropertyName = "nomerTN";
            this.Nomer.HeaderText = "Номер";
            this.Nomer.Name = "Nomer";
            this.Nomer.ReadOnly = true;
            this.Nomer.Width = 80;
            // 
            // Postav
            // 
            this.Postav.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Postav.DataPropertyName = "NamePost";
            this.Postav.HeaderText = "Поставщик";
            this.Postav.Name = "Postav";
            this.Postav.ReadOnly = true;
            // 
            // iddoc
            // 
            this.iddoc.DataPropertyName = "iddoc";
            this.iddoc.HeaderText = "iddoc";
            this.iddoc.Name = "iddoc";
            this.iddoc.ReadOnly = true;
            this.iddoc.Visible = false;
            // 
            // idpost
            // 
            this.idpost.DataPropertyName = "idPost";
            this.idpost.HeaderText = "idpost";
            this.idpost.Name = "idpost";
            this.idpost.ReadOnly = true;
            this.idpost.Visible = false;
            // 
            // lblCena
            // 
            this.lblCena.AutoSize = true;
            this.lblCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCena.Location = new System.Drawing.Point(322, 256);
            this.lblCena.Name = "lblCena";
            this.lblCena.Size = new System.Drawing.Size(16, 18);
            this.lblCena.TabIndex = 7;
            this.lblCena.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(217, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Цена реализации:";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblKol.Location = new System.Drawing.Point(149, 255);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(16, 18);
            this.lblKol.TabIndex = 5;
            this.lblKol.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Количество в остатке:";
            // 
            // lblCODE
            // 
            this.lblCODE.AutoSize = true;
            this.lblCODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCODE.Location = new System.Drawing.Point(355, 16);
            this.lblCODE.Name = "lblCODE";
            this.lblCODE.Size = new System.Drawing.Size(64, 16);
            this.lblCODE.TabIndex = 1;
            this.lblCODE.Text = "0000000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Код:";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(385, 476);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(87, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "&Закрыть";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnViewDoc
            // 
            this.btnViewDoc.Location = new System.Drawing.Point(12, 476);
            this.btnViewDoc.Name = "btnViewDoc";
            this.btnViewDoc.Size = new System.Drawing.Size(134, 23);
            this.btnViewDoc.TabIndex = 2;
            this.btnViewDoc.Text = "Просмотр документа";
            this.btnViewDoc.UseVisualStyleBackColor = true;
            this.btnViewDoc.Click += new System.EventHandler(this.btnViewDoc_Click);
            // 
            // btnAddBasket
            // 
            this.btnAddBasket.Location = new System.Drawing.Point(164, 476);
            this.btnAddBasket.Name = "btnAddBasket";
            this.btnAddBasket.Size = new System.Drawing.Size(134, 23);
            this.btnAddBasket.TabIndex = 2;
            this.btnAddBasket.Text = "Добавить в корзину";
            this.btnAddBasket.UseVisualStyleBackColor = true;
            this.btnAddBasket.Click += new System.EventHandler(this.btnAddBasket_Click);
            // 
            // frmDataOfTovar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 511);
            this.Controls.Add(this.btnAddBasket);
            this.Controls.Add(this.btnViewDoc);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDataOfTovar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Данные о товаре";
            this.Load += new System.EventHandler(this.frmDataOfTovar_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmDataOfTovar_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabInfo.ResumeLayout(false);
            this.tabName.ResumeLayout(false);
            this.tabName.PerformLayout();
            this.tabDescr.ResumeLayout(false);
            this.tabDescr.PerformLayout();
            this.tabCeny.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgCeny)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Label lblCena;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label lblKol;
        public System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCODE;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox txtNameTovar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnViewDoc;
        public System.Windows.Forms.TextBox txtSCODE;
        private System.Windows.Forms.Label lblSCODE;
        private System.Windows.Forms.Button btnSaveSCODE;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tabInfo;
        private System.Windows.Forms.TabPage tabName;
        private System.Windows.Forms.TabPage tabDescr;
        private System.Windows.Forms.TextBox txtDescr;
        public System.Windows.Forms.Button btnAddBasket;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postav;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn idpost;
        private System.Windows.Forms.TabPage tabCeny;
        private System.Windows.Forms.DataGridView dgCeny;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddocC;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtovC;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cena0;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaR;
    }
}