﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop
{
    public partial class FindText : UserControl
    {
        string Find = "Найти";
        Color ColorHelpText = Color.FromArgb(201, 201, 201);

        public delegate void ButtonFindHandler(object sender, EventArgs e);
        public event ButtonFindHandler FindClick;
        public event ButtonFindHandler FindTextChanged;

        public delegate void FindTextBoxKeyPress(object sender, KeyPressEventArgs e);
        public event FindTextBoxKeyPress FindKeyPress;

        Image imgFind = global::MyShop.Properties.Resources.icons8_поиск_241;

        public string HelpTextFind
        {
            get
            {
                return Find;
            }
            set
            {
                Find = value;
            }
        }
        public Color BorderColor { get; set; }

        public TextBox TextBoxFind
        {
            get
            {
                return txtFind;
            }
            set
            {
                txtFind = value;
            }
        }

        public int BorederTickness { get; set; }

        public Color FindTextBackColor { get; set; }

        public Color FindTextForeColor { get; set; }

        public int TextLenght { get; set; }

        public string TextFind { get; set; }

        public FindText()
        {
            InitializeComponent();

            BorderColor = Color.LightGray;
            BorederTickness = 2;
            FindTextBackColor = Color.White;
            FindTextForeColor = Color.Black;
            this.BackColor = FindTextBackColor;
            this.ForeColor = FindTextForeColor;
            txtFind.Text = HelpTextFind;
            txtFind.ForeColor = ColorHelpText;

            this.btnFind.Image = imgFind;
        }

        private void txtFind_Enter(object sender, EventArgs e)
        {
            if (txtFind.Text == Find & txtFind.ForeColor == ColorHelpText)
            {
                txtFind.Text = null;
                txtFind.ForeColor = FindTextForeColor;
                TextLenght = 0;
                TextFind = null;
            }
        }

        private void txtFind_Leave(object sender, EventArgs e)
        {
            if (txtFind.Text == null || txtFind.Text == "")
            {
                txtFind.Text = Find;
                txtFind.ForeColor = ColorHelpText;
                TextLenght = 0;
                TextFind = null;
            }
        }

        private void FindText_Resize(object sender, EventArgs e)
        {
            this.Height = tableLayoutPanel1.Height;
            this.Refresh();
        }


        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(BorderColor, BorederTickness);
            e.Graphics.DrawRectangle(pen, BorederTickness - 1, BorederTickness - 1, tableLayoutPanel1.Width - BorederTickness, tableLayoutPanel1.Height - BorederTickness);
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            //if(TextLenght>0)
            //{
            //    this.btnFind.Image = imgCancel;
            //}

            if (FindClick != null)
            {
                FindClick(sender, e);
            }

        }

        private void txtFind_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (FindKeyPress != null)
            {
                FindKeyPress(sender, e);
            }
        }

        private void FindText_Load(object sender, EventArgs e)
        {
            this.BackColor = FindTextBackColor;
            tableLayoutPanel1.BackColor = FindTextBackColor;
            txtFind.BackColor = FindTextBackColor;
            txtFind.ForeColor = ColorHelpText;
            this.Height = tableLayoutPanel1.Height;
            txtFind.Text = HelpTextFind;
        }

        private void txtFind_TextChanged(object sender, EventArgs e)
        {
            if (txtFind.Text == Find)
            {
                TextLenght = 0;
                TextFind = null;
            }
            else
            {
                TextLenght = txtFind.Text.Length;
                TextFind = txtFind.Text;
            }


            if (FindTextChanged != null)
            {
                FindTextChanged(sender, e);
            }
        }
        public void TextClear()
        {
            TextFind = null;
            TextLenght = 0;
            txtFind.Text = HelpTextFind;
            txtFind.ForeColor = ColorHelpText;
        }

    }
}
