﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace MyShop
{
    public partial class frmSplashSCREEN : Form
    {

        public frmSplashSCREEN()
        {
            InitializeComponent();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawString("Версия " + Assembly.GetExecutingAssembly().GetName().Version.ToString(), new Font("Segoe UI", 9, FontStyle.Regular), Brushes.White, new Point(10,10));
            e.Graphics.DrawRectangle(new Pen(Brushes.White), 0, 0, this.Width-1, this.Height-1);
        }


    }
}
