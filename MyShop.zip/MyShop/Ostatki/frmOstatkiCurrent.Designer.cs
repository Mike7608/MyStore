﻿
namespace MyShop.Ostatki
{
    partial class frmOstatkiCurrent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOstatkiCurrent));
            this.panelBottom = new System.Windows.Forms.Panel();
            this.panelFind = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.myButton2 = new MyShop.MyButton();
            this.myBtnOK = new MyShop.MyButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.myButtonInfo = new MyShop.MyButton();
            this.btnCreateCennik = new MyShop.MyButton();
            this.btnPrint = new MyShop.MyButton();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClearFilter = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new MyShop.MyButton();
            this.findTextCena1 = new MyShop.FindTextCena();
            this.dg = new System.Windows.Forms.DataGridView();
            this.idtov = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameTovar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mnuCreateCennik = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.создатьЦенникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuInfoTovar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelDataGrid = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.uscInfoTovar1 = new MyShop.Ostatki.uscInfoTovar();
            this.panelBottom.SuspendLayout();
            this.panelFind.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.mnuCreateCennik.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.panelDataGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelBottom.Controls.Add(this.panelFind);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 487);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(884, 74);
            this.panelBottom.TabIndex = 0;
            // 
            // panelFind
            // 
            this.panelFind.Controls.Add(this.panel2);
            this.panelFind.Controls.Add(this.panel1);
            this.panelFind.Controls.Add(this.lblTotal);
            this.panelFind.Controls.Add(this.label1);
            this.panelFind.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFind.Location = new System.Drawing.Point(0, 0);
            this.panelFind.Name = "panelFind";
            this.panelFind.Size = new System.Drawing.Size(884, 74);
            this.panelFind.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.myButton2);
            this.panel2.Controls.Add(this.myBtnOK);
            this.panel2.Location = new System.Drawing.Point(440, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(130, 74);
            this.panel2.TabIndex = 9;
            this.panel2.Visible = false;
            // 
            // myButton2
            // 
            this.myButton2.BackColor = System.Drawing.Color.DimGray;
            this.myButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.myButton2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.myButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.myButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.myButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myButton2.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myButton2.ForeColor = System.Drawing.Color.White;
            this.myButton2.Image = global::MyShop.Properties.Resources.icons8_умножение_24;
            this.myButton2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.myButton2.Location = new System.Drawing.Point(69, 5);
            this.myButton2.Name = "myButton2";
            this.myButton2.Size = new System.Drawing.Size(58, 64);
            this.myButton2.TabIndex = 10;
            this.myButton2.Text = "Отмена";
            this.myButton2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.myButton2.UseVisualStyleBackColor = false;
            // 
            // myBtnOK
            // 
            this.myBtnOK.BackColor = System.Drawing.Color.DimGray;
            this.myBtnOK.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.myBtnOK.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.myBtnOK.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.myBtnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myBtnOK.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myBtnOK.ForeColor = System.Drawing.Color.White;
            this.myBtnOK.Image = global::MyShop.Properties.Resources.icons8_галочка_24;
            this.myBtnOK.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.myBtnOK.Location = new System.Drawing.Point(8, 5);
            this.myBtnOK.Name = "myBtnOK";
            this.myBtnOK.Size = new System.Drawing.Size(58, 64);
            this.myBtnOK.TabIndex = 9;
            this.myBtnOK.Text = "OK";
            this.myBtnOK.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.myBtnOK.UseVisualStyleBackColor = false;
            this.myBtnOK.Click += new System.EventHandler(this.myBtnOK_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.myButtonInfo);
            this.panel1.Controls.Add(this.btnCreateCennik);
            this.panel1.Controls.Add(this.btnPrint);
            this.panel1.Location = new System.Drawing.Point(253, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(187, 74);
            this.panel1.TabIndex = 7;
            // 
            // myButtonInfo
            // 
            this.myButtonInfo.BackColor = System.Drawing.Color.DimGray;
            this.myButtonInfo.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.myButtonInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.myButtonInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.myButtonInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myButtonInfo.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myButtonInfo.ForeColor = System.Drawing.Color.White;
            this.myButtonInfo.Image = global::MyShop.Properties.Resources.icons8_Info_24;
            this.myButtonInfo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.myButtonInfo.Location = new System.Drawing.Point(126, 5);
            this.myButtonInfo.Name = "myButtonInfo";
            this.myButtonInfo.Size = new System.Drawing.Size(58, 64);
            this.myButtonInfo.TabIndex = 7;
            this.myButtonInfo.Text = "Информация";
            this.myButtonInfo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.myButtonInfo.UseVisualStyleBackColor = false;
            this.myButtonInfo.Click += new System.EventHandler(this.myButtonInfo_Click);
            // 
            // btnCreateCennik
            // 
            this.btnCreateCennik.BackColor = System.Drawing.Color.DimGray;
            this.btnCreateCennik.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnCreateCennik.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCreateCennik.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnCreateCennik.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateCennik.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateCennik.ForeColor = System.Drawing.Color.White;
            this.btnCreateCennik.Image = global::MyShop.Properties.Resources.creditcards_24;
            this.btnCreateCennik.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCreateCennik.Location = new System.Drawing.Point(4, 5);
            this.btnCreateCennik.Name = "btnCreateCennik";
            this.btnCreateCennik.Size = new System.Drawing.Size(58, 64);
            this.btnCreateCennik.TabIndex = 6;
            this.btnCreateCennik.Text = "Создать ценник";
            this.btnCreateCennik.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCreateCennik.UseVisualStyleBackColor = false;
            this.btnCreateCennik.Click += new System.EventHandler(this.btnCreateCennik_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnPrint.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Image = global::MyShop.Properties.Resources.print_search_24_w;
            this.btnPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrint.Location = new System.Drawing.Point(65, 5);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(58, 64);
            this.btnPrint.TabIndex = 4;
            this.btnPrint.Text = "Печать";
            this.btnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.BtnPrint_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTotal.Location = new System.Drawing.Point(102, 13);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(19, 21);
            this.lblTotal.TabIndex = 1;
            this.lblTotal.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Всего записей:";
            // 
            // btnClearFilter
            // 
            this.btnClearFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearFilter.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnClearFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearFilter.Image = ((System.Drawing.Image)(resources.GetObject("btnClearFilter.Image")));
            this.btnClearFilter.Location = new System.Drawing.Point(834, 16);
            this.btnClearFilter.Name = "btnClearFilter";
            this.btnClearFilter.Size = new System.Drawing.Size(35, 35);
            this.btnClearFilter.TabIndex = 3;
            this.toolTip1.SetToolTip(this.btnClearFilter, "Сбросить фильтр    Ctrl+Del");
            this.btnClearFilter.UseVisualStyleBackColor = true;
            this.btnClearFilter.Click += new System.EventHandler(this.BtnClearFilter_Click);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.btnClearFilter);
            this.panelTop.Controls.Add(this.btnExit);
            this.panelTop.Controls.Add(this.findTextCena1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(884, 74);
            this.panelTop.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(72, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(295, 47);
            this.label2.TabIndex = 8;
            this.label2.Text = "Текущие остатки";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DimGray;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = global::MyShop.Properties.Resources.arrow_left_w_24;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExit.Location = new System.Drawing.Point(3, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(52, 64);
            this.btnExit.TabIndex = 7;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // findTextCena1
            // 
            this.findTextCena1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.findTextCena1.BackColor = System.Drawing.Color.White;
            this.findTextCena1.BorderColor = System.Drawing.Color.LightGray;
            this.findTextCena1.BorederTickness = 2;
            this.findTextCena1.CenaLenght = 0;
            this.findTextCena1.FindTextBackColor = System.Drawing.Color.White;
            this.findTextCena1.FindTextForeColor = System.Drawing.Color.Black;
            this.findTextCena1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findTextCena1.ForeColor = System.Drawing.Color.Black;
            this.findTextCena1.HelpTextCena = "Цена";
            this.findTextCena1.HelpTextFind = "Код и/или наименование товара";
            this.findTextCena1.Location = new System.Drawing.Point(419, 16);
            this.findTextCena1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.findTextCena1.Name = "findTextCena1";
            this.findTextCena1.Size = new System.Drawing.Size(413, 35);
            this.findTextCena1.TabIndex = 2;
            this.findTextCena1.TextCena = "";
            this.findTextCena1.TextFind = "";
            this.findTextCena1.TextLenght = 0;
            this.findTextCena1.FindClick += new MyShop.FindTextCena.ButtonFindHandler(this.FindTextCena1_FindClick_1);
            this.findTextCena1.FindTextChanged += new MyShop.FindTextCena.ButtonFindHandler(this.FindTextCena1_FindTextChanged);
            this.findTextCena1.FindKeyPress += new MyShop.FindTextCena.FindTextBoxKeyPress(this.FindTextCena1_FindKeyPress);
            // 
            // dg
            // 
            this.dg.AllowUserToAddRows = false;
            this.dg.AllowUserToDeleteRows = false;
            this.dg.AllowUserToOrderColumns = true;
            this.dg.BackgroundColor = System.Drawing.Color.White;
            this.dg.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dg.ColumnHeadersHeight = 24;
            this.dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idtov,
            this.Code,
            this.NameTovar,
            this.Kol,
            this.Cena});
            this.dg.ContextMenuStrip = this.mnuCreateCennik;
            this.dg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg.Location = new System.Drawing.Point(244, 0);
            this.dg.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dg.MultiSelect = false;
            this.dg.Name = "dg";
            this.dg.ReadOnly = true;
            this.dg.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg.Size = new System.Drawing.Size(416, 413);
            this.dg.TabIndex = 2;
            this.dg.SelectionChanged += new System.EventHandler(this.dg_SelectionChanged);
            this.dg.DoubleClick += new System.EventHandler(this.Dg_DoubleClick);
            this.dg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmOstatkiCurrent_KeyDown);
            // 
            // idtov
            // 
            this.idtov.DataPropertyName = "idtov";
            this.idtov.HeaderText = "idtov";
            this.idtov.Name = "idtov";
            this.idtov.ReadOnly = true;
            this.idtov.Visible = false;
            // 
            // Code
            // 
            this.Code.DataPropertyName = "Code";
            this.Code.HeaderText = "Код 1С";
            this.Code.Name = "Code";
            this.Code.ReadOnly = true;
            this.Code.Width = 170;
            // 
            // NameTovar
            // 
            this.NameTovar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NameTovar.DataPropertyName = "NameTovar";
            this.NameTovar.HeaderText = "Наименование товара";
            this.NameTovar.Name = "NameTovar";
            this.NameTovar.ReadOnly = true;
            // 
            // Kol
            // 
            this.Kol.DataPropertyName = "kol";
            this.Kol.HeaderText = "Количество";
            this.Kol.Name = "Kol";
            this.Kol.ReadOnly = true;
            this.Kol.Width = 152;
            // 
            // Cena
            // 
            this.Cena.DataPropertyName = "Cena";
            this.Cena.HeaderText = "Цена";
            this.Cena.Name = "Cena";
            this.Cena.ReadOnly = true;
            this.Cena.Width = 170;
            // 
            // mnuCreateCennik
            // 
            this.mnuCreateCennik.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьЦенникToolStripMenuItem,
            this.toolStripMenuItem1,
            this.mnuInfoTovar});
            this.mnuCreateCennik.Name = "contextMenuStrip1";
            this.mnuCreateCennik.Size = new System.Drawing.Size(199, 54);
            // 
            // создатьЦенникToolStripMenuItem
            // 
            this.создатьЦенникToolStripMenuItem.Image = global::MyShop.Properties.Resources.creditcards_24;
            this.создатьЦенникToolStripMenuItem.Name = "создатьЦенникToolStripMenuItem";
            this.создатьЦенникToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.создатьЦенникToolStripMenuItem.Text = "Создать ценник";
            this.создатьЦенникToolStripMenuItem.Click += new System.EventHandler(this.создатьЦенникToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(195, 6);
            // 
            // mnuInfoTovar
            // 
            this.mnuInfoTovar.Name = "mnuInfoTovar";
            this.mnuInfoTovar.Size = new System.Drawing.Size(198, 22);
            this.mnuInfoTovar.Text = "Информация о товаре";
            this.mnuInfoTovar.Click += new System.EventHandler(this.mnuInfoTovar_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.splitContainer1);
            this.panelMain.Controls.Add(this.splitter1);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 74);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(884, 413);
            this.panelMain.TabIndex = 3;
            // 
            // panelDataGrid
            // 
            this.panelDataGrid.Controls.Add(this.dg);
            this.panelDataGrid.Controls.Add(this.panelLeft);
            this.panelDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDataGrid.Location = new System.Drawing.Point(0, 0);
            this.panelDataGrid.Name = "panelDataGrid";
            this.panelDataGrid.Size = new System.Drawing.Size(660, 413);
            this.panelDataGrid.TabIndex = 5;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 413);
            this.splitter1.TabIndex = 4;
            this.splitter1.TabStop = false;
            this.splitter1.Visible = false;
            // 
            // panelLeft
            // 
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(244, 413);
            this.panelLeft.TabIndex = 3;
            this.panelLeft.Visible = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panelDataGrid);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.uscInfoTovar1);
            this.splitContainer1.Size = new System.Drawing.Size(881, 413);
            this.splitContainer1.SplitterDistance = 660;
            this.splitContainer1.TabIndex = 6;
            // 
            // uscInfoTovar1
            // 
            this.uscInfoTovar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uscInfoTovar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uscInfoTovar1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uscInfoTovar1.Location = new System.Drawing.Point(0, 0);
            this.uscInfoTovar1.Name = "uscInfoTovar1";
            this.uscInfoTovar1.PanelsIsOpen = true;
            this.uscInfoTovar1.Size = new System.Drawing.Size(217, 413);
            this.uscInfoTovar1.TabIndex = 0;
            this.uscInfoTovar1.Close += new MyShop.Ostatki.uscInfoTovar.InfoTovarEvent(this.uscInfoTovar1_Close);
            // 
            // frmOstatkiCurrent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelBottom);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmOstatkiCurrent";
            this.Text = "Текущие остатки";
            this.Load += new System.EventHandler(this.FrmOstatkiCurrent_Load);
            this.Shown += new System.EventHandler(this.frmOstatkiCurrent_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmOstatkiCurrent_KeyDown);
            this.Resize += new System.EventHandler(this.frmOstatkiCurrent_Resize);
            this.panelBottom.ResumeLayout(false);
            this.panelFind.ResumeLayout(false);
            this.panelFind.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.mnuCreateCennik.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            this.panelDataGrid.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        public System.Windows.Forms.DataGridView dg;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel panelFind;
        private System.Windows.Forms.Button btnClearFilter;
        private System.Windows.Forms.ToolTip toolTip1;
        private MyButton btnPrint;
        public FindTextCena findTextCena1;
        private System.Windows.Forms.ContextMenuStrip mnuCreateCennik;
        private System.Windows.Forms.ToolStripMenuItem создатьЦенникToolStripMenuItem;
        public MyButton btnCreateCennik;
        private MyButton btnExit;
        private System.Windows.Forms.Panel panel2;
        private MyButton myButton2;
        private MyButton myBtnOK;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelDataGrid;
        private System.Windows.Forms.Splitter splitter1;
        public System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mnuInfoTovar;
        private MyButton myButtonInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtov;
        private System.Windows.Forms.DataGridViewTextBoxColumn Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameTovar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kol;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cena;
        public System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private uscInfoTovar uscInfoTovar1;
    }
}