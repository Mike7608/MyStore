﻿using MyShop.MAGAZIN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MyShop.Ostatki
{
    public partial class frmOstatkiCurrent : Form
    {
        private bool _visibleLeftPanel=false;
        public BindingSource bs = new BindingSource();
        //private string Filtr;

        Cenniki.Cennik cen;

        #region  СВОЙСТВА

        public bool VisibleLeftPanel
        {
            get
            {
                return _visibleLeftPanel;
            }
            set
            {
                _visibleLeftPanel = value;
                splitter1.Visible = value;
                panelLeft.Visible = value;
            }
        }

        #endregion

        public frmOstatkiCurrent()
        {
            InitializeComponent();

           
            bs.ListChanged += Bs_ListChanged;
            MyStyleDataGrid myStyle = new MyStyleDataGrid();
            myStyle.Default(dg);

            cen = new Cenniki.Cennik();
            cen.Notify += Cennik_Created;

            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dg.DefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Regular);

        }

        private void FrmOstatkiCurrent_Load(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            dg.Paint += Dg_Paint;
            bs.DataSource = Global.mainDataSet;
            bs.DataMember = "REMAINS";
            dg.AutoGenerateColumns = false;

            dg.DataSource = bs;
            Font bold = new Font("Segoe UI Semibold", 14, FontStyle.Bold);

            DataGridViewColumn CODE = dg.Columns["CODE"];
            CODE.Width = 150;
            CODE.DefaultCellStyle.Padding = new Padding(15, 5, 5, 5);
            CODE.DefaultCellStyle.Font = bold;

            //dg.Columns["SCODE"].Width = 120;
            dg.Columns["NameTovar"].Width = 400;
            DataGridViewColumn kol = dg.Columns["kol"];
            kol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            //kol.DefaultCellStyle.Format = "N3";
            kol.Width = 80;
            DataGridViewColumn Cena = dg.Columns["Cena"];
            Cena.Width = 130;
            Cena.DefaultCellStyle.Font = bold;
            Cena.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Cena.DefaultCellStyle.Format = "N2";
            Cena.DefaultCellStyle.Padding = new Padding(0, 5, 15, 5);
            uscInfoTovar1.VisibleChanged += UscInfoTovar1_VisibleChanged;

            Cursor = Cursors.Default;

        }

        private void UscInfoTovar1_VisibleChanged(object sender, EventArgs e)
        {
            if (uscInfoTovar1.Visible)
            {
                uscInfoTovar1.LoadData(CurrentIDtov());
            }
        }

        private void Dg_Paint(object sender, PaintEventArgs e)
        {
            MK.Procedures procedures = new MK.Procedures();
            procedures.PaintNullDataString(dg, e);
        }

        private void Bs_ListChanged(object sender, ListChangedEventArgs e)
        {
            lblTotal.Text = bs.Count.ToString();
            if (bs.Count > 0)
            {
                btnPrint.Enabled = true;
                btnCreateCennik.Enabled = true;
                mnuCreateCennik.Enabled = true;
            }
            else
            {
                btnPrint.Enabled = false;
                btnCreateCennik.Enabled = false;
                mnuCreateCennik.Enabled = false;
            }
        }

        public bool BtnPrintVisible
        {
            get
            {
                return btnPrint.Visible;
            }
            set
            {
                btnPrint.Visible = value;
            }
        }

        public bool Panel2Visible
        {
            get
            {
                return panel2.Visible;
            }
            set
            {
                panel2.Visible = value;
            }
        }

        private void ApplyFilter()
        {
            dg.Paint -= Dg_Paint; //сбрасываем сообщение фильтра о пустом результате
            DataTable dt = Global.mainDataSet.Tables[Global.NameTableOstatki];
            string[] colText = { "CODE", "NameTovar" };
            bs.DataSource = findTextCena1.FilteredTable(dt, colText, "Cena", findTextCena1.TextFind, findTextCena1.TextCena);
            dg.DataSource = bs;
            if (bs.Count == 0)
            {
                dg.Paint += Dg_Paint;//выводим сообщение фильтра о пустом результате

                dg.Refresh();
            }
            dg.Focus();
        }

        //private void ApplyFilter2()
        //{
        //    string str1 = findTextCena1.TextFind;//строка текста для поиска
        //    string str2 = findTextCena1.TextCena;//строка цены для поиска

        //    string main = null;
        //    string main2 =null;
        //    if (!string.IsNullOrEmpty(str1))
        //    {
        //        string[] TXT = str1.Split(' ');
        //        int x;
        //        for (x = 0; x < TXT.Length; x++)
        //        {
        //            string t = TXT[x];
        //            main += "[CODE] Like '*"  + t.Trim() + "*' OR [NameTovar] Like '*" +t.Trim()+"*'";
        //            if (x < TXT.Length - 1)
        //            {
        //                main += " AND ";
        //            }
        //        }
        //    }

        //    if(!string.IsNullOrEmpty(str2))//Cena tovara
        //    {
        //        try
        //        {
        //            double Cena = Convert.ToDouble(str2.Replace('.', ','));
        //            string txtS = Cena.ToString().Replace(',', '.');
        //            main2 = "[Cena] =" + txtS;
        //        }
        //        catch
        //        {
        //            MessageBox.Show("Не цифровое значение для поиска в поле 'Цена'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }
               
        //    }

        //    if(!string.IsNullOrEmpty(main2))
        //    {
        //        if(main!=null)
        //        {
        //            main += " AND " + main2;
        //        }
        //        else
        //        {
        //            main = main2;
        //        }
        //    }

        //    //Filtr = main;
        //    //bs.Filter = Filtr;

        //    if (bs.Count > 0)
        //    {
        //        btnPrint.Enabled = true;
        //        myBtnOK.Enabled = true;
        //    }
        //    else
        //    {
        //        btnPrint.Enabled = false;
        //        myBtnOK.Enabled = false;
        //    }
        //    dg.Focus();
        //}

        private void FindTextCena1_FindClick_1(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void FindTextCena1_FindKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ApplyFilter();
                e.Handled = true;
            }
        }



        private void FindTextCena1_FindTextChanged(object sender, EventArgs e)
        {
            //if(findTextCena1.TextLenght==0 & findTextCena1.CenaLenght==0)
            //{
            //    bs.Filter = null;
            //    Filtr = null;
            //}
        }

        private void Dg_DoubleClick(object sender, EventArgs e)
        {
            if (panel2.Visible)
            { 
                InsertDataBufferCennik();
                Close();
            }

        }

        private void InsertDataBufferCennik()
        {
            DataRowView dr = (DataRowView)bs.Current;
            Cennik.BufferCennik.Clear();
            Cennik.BufferCennik.idtov = dr["idtov"].ToString();
            Cennik.BufferCennik.code = dr["code"].ToString();
            Cennik.BufferCennik.NameTovar = dr["NameTovar"].ToString();
            Cennik.BufferCennik.Cena =Convert.ToDecimal(dr["cena"].ToString().Replace('.',','));
            Cennik.BufferCennik.FilterText = findTextCena1.TextFind;
            Cennik.BufferCennik.FilterCena = findTextCena1.TextCena;
            this.DialogResult = DialogResult.OK;
        }

        private void BtnClearFilter_Click(object sender, EventArgs e)
        {
            bs.DataSource = Global.mainDataSet;
            bs.DataMember = "REMAINS";
            findTextCena1.TextClear();
            //Filtr = null;
            Cennik.BufferCennik.FilterText = null;
            Cennik.BufferCennik.FilterCena = null;
        }


        private void FrmOstatkiCurrent_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {

                case Keys.Control | Keys.Delete:
                    BtnClearFilter_Click(btnClearFilter, null);
                    break;
                case Keys.Control | Keys.F:
                    findTextCena1.Focus();
                    break;
                case Keys.I:
                    Dg_DoubleClick(dg, null);
                    break;
                case Keys.Enter:
                    if( panel2.Visible == true)
                    {
                        InsertDataBufferCennik();
                        Close();
                    }
                    break;
                default:
                    break;
            }
        }

        public virtual void BtnPrint_Click(object sender, EventArgs e)
        {
            if (bs.Count > 0)
            {
                PrintGroupOstatki ot = new PrintGroupOstatki(bs);
                FrmPrintPreview prn = new FrmPrintPreview(ot)
                {
                    MdiParent = Global.mainForm

                };
                    prn.Show();
            }

        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            InsertDataBufferCennik();
            Close();
        }

        private void frmOstatkiCurrent_Resize(object sender, EventArgs e)
        {
            dg.Refresh();
            CenterAlignButton();
        }


        private void CenterAlignButton()
        {
            int pan1 = (panelFind.Width - panel1.Width) / 2;
            int pan2 = (panelFind.Width - panel2.Width) / 2;
            if (panel2.Visible)
            {
                //panel1.Location = new Point(pan1 - (panel2.Width/2),0);
                panel2.Location = new Point(pan2, 0);
            }
            else
            {
                panel1.Location = new Point(pan1, 0);
            }
        }

        private void btnCreateCennik_Click(object sender, EventArgs e)
        {
            CreateCennik();
        }

        private void создатьЦенникToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateCennik();
        }

        private void CreateCennik()
        {
            cen.CreateCennik(CurrentIDtov(), true);
        }

        private void Cennik_Created(string Message)
        {
            frmInfoSales frmAlert = new frmInfoSales();
            frmAlert.ShowAlert(Message, "Информация о формировании ценника", frmInfoSales.EnmType.Success);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void myBtnOK_Click(object sender, EventArgs e)
        {
            InsertDataBufferCennik();
            Close();
        }

        private void frmOstatkiCurrent_Shown(object sender, EventArgs e)
        {
            CenterAlignButton();
        }

        private void mnuInfoTovar_Click(object sender, EventArgs e)
        {
            myButtonInfo_Click(sender,e);
        }

        private void myButtonInfo_Click(object sender, EventArgs e)
        {
            if (splitContainer1.Panel2Collapsed)
            {
                splitContainer1.Panel2Collapsed = false;
            }
            else
            {
                splitContainer1.Panel2Collapsed = true;
            }
        }


        private string CurrentIDtov()
        {
            string id=null;

            try
            {
                DataRowView dr = (DataRowView)bs.Current;
                if (dr != null)
                {
                    id = dr["idtov"].ToString();
                }
            }
            catch
            {
                id = null;
            }

            return id;
        }

        private void dg_SelectionChanged(object sender, EventArgs e)
        {
            if (splitContainer1.Panel2Collapsed==false)
            {
                if (!string.IsNullOrEmpty(CurrentIDtov()))
                {
                    uscInfoTovar1.LoadData(CurrentIDtov());
                }
                else
                {
                    uscInfoTovar1.Clear();
                }
            }
        }

        private void uscInfoTovar1_Close()
        {
            splitContainer1.Panel2Collapsed = true;
        }
    }
}
