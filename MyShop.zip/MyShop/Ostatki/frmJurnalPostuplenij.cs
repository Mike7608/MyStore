﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.Ostatki
{
    public partial class frmJurnalPostuplenij : Form
    {

        public BindingSource bs = new BindingSource();
        SQLmodule sql = new SQLmodule();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable("TN");

        public frmJurnalPostuplenij()
        {
            InitializeComponent();

            ds.Tables.Add(dt);
            controlPeriod1.DateStart = DateTime.Now;
            controlPeriod1.DateEnd = DateTime.Now;
            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;

        }

        private void frmJurnalPostuplenij_Load(object sender, EventArgs e)
        {
            bs.DataSource = ds;
            bs.DataMember = dt.TableName;
            dg.AutoGenerateColumns = false;

            dg.DataSource = bs;

            //назначаем стиль таблицы
            MyStyleDataGrid dgStyle = new MyStyleDataGrid();
            dgStyle.Default(dg);
            dg.AutoGenerateColumns = false;
            dg.DefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Regular);
            dg.AllowUserToAddRows = false;

            //настраиваем колонку дата
            DataGridViewColumn data = dg.Columns["DateTN"];
            data.DefaultCellStyle.Padding = new Padding(10, 5, 5, 5);

            //настраиваем колонку сумма
            DataGridViewColumn summa = dg.Columns["Summa"];
            Font bold = new Font("Segoe UI Semibold", 15, FontStyle.Bold);
            summa.DefaultCellStyle.Padding = new Padding(5, 5, 10, 5);
            summa.DefaultCellStyle.Font = bold;

            controlPeriod1_ChangPeriod();
        }

        private void LoadData(string dateStart, string dateEnd)
        { 

            Cursor = Cursors.WaitCursor;

            dt.Clear();
            sql.SQLselect("SELECT  _DH11188.IDDOC, _SC133.SP126 AS UNP, _SC133.DESCR, _DH11188.SP27331 AS data, _DH11188.SP27330 AS NoTN, _DH11188.SP11182 AS SummaNoNDS, _DH11188.SP11183 AS SummaNDS, _DH11188.SP11186 AS Summa FROM  _DH11188 INNER JOIN  _SC133 ON _DH11188.SP11172 = _SC133.ID INNER JOIN  _1SJOURN ON _DH11188.IDDOC = _1SJOURN.IDDOC WHERE (_1SJOURN.CLOSED = 5) AND _DH11188.SP27331 between '" + dateStart + "' and '" + dateEnd + "'  ORDER BY  _DH11188.SP27331 ASC", ds, dt.TableName);

            lblTotal.Text = TotalRowsInTablePeriods().ToString();

            Cursor = Cursors.Default;

            if (dg.Rows.Count > 0)
            {
                btnOpenTN.Enabled = true;
                panel1.Enabled = true;
            }
            else
            {
                btnOpenTN.Enabled = false;
                panel1.Enabled = false;
            }

        }

        private void controlPeriod1_ChangPeriod()
        {
            LoadData(controlPeriod1.DateStart.ToShortDateString(), controlPeriod1.DateEnd.ToShortDateString());
        }

        private int TotalRowsInTablePeriods()
        {
            return dt.Rows.Count;
        }


        private void OpenTN()
        {
            if (dg.Rows.Count > 0)
            {
                string id;//id TN
                int index;

                index = dg.CurrentRow.Index;
                id = dg["iddoc", index].Value.ToString();
                //Console.WriteLine(id);
                frmTNpost fTn = new frmTNpost(id);
                fTn.btnCreateCennik.Visible = true;
                fTn.ColumnSelectVisible = true;
                fTn.checkBox1.Visible = true;
                fTn.ShowDialog();
            }

        }

        private void dg_DoubleClick(object sender, EventArgs e)
        {
            OpenTN();
        }

        private void btnOpenTN_Click(object sender, EventArgs e)
        {
            OpenTN();
        }

        private void dg_Paint(object sender, PaintEventArgs e)
        {
                MK.Procedures procedures = new MK.Procedures();
                procedures.PaintNullDataString(dg, e);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnFilterClear_Click(object sender, EventArgs e)
        {
            bs.DataSource = dt;
            findTextCena.TextClear();
            //Summa();
        }


        private void ApplyFiltr()
        {
            if (findTextCena.TextLenght > 0 | findTextCena.CenaLenght > 0)
            {
                string[] val1 = { "data", "UNP", "descr", "NoTN" };
                bs.DataSource = findTextCena.FilteredTable(dt, val1, "Summa", findTextCena.TextFind, findTextCena.TextCena);
                dg.DataSource = bs;

            }
            //Summa();
        }

        private void findTextCena_FindClick(object sender, EventArgs e)
        {
            ApplyFiltr();
        }

        private void findTextCena_FindKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ApplyFiltr();
                e.Handled = true;
            }
        }


    }
}
