﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace MyShop
{
    public partial class PrintGroupOstatki : System.Drawing.Printing.PrintDocument
    {
        DataTable _dt;

        int page=1;
        int CurrentRow=0;
        int[] StartPageRow = new int[1000];
        string nameGroup = null;
        //bool IsGeneratePage;

        public PrintGroupOstatki(string Filter, string NameGroup)
        {

            InitializeComponent();

            nameGroup = NameGroup;
            Global.mainDataSet.Tables["REMAINS"].DefaultView.RowFilter = Filter;
            _dt = Global.mainDataSet.Tables["REMAINS"].DefaultView.ToTable();
            Global.mainDataSet.Tables["REMAINS"].DefaultView.RowFilter = null;

            this.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintGroupOstatki_PrintPage);
        }

        public PrintGroupOstatki(DataTable dt)
        {
            InitializeComponent();

            _dt = dt;
            nameGroup = dt.TableName;

            this.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintGroupOstatki_PrintPage);
        }

        public PrintGroupOstatki(BindingSource bs)
        {
            InitializeComponent();
            nameGroup = "[По всем группам]";
            Global.mainDataSet.Tables["REMAINS"].DefaultView.RowFilter = bs.Filter;
            _dt = Global.mainDataSet.Tables["REMAINS"].DefaultView.ToTable();
            Global.mainDataSet.Tables["REMAINS"].DefaultView.RowFilter = null;

            this.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintGroupOstatki_PrintPage);
        }

        public PrintGroupOstatki(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        private void PrintGroupOstatki_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            int posX = 40, posY = 40;
          
            Font fontTitleBold = new Font("Arial", 10, FontStyle.Bold);
            Font fontText = new Font("Arial", 9, FontStyle.Regular);

            CurrentRow = StartPageRow[page];

            //выводим номер страницы
            e.Graphics.DrawString("стр. " + page.ToString(), fontText, Brushes.Gray, e.MarginBounds.Right, e.MarginBounds.Bottom);

            if (page == 1)
            {
                //CurrentRow = 0;
                e.Graphics.DrawString("ОСТАТКИ ТОВАРОВ на " + DateTime.Now.ToShortDateString(), fontTitleBold, Brushes.Black, posX + 250, posY);
                posY += 25;

                RectangleF rF = new RectangleF(new Point(posX,posY-2), new Size(745,22));
                e.Graphics.FillRectangle(Brushes.LightGray, rF);


                //Printing.PrintTextBox box = new Printing.PrintTextBox(e.Graphics);
                //box.Text = "Hello!";
                //box.Font = new Font("Times New Roman", 10, FontStyle.Bold);
                //box.BackColor = Color.LightCoral;
                //box.Location = new Point(20, 50);
                //box.StringFormat.Alignment = StringAlignment.Center;
                //box.StringFormat.LineAlignment = StringAlignment.Center;
                //box.Border.Left = 1; box.Border.Right = 1;
                //box.Border.Bottom = 2; box.Border.Top = 2;
                //box.Paint();


                e.Graphics.DrawString("Группа: " + nameGroup.ToUpper(), fontTitleBold, Brushes.Black, posX+10, posY);
                posY += 40;
                e.Graphics.DrawString("Код 1С", fontText, Brushes.Black, posX, posY);
                e.Graphics.DrawString("Наименование товара", fontText, Brushes.Black, posX + 100, posY);
                e.Graphics.DrawString("Кол-во", fontText, Brushes.Black, posX + 580, posY);
                e.Graphics.DrawString("Цена", fontText, Brushes.Black, posX + 680, posY);
                e.Graphics.DrawLine(Pens.Black, posX, posY + 20, 785, posY + 20);

                posY += 25;
            }

            int x;
            for (x = CurrentRow; x < _dt.Rows.Count; x++)
            {
                DataRow dr = _dt.Rows[x];
                e.Graphics.DrawString(dr["Code"].ToString(), fontText, Brushes.Black, posX, posY);
                RectangleF recName = new RectangleF(new Point(posX + 90, posY), new Size(500, 17));
                //e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240, 240, 240)), recName);
                e.Graphics.DrawString(dr["NameTovar"].ToString(), fontText, Brushes.Black, recName);
                e.Graphics.DrawString(dr["kol"].ToString(), fontText, Brushes.Black, posX + 600, posY);
                RectangleF recCena = new RectangleF(new PointF(posX + 660, posY), new Size(80, 17));
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Far;
                e.Graphics.DrawString((string.Format("{0:f}", dr["Cena"])), fontTitleBold, Brushes.Black, recCena, sf);
                e.Graphics.DrawLine(Pens.LightGray, posX, posY + 20, 785, posY + 20);
                posY += 25;

                if (posY + 25 > e.MarginBounds.Bottom)
                {
                    //CurrentRow = x + 1;

                        e.HasMorePages = true;

                    page++;

                    StartPageRow[page] =  x + 1;
                    //PrinterSettings.ToPage = page;

                    break;
                }
                else
                {
                    e.HasMorePages = false;
                }

            }



        }

        //private void TextBox(string Text, Font font, StringFormat format, Color TextColor, Color BackColor, Point Location, Size size, System.Drawing.Printing.PrintPageEventArgs e)
        //{
        //    //закрашиваем фон
        //    RectangleF rF = new RectangleF(Location, size);
        //    e.Graphics.FillRectangle(new SolidBrush(BackColor), rF);

        //    //выводим текст
        //    e.Graphics.DrawString(Text, font, new SolidBrush(TextColor), rF, format);
        //}

        private void PrintGroupOstatki_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            page = 1;
        }

        private void PrintGroupOstatki_EndPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {

        }
    }

}
