﻿using MyShop.MAGAZIN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyShop.Cenniki;

namespace MyShop
{
    public partial class frmTNpost : Form
    {
        string _id;

        BindingSource bs = new BindingSource();
        public string idtov;
        DataSet ds = new DataSet();
        SQLmodule sql = new SQLmodule();
        Cenniki.Cennik cennik = new Cenniki.Cennik();
        frmInfoSales frmAlert = new frmInfoSales();

        public frmTNpost(string id)
        {
            _id = id;
            InitializeComponent();

        }

        public bool ColumnSelectVisible
        {
            get
            {
                return ColSelect.Visible;
            }
            set
            {
                ColSelect.Visible = value;
            }
        }

        private void frmTNpost_Load(object sender, EventArgs e)
        {
            LoadTN();

            LoadDataOfTN();
            if (dg1.Rows.Count > 0)
            {
                btnCreateCennik.Enabled = true;
                checkBox1.Enabled = true;
            }
            else
            {
                btnCreateCennik.Enabled = false;
                checkBox1.Enabled = false;
            }

            cennik.Notify += Cennik_Created;


        }

        private void Cennik_Created(string Message)
        {

            frmAlert.ShowAlert(Message, "Информация о формировании ценника", frmInfoSales.EnmType.Success);
        }

        private void LoadTN()
        {
            Cursor = Cursors.WaitCursor;
            if (ds.Tables.Contains("TN1"))
            {
                ds.Tables.Remove("TN1");
            }
            //************** исправить!!!! данные нужно брать из 1SJOURN  ***************

            sql.SQLselect("SELECT [_DH11188].iddoc, [_DH11188].sp27331 as dataTN, [_DH11188].sp11172 as idpost, [_DH11188].sp27330 as NomerTN, [_SC133].descr, [_SC133].sp126 as unp, [_SC133].sp124 as adr FROM _DH11188, _SC133 where iddoc='" + _id + "' and  _DH11188.sp11172=_SC133.id", ds,"TN1");

            DataRow dr;
            dr = ds.Tables["TN1"].Rows[0];
            if(dr["dataTN"].ToString().Length>0)
            {
                lblDataTN.Text = dr["dataTN"].ToString().Substring(0,10);
            }

            lblNomerTN.Text = dr["NomerTN"].ToString();
            lblPostName1.Text = sql.BLOBstring("3E", dr["idpost"].ToString());
            lblAdres.Text = dr["adr"].ToString();
            lblUNP.Text = dr["unp"].ToString();

            Cursor = Cursors.Default;

        }

        private void CenaVhod()
        {
            foreach(DataRow dr in ds.Tables["DATA"].Rows)
            {
                double cenaV, kol, sum;
                kol = Convert.ToDouble(dr["kol"].ToString());
                sum = Convert.ToDouble(dr["sum2"].ToString());
                cenaV = sum / kol;
                dr["CenaV"] = cenaV;
            }
        }

        private void LoadDataOfTN()
        {
            Cursor = Cursors.WaitCursor;

            if(ds.Tables.Contains("DATA"))
            {
                ds.Tables.Remove("DATA");
            }

            sql.SQLselect("SELECT [_SC156].id, [_DT11188].[lineno], [_SC156].descr, [_DT11188].sp11180 as kol, [_DT11188].sp11181 as cena1, [_DT11188].sp11182 as sum1, [_DT11188].sp11183 as nds, [_DT11188].sp11186 as sum2 FROM [_DT11188] INNER JOIN [_SC156] ON _DT11188.sp11179=_SC156.id WHERE [_DT11188].iddoc='" + _id + "'", ds, "DATA");

            ds.Tables["DATA"].Columns.Add("CenaV", typeof(double));
            ds.Tables["DATA"].Columns.Add("CenaR", typeof(double));

            bs.DataSource = ds;
            bs.DataMember = "DATA";

            dg1.DataSource = bs;

            bs.Sort = "lineno";

            CenaVhod();//рассчитываем входящую цену за 1 единицу товара

            CenaRealiz();//получаем цену реализации

            Cursor = Cursors.Default;

            if (idtov != null)//устанавливаем курсор на искомую позицию товара
            {
                DataGridViewCellStyle dgcs1 = new DataGridViewCellStyle();
                dgcs1.BackColor = Color.Beige;


                int totalR = dg1.Rows.Count;
                int x;
                for (x=0;x<totalR;x++)
                {
                    if (idtov == dg1.Rows[x].Cells["id"].Value.ToString())
                    {
                        dg1.Rows[x].Selected = true;
                        dg1.FirstDisplayedScrollingRowIndex = x;
                        dg1.Rows[x].DefaultCellStyle = dgcs1;
                    }
                }
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CenaRealiz()
        {
            foreach (DataRow dr in ds.Tables["DATA"].Rows)
            {
                string idTNr = dr["id"].ToString();
                foreach(DataRow drR in Global.mainDataSet.Tables["REMAINS"].Rows)
                {
                    if (idTNr== drR["idtov"].ToString())
                    {
                        dr["CenaR"] = drR["Cena"];
                        break;
                    }
                }
            }
        }

        private void btnCreateCennik_Click(object sender, EventArgs e)
        {
                ProcessCennik();          
        }

        private void ProcessCennik()
        {


            int x = 0;
            DateTime dataTN = Convert.ToDateTime(lblDataTN.Text);
            string NomerTN = lblNomerTN.Text;

            //Формируем ценники по всем позициям
            foreach(DataGridViewRow drw in dg1.Rows)
            {
                object val = drw.Cells["ColSelect"].Value;

                if (val != null)
                {
                    bool v = Convert.ToBoolean(val);
                    if (v == true)
                    {
                        cennik.CreateCennik(drw.Cells["ID"].Value.ToString(), dataTN, NomerTN, false);
                        x++;
                    }
                }

            }

            if (x == 0)
            {
                DataRow dr;
                dr = currentRow;

                //Находим код и цену товара по ID
                string idtov = dr["id"].ToString();
                CodeCena cc = new CodeCena();
                cc = cennik.CodeCena1C(idtov);

                //находим описание и QR код
                SCODE sCODE = new SCODE();
                sCODE.Find(idtov, cc.Code);

                //cennik.AddRow(idtov, cc.Code, Convert.ToDateTime(lblDataTN.Text), lblNomerTN.Text, cc.Name, sCODE.row.Descr, cc.Cena, sCODE.row.SCODE);
                cennik.CreateCennik(idtov, dataTN, NomerTN, true);

            }
            else
            {
                frmAlert.ShowAlert("Ценники на выбранные позиции свормированы успушно.", "Информация о формировании ценника", frmInfoSales.EnmType.Success);
            }
        }


        public DataRow currentRow
        {
            get
            {
                int position = this.BindingContext[bs].Position;
                if (position > -1)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                foreach(DataGridViewRow drv in dg1.Rows)
                {
                    drv.Cells["ColSelect"].Value = true;
                }
            }
            else
            {
                foreach (DataGridViewRow drv in dg1.Rows)
                {
                    drv.Cells["ColSelect"].Value = false;
                }
            }
        }


    }
}
