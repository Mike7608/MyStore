﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using QRCoder;

namespace MyShop.Ostatki
{
    public partial class uscInfoTovar : UserControl
    {
        #region === КОНСТАНТЫ ===


        #endregion


        #region === ПЕРЕМЕННЫЕ ===

        InfoTovarForm1S info;
        string id = "";//000007524 - 5T1
        bool _panelIsOpen = true;
        Label lblGrafInfo = new Label();
        Chart chartGrafPrice = new Chart();
        public delegate void InfoTovarEvent();
        public event InfoTovarEvent Close;
        #endregion


        #region === СВОЙСТВА ===

        public string idtov
        {
            get { return id; }

        }


        public bool PanelsIsOpen
        {
            get { return _panelIsOpen; }
            set
            {
                _panelIsOpen = value;
            }
        }

        #endregion

        public uscInfoTovar()
        {
            InitializeComponent();

            Font defFont = new Font("Segoe UI", 9, FontStyle.Regular);

            //txtKod
            txtKod.Dock = DockStyle.Fill;
            txtKod.Font = defFont;
            panelKod.panelMain.Controls.Add(txtKod);

            //txtKratkName
            txtKratkName.Dock = DockStyle.Fill;
            txtKratkName.Font = defFont;
            panelKratkName.panelMain.Controls.Add(txtKratkName);

            //txtFullName
            txtFullName.Dock = DockStyle.Fill;
            txtFullName.Font = defFont;
            panelFullName.panelMain.Controls.Add(txtFullName);
            //panelFullName.IsOpenPanel = false;

            //dgPrice
            dgPrice.Dock = DockStyle.Fill;
            dgPrice.ReadOnly = true;
            panelPrice.panelMain.Controls.Add(dgPrice);

            //dgPost
            dgPost.Dock = DockStyle.Fill;
            dgPost.CellPainting += DgPost_CellPainting;
            panelPost.panelMain.Controls.Add(dgPost);

            panelPost.panelMain.Controls.Add(btnShowDocPost);
            btnShowDocPost.BringToFront();
            
            //QR код
            txtQR.Dock = DockStyle.Top;
            txtQR.Font = defFont;
            picQR.Location = new Point(76, 768);
            //picQR.Dock = DockStyle.Top;
            panelQR.panelMain.BorderStyle = BorderStyle.FixedSingle;
            panelQR.panelMain.Controls.Add(txtQR);
            panelQR.panelMain.Controls.Add(picQR);
            panelQR.panelMain.BackColor = SystemColors.Control;
            panelQR.IsOpen += PanelQR_IsOpen;

            //txtDescr
            txtDescr.Dock = DockStyle.Fill;
            txtDescr.Font = defFont;
            panelDescr.panelMain.Controls.Add(txtDescr);

            //lblGrafInfo
            lblGrafInfo.Height = 50;
            lblGrafInfo.Width = 170;
            lblGrafInfo.Text = "НЕДОСТАТОЧНО ДАННЫХ ДЛЯ ПОСТРОЕНИЯ ГРАФИКА";
            lblGrafInfo.AutoSize = false;
            lblGrafInfo.TextAlign = ContentAlignment.TopCenter;
            lblGrafInfo.ForeColor = Color.Gray;
            panelGrafPrice.Resize += PanelGrafPrice_Resize;
            panelGrafPrice.panelMain.Controls.Add(lblGrafInfo);
            panelGrafPrice.IsOpen += PanelGrafPrice_IsOpen;

            //chartGrafPrice
            chartGrafPrice.Series.Add("Цена");
            chartGrafPrice.ChartAreas.Add("cha1");
            chartGrafPrice.Series["Цена"].ChartArea = "cha1";
            chartGrafPrice.Series["Цена"].ChartType = SeriesChartType.Line;
            chartGrafPrice.Series["Цена"].XValueType = ChartValueType.Date;
            chartGrafPrice.Series["Цена"].YValueType = ChartValueType.Single;
            chartGrafPrice.Series["Цена"].Color = Color.Red;
            chartGrafPrice.Series["Цена"].BorderWidth = 2;
            chartGrafPrice.Palette = ChartColorPalette.Bright;
            chartGrafPrice.Dock = DockStyle.Fill;
            panelGrafPrice.panelMain.Controls.Add(chartGrafPrice);


        }

        private void PanelGrafPrice_IsOpen()
        {
            PanelGrafPrice_Resize(null, null);
        }

        private void PanelQR_IsOpen()
        {
            panelQR_Resize(null, null);
        }

        private void PanelGrafPrice_Resize(object sender, EventArgs e)
        {
            int x = (panelGrafPrice.panelMain.Location.X + panelGrafPrice.panelMain.Width - lblGrafInfo.Width) / 2;
            int y = (panelGrafPrice.panelMain.Location.Y + panelGrafPrice.panelMain.Height - lblGrafInfo.Height) / 2;
            lblGrafInfo.Location = new Point(x, y);
        }

        private void DgPost_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (dgPrice.Rows.Count > 0)
            {
                if (e.ColumnIndex == 2 && e.RowIndex >= 0 && dgPost[e.ColumnIndex, e.RowIndex].Selected)
                {
                    if (panelPost.IsOpenPanel)
                    {
                        btnShowDocPost.Visible = true;
                        btnShowDocPost.Height = e.CellBounds.Height - 1;
                        btnShowDocPost.Width = e.CellBounds.Height;
                        btnShowDocPost.Location = new Point(e.CellBounds.X + e.CellBounds.Width - btnShowDocPost.Width, e.CellBounds.Y);
                    }
                }
            }
            else
            {
                btnShowDocPost.Visible = false;
            }


        }

        private void SelectLastRow(DataGridView dg)
        {
            if (dg.Visible)
            {
                if (dg.Rows.Count > 0)
                {
                    int x = dg.Rows.Count - 1;
                    dg.FirstDisplayedScrollingRowIndex = x;
                    dg.Rows[x].Selected = true;
                }
            }

        }

        private void ShowPrice(string NameTov)//Таблица цен  и график изменения цены
        {
            DataTable dtCen;
            dtCen = info.ListPrice();
            dgPrice.DataSource = dtCen;

            lblGrafInfo.Visible = true;

            //panelGrafPrice.panelMain.Controls.Clear();
            panelGrafPrice.panelMain.BackColor = Color.White;
            panelGrafPrice.panelMain.BorderStyle = BorderStyle.FixedSingle;
            chartGrafPrice.Visible = false;



            //выводим график изменения цены
            if (dtCen.Rows.Count > 1)
            {
                chartGrafPrice.Series[0].Points.Clear();
                chartGrafPrice.Titles.Clear();
                chartGrafPrice.Titles.Add(NameTov);
                lblGrafInfo.Visible = false;
                foreach (DataRow dr in dtCen.Rows)
                {
                    chartGrafPrice.Series[0].Points.AddXY(dr["data"], dr["CenaR"]);
                }
                chartGrafPrice.Visible = true;
            }

        }


        private void ShowDescr()//Описание товара
        {
            string descr = info.Description();
            string Country = info.NameCountry();
            txtDescr.Text = descr;
            string strana = "Страна ввоза: ";
            if (string.IsNullOrEmpty(txtDescr.Text))
            {
                txtDescr.Text = strana + Country;
            }
            else
            {
                if (descr.Contains(strana))
                {
                    txtDescr.Text = descr;
                }
                else
                {
                    txtDescr.Text = descr + "\r\n" + strana + Country;
                }
            }

        }

        private void OpenTN()
        {
            if (dgPost.Rows.Count > 0)
            {
                string idTN;//id TN
                int index;

                index = dgPost.CurrentRow.Index;
                idTN = dgPost["iddoc", index].Value.ToString();

                frmTNpost fTn = new frmTNpost(idTN);
                fTn.idtov = idtov;
                fTn.ShowDialog();
            }

        }


        public void LoadData(string idt)
        {
            id = idt;

            if (!string.IsNullOrEmpty(idt))
            {            
                Cursor = Cursors.WaitCursor;
                //System.Threading.Thread t;
                //t = new System.Threading.Thread(Start);
                //t.Start();
                info = new InfoTovarForm1S(idtov);

                txtKod.Text = info.CODE_1C;
                txtKratkName.Text = info.ShortName;
                txtFullName.Text = info.FullName();
                dgPrice.AutoGenerateColumns = false;
                dgPost.AutoGenerateColumns = false;

                ShowPrice(info.ShortName);
                ShowDescr();

                txtQR.Text = info.QRCODE();
                dgPost.DataSource = info.ListTN();

                SelectLastRow(dgPost);
                SelectLastRow(dgPrice);

                Cursor = Cursors.Default;
            }
        }

        //private void Start()
        //{}

        public void Clear()
        {
            string def = "(нет данных)";
            txtKod.Text = def;
            txtKratkName.Text = def;
            txtFullName.Text = def;
            txtQR.Text = def;
            txtDescr.Text = def;
            dgPost.DataSource = null;
            dgPrice.DataSource = null;
            picQR.Image = null;
            chartGrafPrice.Visible = false;
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }


        private void btnShowDocPost_Click_1(object sender, EventArgs e)
        {
            OpenTN();
        }

        private void picPlus_Click(object sender, EventArgs e)
        {
            if (PanelsIsOpen==false)  //если все панели закрыты
            {
                //тогда открываем все панели и меняем значек
                panelDescr.IsOpenPanel = true;
                panelFullName.IsOpenPanel = true;
                panelGrafPrice.IsOpenPanel = true;
                panelKod.IsOpenPanel = true;
                panelKratkName.IsOpenPanel = true;
                panelPost.IsOpenPanel = true;
                panelPrice.IsOpenPanel = true;
                panelQR.IsOpenPanel = true;
                PanelsIsOpen = true;
                picPlus.Image= Properties.Resources.minus_w;
            }
            else //иначе все наоборот
            {
                panelDescr.IsOpenPanel = false;
                panelFullName.IsOpenPanel = false;
                panelGrafPrice.IsOpenPanel = false;
                panelKod.IsOpenPanel = false;
                panelKratkName.IsOpenPanel = false;
                panelPost.IsOpenPanel = false;
                panelPrice.IsOpenPanel = false;
                panelQR.IsOpenPanel = false;
                PanelsIsOpen = false;
                picPlus.Image = Properties.Resources.plus_w;
            }
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void txtQR_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtQR.Text))
            {
                QRCodeGenerator qg = new QRCodeGenerator();
                var mydata = qg.CreateQrCode(txtQR.Text, QRCodeGenerator.ECCLevel.H);
                var c = new QRCode(mydata);
                picQR.SizeMode = PictureBoxSizeMode.StretchImage;
                picQR.Image = c.GetGraphic(2);
            }
            else
            {
                picQR.Image = null;
                picQR.BackColor = Color.White;
            }
        }


        private void panelQR_Resize(object sender, EventArgs e)
        {
            picQR.Location = new Point((panelQR.panelMain.Width - picQR.Width) / 2, (panelQR.panelMain.Height - picQR.Height + txtQR.Height) / 2);
        }

        private void btnExit_Click_2(object sender, EventArgs e)
        {
            //Added?.Invoke();
            Close?.Invoke();
        }
    }
}
