﻿namespace MyShop
{
    partial class frmTNpost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDataTN = new System.Windows.Forms.Label();
            this.lblNomerTN = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblAdres = new System.Windows.Forms.Label();
            this.lblPostName1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblUNP = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnCreateCennik = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lineno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cena1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sum1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nds = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sum2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 100);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.lblDataTN);
            this.panel5.Controls.Add(this.lblNomerTN);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 59);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(800, 40);
            this.panel5.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Номер документа:";
            // 
            // lblDataTN
            // 
            this.lblDataTN.AutoSize = true;
            this.lblDataTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDataTN.Location = new System.Drawing.Point(412, 8);
            this.lblDataTN.Name = "lblDataTN";
            this.lblDataTN.Size = new System.Drawing.Size(100, 24);
            this.lblDataTN.TabIndex = 3;
            this.lblDataTN.Text = "01.01.2020";
            // 
            // lblNomerTN
            // 
            this.lblNomerTN.AutoSize = true;
            this.lblNomerTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNomerTN.Location = new System.Drawing.Point(126, 8);
            this.lblNomerTN.Name = "lblNomerTN";
            this.lblNomerTN.Size = new System.Drawing.Size(20, 24);
            this.lblNomerTN.TabIndex = 1;
            this.lblNomerTN.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(313, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Дата документа:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gold;
            this.panel3.Controls.Add(this.lblAdres);
            this.panel3.Controls.Add(this.lblPostName1);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(800, 59);
            this.panel3.TabIndex = 0;
            // 
            // lblAdres
            // 
            this.lblAdres.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblAdres.Location = new System.Drawing.Point(158, 33);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lblAdres.Size = new System.Drawing.Size(642, 26);
            this.lblAdres.TabIndex = 7;
            this.lblAdres.Text = "адрес";
            // 
            // lblPostName1
            // 
            this.lblPostName1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPostName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPostName1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPostName1.Location = new System.Drawing.Point(158, 0);
            this.lblPostName1.Name = "lblPostName1";
            this.lblPostName1.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.lblPostName1.Size = new System.Drawing.Size(642, 33);
            this.lblPostName1.TabIndex = 5;
            this.lblPostName1.Text = "Наименование поставщика";
            this.lblPostName1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lblUNP);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(158, 59);
            this.panel4.TabIndex = 6;
            // 
            // lblUNP
            // 
            this.lblUNP.AutoSize = true;
            this.lblUNP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUNP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblUNP.Location = new System.Drawing.Point(46, 29);
            this.lblUNP.Name = "lblUNP";
            this.lblUNP.Size = new System.Drawing.Size(109, 24);
            this.lblUNP.TabIndex = 9;
            this.lblUNP.Text = "000000000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(12, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "УНП:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(47, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Поставщик:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.btnCreateCennik);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 392);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 58);
            this.panel2.TabIndex = 1;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(35, 24);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(91, 17);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Выбрать всё";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Visible = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // btnCreateCennik
            // 
            this.btnCreateCennik.FlatAppearance.BorderSize = 2;
            this.btnCreateCennik.Location = new System.Drawing.Point(143, 16);
            this.btnCreateCennik.Name = "btnCreateCennik";
            this.btnCreateCennik.Size = new System.Drawing.Size(188, 30);
            this.btnCreateCennik.TabIndex = 1;
            this.btnCreateCennik.Text = "Сформировать ценник";
            this.btnCreateCennik.UseVisualStyleBackColor = true;
            this.btnCreateCennik.Visible = false;
            this.btnCreateCennik.Click += new System.EventHandler(this.btnCreateCennik_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnClose.FlatAppearance.BorderSize = 2;
            this.btnClose.Location = new System.Drawing.Point(684, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(93, 30);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "&Закрыть";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dg1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dg1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ColSelect,
            this.lineno,
            this.descr,
            this.kol,
            this.cena1,
            this.sum1,
            this.nds,
            this.sum2,
            this.CenaV,
            this.CenaR});
            this.dg1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg1.Location = new System.Drawing.Point(0, 100);
            this.dg1.MultiSelect = false;
            this.dg1.Name = "dg1";
            this.dg1.RowHeadersWidth = 30;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.Size = new System.Drawing.Size(800, 292);
            this.dg1.TabIndex = 2;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            // 
            // ColSelect
            // 
            this.ColSelect.FalseValue = "false";
            this.ColSelect.HeaderText = "";
            this.ColSelect.IndeterminateValue = "";
            this.ColSelect.Name = "ColSelect";
            this.ColSelect.TrueValue = "true";
            this.ColSelect.Visible = false;
            this.ColSelect.Width = 30;
            // 
            // lineno
            // 
            this.lineno.DataPropertyName = "lineno";
            this.lineno.HeaderText = "Номер п/п";
            this.lineno.Name = "lineno";
            this.lineno.Width = 30;
            // 
            // descr
            // 
            this.descr.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.descr.DataPropertyName = "descr";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descr.DefaultCellStyle = dataGridViewCellStyle2;
            this.descr.HeaderText = "Наименование товара";
            this.descr.Name = "descr";
            // 
            // kol
            // 
            this.kol.DataPropertyName = "kol";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N3";
            dataGridViewCellStyle3.NullValue = null;
            this.kol.DefaultCellStyle = dataGridViewCellStyle3;
            this.kol.HeaderText = "Количество";
            this.kol.Name = "kol";
            this.kol.Width = 50;
            // 
            // cena1
            // 
            this.cena1.DataPropertyName = "cena1";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N2";
            dataGridViewCellStyle4.NullValue = null;
            this.cena1.DefaultCellStyle = dataGridViewCellStyle4;
            this.cena1.HeaderText = "Цена учётная";
            this.cena1.Name = "cena1";
            this.cena1.Width = 60;
            // 
            // sum1
            // 
            this.sum1.DataPropertyName = "sum1";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N2";
            dataGridViewCellStyle5.NullValue = null;
            this.sum1.DefaultCellStyle = dataGridViewCellStyle5;
            this.sum1.HeaderText = "Сумма учётная";
            this.sum1.Name = "sum1";
            this.sum1.Width = 80;
            // 
            // nds
            // 
            this.nds.DataPropertyName = "nds";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N2";
            dataGridViewCellStyle6.NullValue = null;
            this.nds.DefaultCellStyle = dataGridViewCellStyle6;
            this.nds.HeaderText = "НДС";
            this.nds.Name = "nds";
            this.nds.Width = 40;
            // 
            // sum2
            // 
            this.sum2.DataPropertyName = "sum2";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = null;
            this.sum2.DefaultCellStyle = dataGridViewCellStyle7;
            this.sum2.HeaderText = "Сумма с НДС";
            this.sum2.Name = "sum2";
            this.sum2.Width = 80;
            // 
            // CenaV
            // 
            this.CenaV.DataPropertyName = "CenaV";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle8.Format = "N2";
            dataGridViewCellStyle8.NullValue = "0";
            this.CenaV.DefaultCellStyle = dataGridViewCellStyle8;
            this.CenaV.HeaderText = "Цена (вход)";
            this.CenaV.Name = "CenaV";
            this.CenaV.Width = 60;
            // 
            // CenaR
            // 
            this.CenaR.DataPropertyName = "CenaR";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Honeydew;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle9.Format = "N2";
            this.CenaR.DefaultCellStyle = dataGridViewCellStyle9;
            this.CenaR.HeaderText = "Цена реализации";
            this.CenaR.Name = "CenaR";
            this.CenaR.Width = 60;
            // 
            // frmTNpost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dg1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTNpost";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Документ поступления";
            this.Load += new System.EventHandler(this.frmTNpost_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.Label lblPostName1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblDataTN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNomerTN;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.Label lblUNP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnClose;
        public System.Windows.Forms.Button btnCreateCennik;
        public System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColSelect;
        private System.Windows.Forms.DataGridViewTextBoxColumn lineno;
        private System.Windows.Forms.DataGridViewTextBoxColumn descr;
        private System.Windows.Forms.DataGridViewTextBoxColumn kol;
        private System.Windows.Forms.DataGridViewTextBoxColumn cena1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sum1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nds;
        private System.Windows.Forms.DataGridViewTextBoxColumn sum2;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaV;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaR;
    }
}