﻿namespace MyShop.Ostatki
{
    partial class frmJurnalPostuplenij
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmJurnalPostuplenij));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new MyShop.MyButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnFilterClear = new System.Windows.Forms.Button();
            this.findTextCena = new MyShop.FindTextCena();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.panelFind = new System.Windows.Forms.Panel();
            this.btnOpenTN = new MyShop.MyButton();
            this.controlPeriod1 = new Periods.ControlPeriod();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dg = new System.Windows.Forms.DataGridView();
            this.IDDOC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateTN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UNP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameContr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NoTN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SummNoNDS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SummaNDS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Summa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelTop.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.panelFind.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.btnExit);
            this.panelTop.Controls.Add(this.panel1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(947, 68);
            this.panelTop.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(78, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(374, 47);
            this.label2.TabIndex = 12;
            this.label2.Text = "Журнал поступлений";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DimGray;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = global::MyShop.Properties.Resources.arrow_left_w_24;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExit.Location = new System.Drawing.Point(3, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(52, 64);
            this.btnExit.TabIndex = 11;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnFilterClear);
            this.panel1.Controls.Add(this.findTextCena);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(467, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(480, 68);
            this.panel1.TabIndex = 10;
            // 
            // btnFilterClear
            // 
            this.btnFilterClear.BackColor = System.Drawing.Color.Transparent;
            this.btnFilterClear.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnFilterClear.FlatAppearance.BorderSize = 2;
            this.btnFilterClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilterClear.Image = ((System.Drawing.Image)(resources.GetObject("btnFilterClear.Image")));
            this.btnFilterClear.Location = new System.Drawing.Point(427, 19);
            this.btnFilterClear.Name = "btnFilterClear";
            this.btnFilterClear.Size = new System.Drawing.Size(35, 35);
            this.btnFilterClear.TabIndex = 1;
            this.btnFilterClear.UseVisualStyleBackColor = false;
            this.btnFilterClear.Click += new System.EventHandler(this.btnFilterClear_Click);
            // 
            // findTextCena
            // 
            this.findTextCena.BackColor = System.Drawing.Color.White;
            this.findTextCena.BorderColor = System.Drawing.Color.LightGray;
            this.findTextCena.BorederTickness = 2;
            this.findTextCena.CenaLenght = 0;
            this.findTextCena.FindTextBackColor = System.Drawing.Color.White;
            this.findTextCena.FindTextForeColor = System.Drawing.Color.Black;
            this.findTextCena.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findTextCena.ForeColor = System.Drawing.Color.Black;
            this.findTextCena.HelpTextCena = "Сумма сделки";
            this.findTextCena.HelpTextFind = "Поставщик или УНП или номер ТН";
            this.findTextCena.Location = new System.Drawing.Point(8, 19);
            this.findTextCena.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.findTextCena.Name = "findTextCena";
            this.findTextCena.Size = new System.Drawing.Size(418, 35);
            this.findTextCena.TabIndex = 0;
            this.findTextCena.TextCena = null;
            this.findTextCena.TextFind = null;
            this.findTextCena.TextLenght = 0;
            this.findTextCena.FindClick += new MyShop.FindTextCena.ButtonFindHandler(this.findTextCena_FindClick);
            this.findTextCena.FindKeyPress += new MyShop.FindTextCena.FindTextBoxKeyPress(this.findTextCena_FindKeyPress);
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelBottom.Controls.Add(this.panelFind);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 499);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(947, 74);
            this.panelBottom.TabIndex = 3;
            // 
            // panelFind
            // 
            this.panelFind.Controls.Add(this.btnOpenTN);
            this.panelFind.Controls.Add(this.controlPeriod1);
            this.panelFind.Controls.Add(this.lblTotal);
            this.panelFind.Controls.Add(this.label1);
            this.panelFind.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFind.Location = new System.Drawing.Point(0, 0);
            this.panelFind.Name = "panelFind";
            this.panelFind.Size = new System.Drawing.Size(947, 74);
            this.panelFind.TabIndex = 3;
            // 
            // btnOpenTN
            // 
            this.btnOpenTN.BackColor = System.Drawing.Color.DimGray;
            this.btnOpenTN.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnOpenTN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnOpenTN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnOpenTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpenTN.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenTN.ForeColor = System.Drawing.Color.White;
            this.btnOpenTN.Image = global::MyShop.Properties.Resources.icons8_файл_24;
            this.btnOpenTN.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnOpenTN.Location = new System.Drawing.Point(545, 4);
            this.btnOpenTN.Name = "btnOpenTN";
            this.btnOpenTN.Size = new System.Drawing.Size(57, 64);
            this.btnOpenTN.TabIndex = 3;
            this.btnOpenTN.Text = "Открыть ТН";
            this.btnOpenTN.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnOpenTN.UseVisualStyleBackColor = false;
            this.btnOpenTN.Click += new System.EventHandler(this.btnOpenTN_Click);
            // 
            // controlPeriod1
            // 
            this.controlPeriod1.ButtonBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.controlPeriod1.ButtonBorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.controlPeriod1.ButtonForeColor = System.Drawing.Color.White;
            this.controlPeriod1.CheckedBackColor = System.Drawing.SystemColors.Highlight;
            this.controlPeriod1.ControlBackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.controlPeriod1.DateEnd = new System.DateTime(2020, 12, 31, 23, 59, 59, 0);
            this.controlPeriod1.DateStart = new System.DateTime(2020, 12, 1, 0, 0, 0, 0);
            this.controlPeriod1.DefaultPeriodOnly = false;
            this.controlPeriod1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.controlPeriod1.Location = new System.Drawing.Point(12, 4);
            this.controlPeriod1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.controlPeriod1.Name = "controlPeriod1";
            this.controlPeriod1.PeriodDefault = Periods.ControlPeriod.DefaultPeriod.Month;
            this.controlPeriod1.Size = new System.Drawing.Size(360, 66);
            this.controlPeriod1.TabIndex = 2;
            this.controlPeriod1.TextBackColor = System.Drawing.Color.Gray;
            this.controlPeriod1.TextFont = new System.Drawing.Font("Segoe UI", 10F);
            this.controlPeriod1.TextForeColor = System.Drawing.Color.White;
            this.controlPeriod1.ChangPeriod += new Periods.ControlPeriod.PeriodHandler(this.controlPeriod1_ChangPeriod);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTotal.Location = new System.Drawing.Point(473, 3);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(19, 21);
            this.lblTotal.TabIndex = 1;
            this.lblTotal.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(392, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Всего записей:";
            // 
            // dg
            // 
            this.dg.AllowUserToAddRows = false;
            this.dg.AllowUserToDeleteRows = false;
            this.dg.AllowUserToOrderColumns = true;
            this.dg.BackgroundColor = System.Drawing.Color.White;
            this.dg.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dg.ColumnHeadersHeight = 24;
            this.dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDDOC,
            this.DateTN,
            this.UNP,
            this.NameContr,
            this.NoTN,
            this.SummNoNDS,
            this.SummaNDS,
            this.Summa});
            this.dg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg.Location = new System.Drawing.Point(0, 68);
            this.dg.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dg.MultiSelect = false;
            this.dg.Name = "dg";
            this.dg.ReadOnly = true;
            this.dg.RowTemplate.Height = 32;
            this.dg.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg.Size = new System.Drawing.Size(947, 431);
            this.dg.TabIndex = 4;
            this.dg.Paint += new System.Windows.Forms.PaintEventHandler(this.dg_Paint);
            this.dg.DoubleClick += new System.EventHandler(this.dg_DoubleClick);
            // 
            // IDDOC
            // 
            this.IDDOC.DataPropertyName = "IDDOC";
            this.IDDOC.HeaderText = "IDDOC";
            this.IDDOC.Name = "IDDOC";
            this.IDDOC.ReadOnly = true;
            this.IDDOC.Visible = false;
            // 
            // DateTN
            // 
            this.DateTN.DataPropertyName = "data";
            this.DateTN.HeaderText = "Дата ТН";
            this.DateTN.Name = "DateTN";
            this.DateTN.ReadOnly = true;
            this.DateTN.Width = 120;
            // 
            // UNP
            // 
            this.UNP.DataPropertyName = "UNP";
            this.UNP.HeaderText = "УНП";
            this.UNP.Name = "UNP";
            this.UNP.ReadOnly = true;
            this.UNP.Width = 130;
            // 
            // NameContr
            // 
            this.NameContr.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NameContr.DataPropertyName = "descr";
            this.NameContr.HeaderText = "Наименование поставщика";
            this.NameContr.Name = "NameContr";
            this.NameContr.ReadOnly = true;
            // 
            // NoTN
            // 
            this.NoTN.DataPropertyName = "NoTN";
            this.NoTN.HeaderText = "Номер ТН";
            this.NoTN.Name = "NoTN";
            this.NoTN.ReadOnly = true;
            // 
            // SummNoNDS
            // 
            this.SummNoNDS.DataPropertyName = "SummaNoNDS";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N2";
            dataGridViewCellStyle1.NullValue = null;
            this.SummNoNDS.DefaultCellStyle = dataGridViewCellStyle1;
            this.SummNoNDS.HeaderText = "Сумма без НДС";
            this.SummNoNDS.Name = "SummNoNDS";
            this.SummNoNDS.ReadOnly = true;
            this.SummNoNDS.Width = 120;
            // 
            // SummaNDS
            // 
            this.SummaNDS.DataPropertyName = "SummaNDS";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.SummaNDS.DefaultCellStyle = dataGridViewCellStyle2;
            this.SummaNDS.HeaderText = "Сумма НДС";
            this.SummaNDS.Name = "SummaNDS";
            this.SummaNDS.ReadOnly = true;
            // 
            // Summa
            // 
            this.Summa.DataPropertyName = "Summa";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.NullValue = null;
            this.Summa.DefaultCellStyle = dataGridViewCellStyle3;
            this.Summa.HeaderText = "Сумма с НДС";
            this.Summa.Name = "Summa";
            this.Summa.ReadOnly = true;
            this.Summa.Width = 150;
            // 
            // frmJurnalPostuplenij
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 573);
            this.Controls.Add(this.dg);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelTop);
            this.Name = "frmJurnalPostuplenij";
            this.Text = "Журнал поступлений";
            this.Load += new System.EventHandler(this.frmJurnalPostuplenij_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.panelFind.ResumeLayout(false);
            this.panelFind.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        public System.Windows.Forms.Panel panelBottom;
        public System.Windows.Forms.Panel panelFind;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.DataGridView dg;
        private Periods.ControlPeriod controlPeriod1;
        private MyButton btnOpenTN;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnFilterClear;
        private FindTextCena findTextCena;
        private MyButton btnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDDOC;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateTN;
        private System.Windows.Forms.DataGridViewTextBoxColumn UNP;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameContr;
        private System.Windows.Forms.DataGridViewTextBoxColumn NoTN;
        private System.Windows.Forms.DataGridViewTextBoxColumn SummNoNDS;
        private System.Windows.Forms.DataGridViewTextBoxColumn SummaNDS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Summa;
        private System.Windows.Forms.Label label2;
    }
}