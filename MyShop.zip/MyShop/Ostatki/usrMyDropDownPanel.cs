﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.Ostatki
{
    public partial class usrMyDropDownPanel : UserControl
    {
        #region === ПЕРЕМЕННЫЕ ===

        int defHeight;
        public int HeightCaption;
        bool panelIsOpen=true;
        Color _CaptionBackColor;
        Color _CaptionForeColor;

        #endregion

        #region === СВОЙСТВА ===
        public string GroupName
        {
            get
            {
                return lblName.Text;
            }
            set
            {
                lblName.Text = value;
            }
        }

        public bool IsOpenPanel
        {
            get { return panelIsOpen; }
            set
            {
                panelIsOpen = value;

                if (value)
                {
                    //открыта
                    OpenPanel();
                }
                else
                {
                    //закрыта
                    ClosePanel();
                }
            }
        }

        public Color CaptionBackColor
        {
            get { return _CaptionBackColor; }
            set 
            { 
                _CaptionBackColor = value;
                lblName.BackColor = value;
                lblPlus.BackColor = value;
            }
        }

        public Color CaptionForeColor
        {
            get { return _CaptionForeColor; }
            set 
            { 
                _CaptionForeColor = value;
                lblName.ForeColor = value;
            }
        }

        #endregion


        #region === СОБЫТИЯ ===

        public delegate void MyDropDownPanelEvent();
        public event MyDropDownPanelEvent IsClose;
        public event MyDropDownPanelEvent IsOpen;

        #endregion
        public usrMyDropDownPanel()
        {
            InitializeComponent();

            HeightCaption = lblName.Height;
            _CaptionBackColor = SystemColors.ControlDarkDark;
            _CaptionForeColor = Color.White;
            lblPlus.BackColor = _CaptionBackColor;
        }

        private void lblPlus_Click(object sender, EventArgs e)
        {
            if (this.Height > HeightCaption)
            {
                ClosePanel();
            }
            else
            {
                OpenPanel();
            }
        }

        private void usrMyDropDownPanel_Resize(object sender, EventArgs e)
        {
            if (this.Height > HeightCaption)
            {
                defHeight = this.Height;
            }
        }

        private void OpenPanel()
        {
            this.Height = defHeight;
            lblPlus.Image = Properties.Resources.minus_w;
            panelIsOpen = true;
            panelMain.Visible = true;
            panelLeft.Visible = true;
            IsOpen?.Invoke();
        }

        private void ClosePanel()
        {
            this.Height = HeightCaption;
            lblPlus.Image = Properties.Resources.plus_w;
            panelIsOpen = false;
            panelLeft.Visible = false;
            panelMain.Visible = false;
            IsClose?.Invoke();
        }
    }
}
