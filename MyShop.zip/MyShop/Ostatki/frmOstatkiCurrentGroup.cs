﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.Ostatki
{
    public partial class frmOstatkiCurrentGroup : frmOstatkiCurrent
    {
        //private Panel panelListGroup = new Panel();
        TreeView tv = new TreeView();
        DataSet ds = new DataSet();
        SQLmodule sql = new SQLmodule();
        DataTable dt = Global.mainDataSet.Tables["REMAINS"].Copy();
        Label lblGroupName = new Label();

        public frmOstatkiCurrentGroup()
        {
            //InitializeComponent();

            //panelListGroup.Dock = DockStyle.Left;
            //panelListGroup.Width = 300;
            //panelListGroup.BackColor = Color.DarkGray;

            label2.Text += " по группам";

            VisibleLeftPanel = true;
            tv.Dock = DockStyle.Fill;
            tv.TabIndex = 0;
            tv.FullRowSelect = true;
            tv.HideSelection = false;
            panelLeft.Controls.Add(tv);
            //panelListGroup.Controls.Add(tv);
            //this.Controls.Add(panelListGroup);
            sql.SQLselect("SELECT id, parentid, code, descr, isfolder, sp148 as idstran FROM _SC156 ORDER BY descr ASC",ds, "SprTovar");
            FillTreeView(tv, "0", ds.Tables["SprTovar"]);
            //panelFind.Visible = false;
            tv.AfterSelect += Tv_AfterSelect;
            this.Text += " (по группам)";

            lblGroupName.Location = new Point(31, 33);
            lblGroupName.ForeColor = Color.Gainsboro;
            Font fontGroupName = new Font("Segoe UI Semibold", 12, FontStyle.Regular);
            lblGroupName.Font = fontGroupName;
            lblGroupName.AutoSize = true;
            panelBottom.Controls.Add(lblGroupName);

        }


        private void Tv_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (ds.Tables["SprTovar"].Rows.Count > 0)
            {

                SelectTovar(tv.SelectedNode.Name);

            }
        }

        private void SelectTovar(string Find) //выбираем нужный товар по группе
        {

            dt.Clear();

            if (Find != null)
            {
                DataRow[] dr = ds.Tables["SprTovar"].Select("parentid='" + Find + "' and isfolder>1");

                foreach (DataRow drow in dr)
                {
                    SelectPosition(drow["id"].ToString());

                }
            }
            bs.DataSource = dt;

            lblGroupName.Text = tv.SelectedNode.Text;
            dt.TableName = lblGroupName.Text;
        }

        private void SelectPosition(string ID)
        {
            DataRow[] dr = Global.mainDataSet.Tables["Remains"].Select("idtov='" + ID + "'");
            foreach (DataRow d in dr)
            {
                dt.ImportRow(d);
            }
        }

        private TreeView FillTreeView(TreeView tvr, string Filtr, DataTable dt) //формируем дерево списка групп товаров
        {
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Select("parentid='" + Filtr + "' and isfolder=1"))
                {
                    TreeNode tn = new TreeNode();
                    tn.Text = dr["descr"].ToString();
                    tn.Name = dr["id"].ToString();
                    tvr.Nodes.Add(tn);
                    FillTreeSub(ref tn, dr["id"].ToString(), dt);
                }
            }
            return tvr;
        }

        private void FillTreeSub(ref TreeNode tn, string Filtr, DataTable dt)
        {
            DataRow[] dr = dt.Select("parentid='" + Filtr + "' and isfolder=1");
            foreach (DataRow drow in dr)
            {
                TreeNode tnt = new TreeNode();
                tnt.Text = drow["descr"].ToString();
                tnt.Name = drow["id"].ToString();
                tn.Nodes.Add(tnt);
                FillTreeSub(ref tnt, drow["id"].ToString(), dt);
            }

        }

        public override void BtnPrint_Click(object sender, EventArgs e)
        {
            PrintGroupOstatki ot = new PrintGroupOstatki(dt);
            FrmPrintPreview prn = new FrmPrintPreview(ot);
            prn.MdiParent = Global.mainForm;
            prn.Show();
        }

    }
}
