﻿
namespace MyShop.Ostatki
{
    partial class uscInfoTovar
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtQR = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtKratkName = new System.Windows.Forms.TextBox();
            this.txtKod = new System.Windows.Forms.TextBox();
            this.CenaR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cena0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtovC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iddocC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrice = new System.Windows.Forms.DataGridView();
            this.DataC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idpost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iddoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postav = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDescr = new System.Windows.Forms.TextBox();
            this.dgPost = new System.Windows.Forms.DataGridView();
            this.panelMain = new System.Windows.Forms.Panel();
            this.btnShowDocPost = new System.Windows.Forms.Button();
            this.panelDescr = new MyShop.Ostatki.usrMyDropDownPanel();
            this.picQR = new System.Windows.Forms.PictureBox();
            this.panelQR = new MyShop.Ostatki.usrMyDropDownPanel();
            this.panelPost = new MyShop.Ostatki.usrMyDropDownPanel();
            this.panelGrafPrice = new MyShop.Ostatki.usrMyDropDownPanel();
            this.panelPrice = new MyShop.Ostatki.usrMyDropDownPanel();
            this.panelFullName = new MyShop.Ostatki.usrMyDropDownPanel();
            this.panelKratkName = new MyShop.Ostatki.usrMyDropDownPanel();
            this.panelKod = new MyShop.Ostatki.usrMyDropDownPanel();
            this.lblNameControl = new System.Windows.Forms.Label();
            this.picPlus = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPost)).BeginInit();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picQR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlus)).BeginInit();
            this.SuspendLayout();
            // 
            // txtQR
            // 
            this.txtQR.BackColor = System.Drawing.Color.White;
            this.txtQR.Location = new System.Drawing.Point(26, 1479);
            this.txtQR.Name = "txtQR";
            this.txtQR.ReadOnly = true;
            this.txtQR.Size = new System.Drawing.Size(211, 22);
            this.txtQR.TabIndex = 15;
            this.txtQR.TextChanged += new System.EventHandler(this.txtQR_TextChanged);
            // 
            // txtFullName
            // 
            this.txtFullName.BackColor = System.Drawing.Color.White;
            this.txtFullName.Location = new System.Drawing.Point(24, 1210);
            this.txtFullName.Multiline = true;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.ReadOnly = true;
            this.txtFullName.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFullName.Size = new System.Drawing.Size(213, 80);
            this.txtFullName.TabIndex = 5;
            // 
            // txtKratkName
            // 
            this.txtKratkName.BackColor = System.Drawing.Color.White;
            this.txtKratkName.Location = new System.Drawing.Point(24, 1138);
            this.txtKratkName.Multiline = true;
            this.txtKratkName.Name = "txtKratkName";
            this.txtKratkName.ReadOnly = true;
            this.txtKratkName.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtKratkName.Size = new System.Drawing.Size(204, 45);
            this.txtKratkName.TabIndex = 3;
            // 
            // txtKod
            // 
            this.txtKod.BackColor = System.Drawing.Color.White;
            this.txtKod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKod.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtKod.Location = new System.Drawing.Point(24, 1091);
            this.txtKod.Name = "txtKod";
            this.txtKod.ReadOnly = true;
            this.txtKod.Size = new System.Drawing.Size(213, 23);
            this.txtKod.TabIndex = 1;
            // 
            // CenaR
            // 
            this.CenaR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CenaR.DataPropertyName = "CenaR";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.Format = "N2";
            this.CenaR.DefaultCellStyle = dataGridViewCellStyle1;
            this.CenaR.FillWeight = 81.47208F;
            this.CenaR.HeaderText = "Цена реализации";
            this.CenaR.Name = "CenaR";
            this.CenaR.ReadOnly = true;
            // 
            // Cena0
            // 
            this.Cena0.DataPropertyName = "Cena0";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N2";
            this.Cena0.DefaultCellStyle = dataGridViewCellStyle2;
            this.Cena0.FillWeight = 81.47208F;
            this.Cena0.HeaderText = "Цена поспупления (без НДС)";
            this.Cena0.Name = "Cena0";
            this.Cena0.ReadOnly = true;
            this.Cena0.Width = 70;
            // 
            // idtovC
            // 
            this.idtovC.DataPropertyName = "idtov";
            this.idtovC.HeaderText = "idtovC";
            this.idtovC.Name = "idtovC";
            this.idtovC.ReadOnly = true;
            this.idtovC.Visible = false;
            // 
            // iddocC
            // 
            this.iddocC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.iddocC.DataPropertyName = "iddoc";
            this.iddocC.HeaderText = "iddocC";
            this.iddocC.Name = "iddocC";
            this.iddocC.ReadOnly = true;
            this.iddocC.Visible = false;
            // 
            // dgPrice
            // 
            this.dgPrice.AllowUserToAddRows = false;
            this.dgPrice.AllowUserToDeleteRows = false;
            this.dgPrice.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgPrice.ColumnHeadersHeight = 25;
            this.dgPrice.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iddocC,
            this.idtovC,
            this.DataC,
            this.Cena0,
            this.CenaR});
            this.dgPrice.Location = new System.Drawing.Point(7, 1282);
            this.dgPrice.MultiSelect = false;
            this.dgPrice.Name = "dgPrice";
            this.dgPrice.ReadOnly = true;
            this.dgPrice.RowHeadersWidth = 10;
            this.dgPrice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPrice.Size = new System.Drawing.Size(230, 106);
            this.dgPrice.TabIndex = 17;
            // 
            // DataC
            // 
            this.DataC.DataPropertyName = "data";
            this.DataC.FillWeight = 137.0558F;
            this.DataC.HeaderText = "Дата установки цены";
            this.DataC.Name = "DataC";
            this.DataC.ReadOnly = true;
            this.DataC.Width = 70;
            // 
            // idpost
            // 
            this.idpost.DataPropertyName = "idPost";
            this.idpost.HeaderText = "idpost";
            this.idpost.Name = "idpost";
            this.idpost.ReadOnly = true;
            this.idpost.Visible = false;
            // 
            // iddoc
            // 
            this.iddoc.DataPropertyName = "iddoc";
            this.iddoc.HeaderText = "iddoc";
            this.iddoc.Name = "iddoc";
            this.iddoc.ReadOnly = true;
            this.iddoc.Visible = false;
            // 
            // Postav
            // 
            this.Postav.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Postav.DataPropertyName = "NamePost";
            this.Postav.HeaderText = "Поставщик";
            this.Postav.Name = "Postav";
            this.Postav.ReadOnly = true;
            // 
            // Nomer
            // 
            this.Nomer.DataPropertyName = "nomerTN";
            this.Nomer.HeaderText = "Номер";
            this.Nomer.Name = "Nomer";
            this.Nomer.ReadOnly = true;
            this.Nomer.Width = 70;
            // 
            // Data
            // 
            this.Data.DataPropertyName = "data";
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            this.Data.DefaultCellStyle = dataGridViewCellStyle3;
            this.Data.HeaderText = "Дата";
            this.Data.Name = "Data";
            this.Data.ReadOnly = true;
            this.Data.Width = 70;
            // 
            // txtDescr
            // 
            this.txtDescr.BackColor = System.Drawing.Color.White;
            this.txtDescr.Location = new System.Drawing.Point(18, 1230);
            this.txtDescr.Multiline = true;
            this.txtDescr.Name = "txtDescr";
            this.txtDescr.ReadOnly = true;
            this.txtDescr.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescr.Size = new System.Drawing.Size(213, 80);
            this.txtDescr.TabIndex = 20;
            // 
            // dgPost
            // 
            this.dgPost.AllowUserToAddRows = false;
            this.dgPost.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgPost.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgPost.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgPost.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPost.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Data,
            this.Nomer,
            this.Postav,
            this.iddoc,
            this.idpost});
            this.dgPost.Location = new System.Drawing.Point(41, 1364);
            this.dgPost.MultiSelect = false;
            this.dgPost.Name = "dgPost";
            this.dgPost.ReadOnly = true;
            this.dgPost.RowHeadersWidth = 10;
            this.dgPost.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPost.Size = new System.Drawing.Size(204, 109);
            this.dgPost.TabIndex = 18;
            // 
            // panelMain
            // 
            this.panelMain.AutoScroll = true;
            this.panelMain.Controls.Add(this.btnShowDocPost);
            this.panelMain.Controls.Add(this.txtDescr);
            this.panelMain.Controls.Add(this.panelDescr);
            this.panelMain.Controls.Add(this.dgPost);
            this.panelMain.Controls.Add(this.dgPrice);
            this.panelMain.Controls.Add(this.picQR);
            this.panelMain.Controls.Add(this.txtQR);
            this.panelMain.Controls.Add(this.panelQR);
            this.panelMain.Controls.Add(this.panelPost);
            this.panelMain.Controls.Add(this.panelGrafPrice);
            this.panelMain.Controls.Add(this.panelPrice);
            this.panelMain.Controls.Add(this.txtFullName);
            this.panelMain.Controls.Add(this.panelFullName);
            this.panelMain.Controls.Add(this.txtKratkName);
            this.panelMain.Controls.Add(this.panelKratkName);
            this.panelMain.Controls.Add(this.txtKod);
            this.panelMain.Controls.Add(this.panelKod);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 23);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(309, 742);
            this.panelMain.TabIndex = 20;
            // 
            // btnShowDocPost
            // 
            this.btnShowDocPost.BackColor = System.Drawing.SystemColors.Control;
            this.btnShowDocPost.FlatAppearance.BorderSize = 0;
            this.btnShowDocPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnShowDocPost.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnShowDocPost.Location = new System.Drawing.Point(102, 1338);
            this.btnShowDocPost.Margin = new System.Windows.Forms.Padding(0);
            this.btnShowDocPost.Name = "btnShowDocPost";
            this.btnShowDocPost.Size = new System.Drawing.Size(25, 23);
            this.btnShowDocPost.TabIndex = 21;
            this.btnShowDocPost.Text = "...";
            this.btnShowDocPost.UseVisualStyleBackColor = false;
            this.btnShowDocPost.Visible = false;
            this.btnShowDocPost.Click += new System.EventHandler(this.btnShowDocPost_Click_1);
            // 
            // panelDescr
            // 
            this.panelDescr.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelDescr.CaptionForeColor = System.Drawing.Color.White;
            this.panelDescr.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDescr.GroupName = "Описание";
            this.panelDescr.IsOpenPanel = true;
            this.panelDescr.Location = new System.Drawing.Point(0, 886);
            this.panelDescr.Name = "panelDescr";
            this.panelDescr.Size = new System.Drawing.Size(292, 170);
            this.panelDescr.TabIndex = 19;
            // 
            // picQR
            // 
            this.picQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picQR.Location = new System.Drawing.Point(83, 1505);
            this.picQR.Name = "picQR";
            this.picQR.Size = new System.Drawing.Size(110, 110);
            this.picQR.TabIndex = 16;
            this.picQR.TabStop = false;
            // 
            // panelQR
            // 
            this.panelQR.BackColor = System.Drawing.SystemColors.Control;
            this.panelQR.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelQR.CaptionForeColor = System.Drawing.Color.White;
            this.panelQR.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelQR.GroupName = "QR код";
            this.panelQR.IsOpenPanel = true;
            this.panelQR.Location = new System.Drawing.Point(0, 704);
            this.panelQR.Name = "panelQR";
            this.panelQR.Size = new System.Drawing.Size(292, 182);
            this.panelQR.TabIndex = 14;
            this.panelQR.Resize += new System.EventHandler(this.panelQR_Resize);
            // 
            // panelPost
            // 
            this.panelPost.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelPost.CaptionForeColor = System.Drawing.Color.White;
            this.panelPost.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPost.GroupName = "Поставщик";
            this.panelPost.IsOpenPanel = true;
            this.panelPost.Location = new System.Drawing.Point(0, 565);
            this.panelPost.Name = "panelPost";
            this.panelPost.Size = new System.Drawing.Size(292, 139);
            this.panelPost.TabIndex = 12;
            // 
            // panelGrafPrice
            // 
            this.panelGrafPrice.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelGrafPrice.CaptionForeColor = System.Drawing.Color.White;
            this.panelGrafPrice.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelGrafPrice.GroupName = "График изменения цены";
            this.panelGrafPrice.IsOpenPanel = true;
            this.panelGrafPrice.Location = new System.Drawing.Point(0, 362);
            this.panelGrafPrice.Name = "panelGrafPrice";
            this.panelGrafPrice.Size = new System.Drawing.Size(292, 203);
            this.panelGrafPrice.TabIndex = 8;
            // 
            // panelPrice
            // 
            this.panelPrice.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelPrice.CaptionForeColor = System.Drawing.Color.White;
            this.panelPrice.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPrice.GroupName = "Цена";
            this.panelPrice.IsOpenPanel = true;
            this.panelPrice.Location = new System.Drawing.Point(0, 223);
            this.panelPrice.Name = "panelPrice";
            this.panelPrice.Size = new System.Drawing.Size(292, 139);
            this.panelPrice.TabIndex = 6;
            // 
            // panelFullName
            // 
            this.panelFullName.BackColor = System.Drawing.SystemColors.Control;
            this.panelFullName.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelFullName.CaptionForeColor = System.Drawing.Color.White;
            this.panelFullName.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFullName.GroupName = "Полное наименование";
            this.panelFullName.IsOpenPanel = true;
            this.panelFullName.Location = new System.Drawing.Point(0, 110);
            this.panelFullName.Name = "panelFullName";
            this.panelFullName.Size = new System.Drawing.Size(292, 113);
            this.panelFullName.TabIndex = 4;
            // 
            // panelKratkName
            // 
            this.panelKratkName.BackColor = System.Drawing.SystemColors.Control;
            this.panelKratkName.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelKratkName.CaptionForeColor = System.Drawing.Color.White;
            this.panelKratkName.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelKratkName.GroupName = "Краткое наименование";
            this.panelKratkName.IsOpenPanel = true;
            this.panelKratkName.Location = new System.Drawing.Point(0, 42);
            this.panelKratkName.Name = "panelKratkName";
            this.panelKratkName.Size = new System.Drawing.Size(292, 68);
            this.panelKratkName.TabIndex = 2;
            // 
            // panelKod
            // 
            this.panelKod.BackColor = System.Drawing.SystemColors.Control;
            this.panelKod.CaptionBackColor = System.Drawing.Color.SteelBlue;
            this.panelKod.CaptionForeColor = System.Drawing.Color.White;
            this.panelKod.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelKod.GroupName = "Код товара";
            this.panelKod.IsOpenPanel = true;
            this.panelKod.Location = new System.Drawing.Point(0, 0);
            this.panelKod.Name = "panelKod";
            this.panelKod.Size = new System.Drawing.Size(292, 42);
            this.panelKod.TabIndex = 0;
            // 
            // lblNameControl
            // 
            this.lblNameControl.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblNameControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNameControl.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNameControl.ForeColor = System.Drawing.Color.White;
            this.lblNameControl.Location = new System.Drawing.Point(0, 0);
            this.lblNameControl.Margin = new System.Windows.Forms.Padding(0);
            this.lblNameControl.Name = "lblNameControl";
            this.lblNameControl.Size = new System.Drawing.Size(309, 23);
            this.lblNameControl.TabIndex = 19;
            this.lblNameControl.Text = "ИНФОРМАЦИЯ О ТОВАРЕ";
            this.lblNameControl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picPlus
            // 
            this.picPlus.BackColor = System.Drawing.SystemColors.HotTrack;
            this.picPlus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picPlus.Image = global::MyShop.Properties.Resources.minus_w;
            this.picPlus.Location = new System.Drawing.Point(5, 7);
            this.picPlus.Name = "picPlus";
            this.picPlus.Size = new System.Drawing.Size(10, 10);
            this.picPlus.TabIndex = 22;
            this.picPlus.TabStop = false;
            this.picPlus.Click += new System.EventHandler(this.picPlus_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnExit.BackgroundImage = global::MyShop.Properties.Resources.icons8_умножение_24;
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Location = new System.Drawing.Point(289, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(14, 14);
            this.btnExit.TabIndex = 23;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_2);
            // 
            // uscInfoTovar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.picPlus);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.lblNameControl);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "uscInfoTovar";
            this.Size = new System.Drawing.Size(309, 765);
            ((System.ComponentModel.ISupportInitialize)(this.dgPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPost)).EndInit();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picQR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlus)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox picQR;
        private System.Windows.Forms.TextBox txtQR;
        private usrMyDropDownPanel panelQR;
        private usrMyDropDownPanel panelPost;

        private usrMyDropDownPanel panelGrafPrice;
        private usrMyDropDownPanel panelPrice;
        private System.Windows.Forms.TextBox txtFullName;
        private usrMyDropDownPanel panelFullName;
        private System.Windows.Forms.TextBox txtKratkName;
        private usrMyDropDownPanel panelKratkName;
        private System.Windows.Forms.TextBox txtKod;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaR;
        private usrMyDropDownPanel panelKod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cena0;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtovC;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddocC;
        private System.Windows.Forms.DataGridView dgPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataC;
        private System.Windows.Forms.DataGridViewTextBoxColumn idpost;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postav;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.TextBox txtDescr;
        private usrMyDropDownPanel panelDescr;
        private System.Windows.Forms.DataGridView dgPost;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button btnShowDocPost;
        private System.Windows.Forms.Label lblNameControl;
        private System.Windows.Forms.PictureBox picPlus;
        private System.Windows.Forms.Button btnExit;
    }
}
