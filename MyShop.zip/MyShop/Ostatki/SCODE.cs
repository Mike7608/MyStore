﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace MyShop
{        


    class SCODE
    {
        SqlConnection conn;
        public Row row;

        public SCODE()
        {
            conn = new SqlConnection(Global.SqlConnectionString);
            row = new Row();
        }


        public Row Find(string idtov, string CODE)
        {

            conn.Open();
            string SQLstr;
            SQLstr = string.Format("SELECT ID, idtov, code, scode, descr FROM CODES WHERE idtov='{0}' AND code='{1}'", idtov, CODE);

            SqlCommand cmdSQ = new SqlCommand(SQLstr, conn);
            SqlDataReader dr1 = cmdSQ.ExecuteReader();

            while (dr1.Read())
            {
                ReadSingleRow(dr1, row);
            }
            conn.Close();


            return row;

        }

        public void Update(Row c)
        {
                conn.Open();
                string SQLstr;
                SQLstr = string.Format("UPDATE CODES SET scode='{0}', data='{3}' WHERE idtov='{1}' AND code='{2}';", c.SCODE, c.IDTOV, c.CODE, DateTime.Now);
                SqlCommand cmdSQ = new SqlCommand(SQLstr, conn);
                cmdSQ.ExecuteReader();
                conn.Close();
        }

        public void UpdateDescr(string descr)
        {
            conn.Open();
            string SQLstr;
            SQLstr = string.Format("UPDATE CODES SET data='{2}', descr='{3}' WHERE idtov='{0}' AND code='{1}';",  row.IDTOV, row.CODE, DateTime.Now, descr);
            SqlCommand cmdSQ = new SqlCommand(SQLstr, conn);
            cmdSQ.ExecuteReader();
            conn.Close();
        }

        public void InsertDescr(string descr, string idtov, string code)
        {
            conn.Open();
            string SQLstr;
            SQLstr = string.Format("INSERT INTO CODES (idtov, code, descr, data) VALUES ('{0}', '{1}', '{2}', '{3}');", idtov, code, descr, DateTime.Now);
            SqlCommand cmdSQ = new SqlCommand(SQLstr, conn);
            cmdSQ.ExecuteReader();
            conn.Close();
        }

        public void Insert(Row c)
        {
            conn.Open();
            string SQLstr;
            SQLstr = string.Format("INSERT INTO CODES (idtov, code, scode, data) VALUES ('{0}','{1}','{2}', '{3}');", c.IDTOV, c.CODE, c.SCODE, DateTime.Now);

            SqlCommand cmdSQ = new SqlCommand(SQLstr, conn);
            cmdSQ.ExecuteReader();
            conn.Close();
        }

        private  void ReadSingleRow(IDataRecord record, Row c)
        {
            c.ID = Convert.ToInt32(record[0]);
            c.IDTOV = record[1].ToString();
            c.CODE = record[2].ToString();
            c.SCODE = record[3].ToString();
            c.Descr = record[4].ToString();
        }

    }

    class Row
    {
        public int ID;
        public string IDTOV;
        public string CODE;
        public string SCODE;
        public string Descr;

        public Row()
        {
            ID = 0;
            IDTOV = null;
            CODE = null;
            SCODE = null;
            Descr = null;
        }
    }

}
