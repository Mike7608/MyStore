﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Globalization;
using System.Data.SqlClient;
using System.Data.Common;

namespace MyShop
{

    /// <summary>
    /// Остатки товаров по 1С бухгалтерия 7.7
    /// </summary>
    class Remains
    {
        #region ===ПЕРЕМЕННЫЕ===

        SQLmodule sql = new SQLmodule();
        Settings set = new Settings();
        string SQLconn;
        public delegate void RemainsEvent();
        DataSet ds;
        DataTable dt;

        /// <summary>
        /// Событие возникающее после успешного получения остатков
        /// </summary>
        public event RemainsEvent Added;

        public event RemainsEvent NoAdded;
        #endregion

        public Remains()//инициализация
        {
            SQLconn = set.SQLconnectionString;
            ds = new DataSet();
        }


        public void Start(string date, char K, string accid)
        {

            sql.SQLselect($"SELECT _SC156.ID AS idtov, _SC156.CODE, _SC156.DESCR AS NameTovar, (CONVERT(float, _1SBKTTL.OBDT1) + CONVERT(float, _1SBKTTL.OBDT2) + CONVERT(float, _1SBKTTL.OBDT3) + CONVERT(float, _1SBKTTL.SD)) - (CONVERT(float, _1SBKTTL.OBKT1) + CONVERT(float, _1SBKTTL.OBKT2) + CONVERT(float, _1SBKTTL.OBKT3)) AS kol  FROM  _1SBKTTL INNER JOIN _SC156 ON _1SBKTTL.SC0 = _SC156.ID WHERE(_1SBKTTL.ACCID='{accid}' AND _1SBKTTL.KIND = '{K}') AND DATE = '{date}' ORDER BY _1SBKTTL.DATE", Global.mainDataSet, "REMAINS");

            dt = Global.mainDataSet.Tables["REMAINS"];

            DeleteZero("kol");// удаляем товары с нулевыми остатками

            dt.Columns.Add("Cena", typeof(double));
            dt.Columns.Add("Cena0", typeof(double));
            dt.Columns.Add("Date", typeof(DateTime));
            dt.Columns.Add("Kurs", typeof(float));

            //***старый запрос*** --- SELECT [SP48380] as idtov, [SP48384] as Cena FROM [_DT48386]
            sql.SQLselect("SELECT   _SC40814.Parentext as idtov, CONVERT(float, _1SCONST.VALUE) as Cena, date FROM  _1SCONST INNER JOIN  _SC40814 ON _1SCONST.OBJID = _SC40814.ID WHERE _1SCONST.id = 'VHM' ORDER BY DATE ASC; ", ds, "Cena");

            sql.SQLselect("SELECT [SP11179] as idtov, [SP11180] as kol, [SP11186] as Summa0, (SP11186 / SP11180) as Cena0 FROM [_DT11188]", ds, "Cena0");

            sql.SQLselect("SELECT * from Currency order by date ASC", ds, "Currency");

            CenyToReamains(dt);// подставляем цены

            ds.Clear();

            //создаем первичный ключ
            var keys = new DataColumn[1];
            keys[0] = dt.Columns["idtov"];
            dt.PrimaryKey = keys;

            Added?.Invoke();

        }

        private void DeleteZero(string ColumnName)
        {
            foreach (DataRow dr in dt.Rows)
            {
                if (double.Parse(dr[ColumnName].ToString()) <= 0)
                {
                    dr.Delete();
                }
            }
            dt.AcceptChanges();
        }


        private void CenyToReamains(DataTable dt)
        {
            foreach (DataRow dr in dt.Rows)
            {
                dr.BeginEdit();
                string idtov = dr["idtov"].ToString();
                CenaDate c = Cena_Date(idtov, ds.Tables["Cena"]);

                dr["Cena"] = c.cena;
                dr["Cena0"] = Cena0(idtov, ds.Tables["Cena0"]);
                dr["Date"] = c.date;
                dr["Kurs"] = Kurs(c.date);
                dr.EndEdit();
            }
        }

        private float Kurs(DateTime date)
        {
            //CurrencySQL currencySQL = new CurrencySQL(SQLconn);
            //CurrencySQL.RateCurrency rateCurrency;
            //rateCurrency = currencySQL.Kurs("USD", date);

            //return rateCurrency.Rate;

            float a=0;

            DataRow[] dr = ds.Tables["Currency"].Select($"date='{date}'");

            if (dr.Length > 0)
            {
                a = Convert.ToSingle(dr[0]["Rate"]);
            }

            return a;
        }

        private CenaDate Cena_Date(string idtov, DataTable dt)
        {
            CenaDate c= new CenaDate();
            
            DataRow[] dr = dt.Select($"idtov='{idtov}'");
            int count = dr.Length;

            if (count > 0)
            {
                c.cena = double.Parse(dr[count - 1]["Cena"].ToString());
                c.date = DateTime.Parse(dr[count - 1]["date"].ToString());
            }

            return c;
        }

        class CenaDate
        {
            public DateTime date { get; set; }
            public double cena { get; set; }
        }

        private double Cena0(string idtov, DataTable dt)
        {
            double cena = 0;
            DataRow[] dr = dt.Select($"idtov='{idtov}'");
            int count = dr.Length;
            if (count > 0)
            {
                cena = double.Parse(dr[count - 1]["Cena0"].ToString());
            }

            return cena;
        }


        /// <summary>
        /// Процедура создает таблицу REMAINS с остатками на заданную дату в базе данных SQL
        /// </summary>
        /// <param name="kind"></param>
        /// <param name="DATE"></param>
        public void LoadData()//LoadData(string accid = "2Q", string kind = "3", string DATE = "01/10/2020")
        {
            //ПРОВЕРКА ДАННЫХ НА НАЛИЧИЕ
            bool val = CheckTable();


            DateTime DATE = set.WorkPeriod[0];

            if (val == true)
            {
                Global.mainDataSet.Reset();//перед загрузкой данных очищаем DataSet

                string Dt = DATE.Day.ToString() + "/" + DATE.Month.ToString() + "/" + DATE.Year.ToString();
                Start(Dt, '3', "2Q");
            }
            else
            {
                NoAdded?.Invoke();
                throw new Exception("Отсутствуют данные для работы программы. Произведите импорт данных.");

            }

        }


        private bool CheckTable()
        {
            bool val = false;
            string[] list = set.ListTableDBF;
            int x = 0;
            foreach (string s in list)
            {
                string tmp = "_" + s;
                val = sql.IsExistingTable(tmp);
                if (val == true) { x++; }
            }
            if (x == list.Length) { val = true; } else { val = false; }
            return val;
        }



    }
}
