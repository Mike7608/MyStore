﻿namespace MyShop
{
    partial class FrmDataOfTovar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabInfo = new System.Windows.Forms.TabControl();
            this.tabName = new System.Windows.Forms.TabPage();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtNameTovar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabDescr = new System.Windows.Forms.TabPage();
            this.txtDescr = new System.Windows.Forms.TextBox();
            this.tabCeny = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dgCeny = new System.Windows.Forms.DataGridView();
            this.iddocC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtovC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cena0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabDocIn = new System.Windows.Forms.TabPage();
            this.btnShowDocPost = new System.Windows.Forms.Button();
            this.dg1 = new System.Windows.Forms.DataGridView();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postav = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iddoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idpost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabQR = new System.Windows.Forms.TabPage();
            this.txtSCODE = new System.Windows.Forms.TextBox();
            this.lblSCODE = new System.Windows.Forms.Label();
            this.lblCODE = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tabInfo.SuspendLayout();
            this.tabName.SuspendLayout();
            this.tabDescr.SuspendLayout();
            this.tabCeny.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCeny)).BeginInit();
            this.tabDocIn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).BeginInit();
            this.tabQR.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabInfo);
            this.groupBox1.Controls.Add(this.lblCODE);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(460, 266);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Информация о товаре:";
            // 
            // tabInfo
            // 
            this.tabInfo.Controls.Add(this.tabName);
            this.tabInfo.Controls.Add(this.tabDescr);
            this.tabInfo.Controls.Add(this.tabCeny);
            this.tabInfo.Controls.Add(this.tabDocIn);
            this.tabInfo.Controls.Add(this.tabQR);
            this.tabInfo.Location = new System.Drawing.Point(9, 49);
            this.tabInfo.Name = "tabInfo";
            this.tabInfo.SelectedIndex = 0;
            this.tabInfo.Size = new System.Drawing.Size(445, 211);
            this.tabInfo.TabIndex = 14;
            this.tabInfo.SelectedIndexChanged += new System.EventHandler(this.tabInfo_SelectedIndexChanged);
            this.tabInfo.Click += new System.EventHandler(this.TabInfo_Click);
            // 
            // tabName
            // 
            this.tabName.BackColor = System.Drawing.SystemColors.Window;
            this.tabName.Controls.Add(this.txtFullName);
            this.tabName.Controls.Add(this.txtNameTovar);
            this.tabName.Controls.Add(this.label2);
            this.tabName.Controls.Add(this.label6);
            this.tabName.Location = new System.Drawing.Point(4, 22);
            this.tabName.Name = "tabName";
            this.tabName.Padding = new System.Windows.Forms.Padding(3);
            this.tabName.Size = new System.Drawing.Size(437, 185);
            this.tabName.TabIndex = 0;
            this.tabName.Text = "Наименование";
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(64, 61);
            this.txtFullName.Multiline = true;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.ReadOnly = true;
            this.txtFullName.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFullName.Size = new System.Drawing.Size(363, 105);
            this.txtFullName.TabIndex = 15;
            // 
            // txtNameTovar
            // 
            this.txtNameTovar.Location = new System.Drawing.Point(64, 18);
            this.txtNameTovar.Name = "txtNameTovar";
            this.txtNameTovar.ReadOnly = true;
            this.txtNameTovar.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNameTovar.Size = new System.Drawing.Size(362, 20);
            this.txtNameTovar.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Краткое:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Полное:";
            // 
            // tabDescr
            // 
            this.tabDescr.BackColor = System.Drawing.SystemColors.Window;
            this.tabDescr.Controls.Add(this.txtDescr);
            this.tabDescr.Location = new System.Drawing.Point(4, 22);
            this.tabDescr.Name = "tabDescr";
            this.tabDescr.Padding = new System.Windows.Forms.Padding(3);
            this.tabDescr.Size = new System.Drawing.Size(437, 185);
            this.tabDescr.TabIndex = 1;
            this.tabDescr.Text = "Описание";
            // 
            // txtDescr
            // 
            this.txtDescr.Location = new System.Drawing.Point(6, 6);
            this.txtDescr.Multiline = true;
            this.txtDescr.Name = "txtDescr";
            this.txtDescr.ReadOnly = true;
            this.txtDescr.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescr.Size = new System.Drawing.Size(425, 173);
            this.txtDescr.TabIndex = 0;
            // 
            // tabCeny
            // 
            this.tabCeny.Controls.Add(this.chart1);
            this.tabCeny.Controls.Add(this.dgCeny);
            this.tabCeny.Location = new System.Drawing.Point(4, 22);
            this.tabCeny.Name = "tabCeny";
            this.tabCeny.Padding = new System.Windows.Forms.Padding(3);
            this.tabCeny.Size = new System.Drawing.Size(437, 185);
            this.tabCeny.TabIndex = 2;
            this.tabCeny.Text = "Цены";
            this.tabCeny.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            this.chart1.BorderlineColor = System.Drawing.Color.Black;
            this.chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea1.AxisX.ArrowStyle = System.Windows.Forms.DataVisualization.Charting.AxisArrowStyle.SharpTriangle;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea1.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            chartArea1.AxisX2.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.Gainsboro;
            chartArea1.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            chartArea1.AxisY2.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Location = new System.Drawing.Point(237, 3);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series1.BorderWidth = 2;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Color = System.Drawing.Color.Blue;
            series1.IsVisibleInLegend = false;
            series1.Legend = "Legend1";
            series1.Name = "Цена";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Single;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(197, 179);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // dgCeny
            // 
            this.dgCeny.AllowUserToAddRows = false;
            this.dgCeny.AllowUserToDeleteRows = false;
            this.dgCeny.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgCeny.ColumnHeadersHeight = 20;
            this.dgCeny.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iddocC,
            this.idtovC,
            this.DataC,
            this.Cena0,
            this.CenaR});
            this.dgCeny.Location = new System.Drawing.Point(3, 3);
            this.dgCeny.MultiSelect = false;
            this.dgCeny.Name = "dgCeny";
            this.dgCeny.ReadOnly = true;
            this.dgCeny.RowHeadersWidth = 10;
            this.dgCeny.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgCeny.Size = new System.Drawing.Size(235, 179);
            this.dgCeny.TabIndex = 0;
            // 
            // iddocC
            // 
            this.iddocC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.iddocC.DataPropertyName = "iddoc";
            this.iddocC.HeaderText = "iddocC";
            this.iddocC.Name = "iddocC";
            this.iddocC.ReadOnly = true;
            this.iddocC.Visible = false;
            // 
            // idtovC
            // 
            this.idtovC.DataPropertyName = "idtov";
            this.idtovC.HeaderText = "idtovC";
            this.idtovC.Name = "idtovC";
            this.idtovC.ReadOnly = true;
            this.idtovC.Visible = false;
            // 
            // DataC
            // 
            this.DataC.DataPropertyName = "data";
            this.DataC.FillWeight = 137.0558F;
            this.DataC.HeaderText = "Дата установки цены";
            this.DataC.Name = "DataC";
            this.DataC.ReadOnly = true;
            this.DataC.Width = 70;
            // 
            // Cena0
            // 
            this.Cena0.DataPropertyName = "Cena0";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N2";
            this.Cena0.DefaultCellStyle = dataGridViewCellStyle1;
            this.Cena0.FillWeight = 81.47208F;
            this.Cena0.HeaderText = "Цена поспупления (без НДС)";
            this.Cena0.Name = "Cena0";
            this.Cena0.ReadOnly = true;
            this.Cena0.Width = 70;
            // 
            // CenaR
            // 
            this.CenaR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CenaR.DataPropertyName = "CenaR";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.Format = "N2";
            this.CenaR.DefaultCellStyle = dataGridViewCellStyle2;
            this.CenaR.FillWeight = 81.47208F;
            this.CenaR.HeaderText = "Цена реализации";
            this.CenaR.Name = "CenaR";
            this.CenaR.ReadOnly = true;
            // 
            // tabDocIn
            // 
            this.tabDocIn.Controls.Add(this.btnShowDocPost);
            this.tabDocIn.Controls.Add(this.dg1);
            this.tabDocIn.Location = new System.Drawing.Point(4, 22);
            this.tabDocIn.Name = "tabDocIn";
            this.tabDocIn.Padding = new System.Windows.Forms.Padding(3);
            this.tabDocIn.Size = new System.Drawing.Size(437, 185);
            this.tabDocIn.TabIndex = 3;
            this.tabDocIn.Text = "Док. поступления";
            this.tabDocIn.UseVisualStyleBackColor = true;
            // 
            // btnShowDocPost
            // 
            this.btnShowDocPost.BackColor = System.Drawing.SystemColors.Control;
            this.btnShowDocPost.FlatAppearance.BorderSize = 0;
            this.btnShowDocPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnShowDocPost.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnShowDocPost.Location = new System.Drawing.Point(287, 81);
            this.btnShowDocPost.Margin = new System.Windows.Forms.Padding(0);
            this.btnShowDocPost.Name = "btnShowDocPost";
            this.btnShowDocPost.Size = new System.Drawing.Size(25, 23);
            this.btnShowDocPost.TabIndex = 12;
            this.btnShowDocPost.Text = "...";
            this.btnShowDocPost.UseVisualStyleBackColor = false;
            this.btnShowDocPost.Visible = false;
            this.btnShowDocPost.Click += new System.EventHandler(this.btnShowDocPost_Click);
            // 
            // dg1
            // 
            this.dg1.AllowUserToAddRows = false;
            this.dg1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dg1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dg1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dg1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Data,
            this.Nomer,
            this.Postav,
            this.iddoc,
            this.idpost});
            this.dg1.Location = new System.Drawing.Point(3, 3);
            this.dg1.MultiSelect = false;
            this.dg1.Name = "dg1";
            this.dg1.ReadOnly = true;
            this.dg1.RowHeadersWidth = 30;
            this.dg1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg1.Size = new System.Drawing.Size(431, 176);
            this.dg1.TabIndex = 11;
            this.dg1.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dg1_CellPainting);
            this.dg1.DoubleClick += new System.EventHandler(this.dg1_DoubleClick_1);
            // 
            // Data
            // 
            this.Data.DataPropertyName = "data";
            dataGridViewCellStyle4.Format = "d";
            dataGridViewCellStyle4.NullValue = null;
            this.Data.DefaultCellStyle = dataGridViewCellStyle4;
            this.Data.HeaderText = "Дата";
            this.Data.Name = "Data";
            this.Data.ReadOnly = true;
            this.Data.Width = 80;
            // 
            // Nomer
            // 
            this.Nomer.DataPropertyName = "nomerTN";
            this.Nomer.HeaderText = "Номер";
            this.Nomer.Name = "Nomer";
            this.Nomer.ReadOnly = true;
            this.Nomer.Width = 80;
            // 
            // Postav
            // 
            this.Postav.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Postav.DataPropertyName = "NamePost";
            this.Postav.HeaderText = "Поставщик";
            this.Postav.Name = "Postav";
            this.Postav.ReadOnly = true;
            // 
            // iddoc
            // 
            this.iddoc.DataPropertyName = "iddoc";
            this.iddoc.HeaderText = "iddoc";
            this.iddoc.Name = "iddoc";
            this.iddoc.ReadOnly = true;
            this.iddoc.Visible = false;
            // 
            // idpost
            // 
            this.idpost.DataPropertyName = "idPost";
            this.idpost.HeaderText = "idpost";
            this.idpost.Name = "idpost";
            this.idpost.ReadOnly = true;
            this.idpost.Visible = false;
            // 
            // tabQR
            // 
            this.tabQR.Controls.Add(this.txtSCODE);
            this.tabQR.Controls.Add(this.lblSCODE);
            this.tabQR.Location = new System.Drawing.Point(4, 22);
            this.tabQR.Name = "tabQR";
            this.tabQR.Size = new System.Drawing.Size(437, 185);
            this.tabQR.TabIndex = 4;
            this.tabQR.Text = "QR код";
            this.tabQR.UseVisualStyleBackColor = true;
            // 
            // txtSCODE
            // 
            this.txtSCODE.Location = new System.Drawing.Point(64, 17);
            this.txtSCODE.Multiline = true;
            this.txtSCODE.Name = "txtSCODE";
            this.txtSCODE.ReadOnly = true;
            this.txtSCODE.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSCODE.Size = new System.Drawing.Size(362, 150);
            this.txtSCODE.TabIndex = 15;
            // 
            // lblSCODE
            // 
            this.lblSCODE.AutoSize = true;
            this.lblSCODE.Location = new System.Drawing.Point(10, 17);
            this.lblSCODE.Name = "lblSCODE";
            this.lblSCODE.Size = new System.Drawing.Size(47, 13);
            this.lblSCODE.TabIndex = 14;
            this.lblSCODE.Text = "QR код:";
            // 
            // lblCODE
            // 
            this.lblCODE.AutoSize = true;
            this.lblCODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCODE.Location = new System.Drawing.Point(355, 16);
            this.lblCODE.Name = "lblCODE";
            this.lblCODE.Size = new System.Drawing.Size(64, 16);
            this.lblCODE.TabIndex = 1;
            this.lblCODE.Text = "0000000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Код:";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(385, 293);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(87, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "&Закрыть";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // FrmDataOfTovar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(484, 326);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmDataOfTovar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Данные о товаре";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmDataOfTovar_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabInfo.ResumeLayout(false);
            this.tabName.ResumeLayout(false);
            this.tabName.PerformLayout();
            this.tabDescr.ResumeLayout(false);
            this.tabDescr.PerformLayout();
            this.tabCeny.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCeny)).EndInit();
            this.tabDocIn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg1)).EndInit();
            this.tabQR.ResumeLayout(false);
            this.tabQR.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCODE;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox txtNameTovar;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabName;
        private System.Windows.Forms.TabPage tabDescr;
        private System.Windows.Forms.TextBox txtDescr;
        private System.Windows.Forms.TabPage tabCeny;
        private System.Windows.Forms.DataGridView dgCeny;
        private System.Windows.Forms.TabPage tabDocIn;
        private System.Windows.Forms.DataGridView dg1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postav;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn idpost;
        private System.Windows.Forms.TabPage tabQR;
        public System.Windows.Forms.TextBox txtSCODE;
        private System.Windows.Forms.Label lblSCODE;
        private System.Windows.Forms.Button btnShowDocPost;
        public System.Windows.Forms.TabControl tabInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddocC;
        private System.Windows.Forms.DataGridViewTextBoxColumn idtovC;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cena0;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaR;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}