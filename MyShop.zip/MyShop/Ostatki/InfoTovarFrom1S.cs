﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace MyShop
{
    class InfoTovarForm1S
    {

        public DataSet dsDATA = new DataSet();

        #region "Свойства"
        private string idtov { set; get; }

        private string IDcountry;

        /// <summary>
        /// Код группы
        /// </summary>
        public string ParentID { get; }

        /// <summary>
        /// Код товара по базе 1С
        /// </summary>
        public string CODE_1C { get; }

        /// <summary>
        /// Краткое наименование товара
        /// </summary>
        public string ShortName { get; }

        /// <summary>
        /// Единица измерения
        /// </summary>
        public string UnitName { get; }


        #endregion

        string SQLcon;


        public InfoTovarForm1S(string IDtov)
        {
            Settings set = new Settings();
            SQLcon = set.SQLconnectionString;
            idtov = IDtov;

            ReadMainInfo();


            DataRow dr;
            dr = dsDATA.Tables["Tovar"].Rows[0];
            IDcountry = dr["idcountry"].ToString();
            ParentID = dr["parentid"].ToString();
            CODE_1C = dr["code"].ToString(); // код товара
            ShortName = dr["Name"].ToString(); // наименование товара
            UnitName = EdinIzm(dr["edIzm"].ToString());//Единица измерения
        }


        private string EdinIzm(string id)
        {
            using (SqlConnection conn = new SqlConnection(SQLcon))
            {
                conn.Open();
                string str0 = null;
                SqlCommand cmd = new SqlCommand(string.Format("SELECT descr from _SC116 where id='{0}'", id), conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        str0 = reader.GetValue(0).ToString();
                    }
                    reader.Close();
                }
                conn.Close();
                return str0;
            }

        }


        /// <summary>
        /// функция возвращает строку из таблицы 1SBLOB
        /// </summary>
        /// <param name="FieldId">Идентификатор записи</param>
        /// <param name="ObjId">Код объекта/param>
        /// <returns></returns>
        private string BLOBstringDS(string FieldId, DataTable dt)
        {
            string val = null;

            if (dt.Rows.Count > 0)
            {
                try
                {
                    DataRow dr0 = dt.Rows[0];
                    string Lenstr;
                    Lenstr = dr0["block"].ToString().Substring(0, 9);
                    int iLen = HEXtoInt(Lenstr.Trim());
                    int x = 0;
                    foreach (DataRow dr in dt.Rows)
                    {
                        int y = Convert.ToInt32(dr["blockno"]);
                        if (y == x)
                        {
                            val += dr["block"].ToString();
                            x++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    val = val.Substring(9, iLen);
                }
                catch
                {
                    val = null;
                }


            }

            return val;
        }

        /// <summary>
        /// Функция конвертирует HEX значение в целое число
        /// </summary>
        /// <param name="Hex"></param>
        /// <returns></returns>
        private int HEXtoInt(string Hex)
        {
            int iLen;
            if (int.TryParse(Hex, System.Globalization.NumberStyles.HexNumber, null, out iLen))
            {

            }
            return iLen;
        }

        public string Description()
        {
            string tmpD = "";
            SqlDataReader descr;
            using (SqlConnection connSQL = new SqlConnection(SQLcon))
            {
                connSQL.Open();
                SqlCommand cmd = new SqlCommand(string.Format("SELECT  descr from CODES WHERE idtov='{0}'", idtov), connSQL);
                descr = cmd.ExecuteReader();
                while (descr.Read())
                {
                    tmpD = descr["descr"].ToString();
                }
                connSQL.Close();
                descr.Close();
            }
            return tmpD;
        }

        public string QRCODE()
        {
            SqlDataReader descr;
            string tmp = "";
            using (SqlConnection connSQL = new SqlConnection(SQLcon))
            {
                connSQL.Open();
                SqlCommand cmd = new SqlCommand(string.Format("SELECT SCODE from CODES WHERE idtov='{0}'", idtov), connSQL);
                descr = cmd.ExecuteReader();
                while (descr.Read())
                {
                    tmp = descr["SCODE"].ToString();
                }
                connSQL.Close();
                descr.Close();
            }

            return tmp;
        }

        /// <summary>
        /// Выборка данных (наименование, цена входная без НДС и т.д.) о товаре по коду
        /// </summary>
        private void ReadMainInfo()
        {
            using (SqlConnection conn = new SqlConnection(SQLcon))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                //загружаем нужный товар
                SqlCommand cmdSel = new SqlCommand(string.Format("SELECT id, parentid, code, descr as Name,  sp141 as cena0, sp148 as idcountry, sp140 as edIzm, sp48410 as idTara from _SC156 where id='{0}'", idtov), conn);
                da.SelectCommand = cmdSel;
                da.Fill(dsDATA, "Tovar");
                conn.Close();
            }


        }


        public string NameCountry()
        {
            string nameC="";
            using (SqlConnection conn = new SqlConnection(SQLcon))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(string.Format("SELECT descr from _SC27082 where id='{0}'", IDcountry), conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nameC = reader.GetValue(0).ToString();
                    }
                }
                reader.Close();
                conn.Close();
            }
            return nameC;
        }



        /// <summary>
        /// Таблица входнящих накладных на заданный товар
        /// </summary>
        /// <returns></returns>
        public DataTable ListTN()
        {
            DataTable dtTN = new DataTable();
            DataTable dtTMP = new DataTable();

            using (SqlConnection conn = new SqlConnection(SQLcon))
            {
                conn.Open();
                SqlDataAdapter daT = new SqlDataAdapter();
                SqlCommand cmdTEMP = new SqlCommand(string.Format("SELECT iddoc from _DT11188 where sp11179='{0}'", idtov), conn);
                daT.SelectCommand = cmdTEMP;
                daT.Fill(dtTMP);
                //conn.Close();

                SqlDataAdapter da = new SqlDataAdapter();
                //conn.Open();
                foreach (DataRow drTMP in dtTMP.Rows)
                {
                    string idTN = drTMP["iddoc"].ToString();
                    SqlCommand cmdTN = new SqlCommand(string.Format("SELECT [_DH11188].iddoc, [_DH11188].sp27331 as data, [_DH11188].sp11172 as idPost, [_DH11188].sp27330 as NomerTN, [_SC133].descr as NamePost from _DH11188 inner join _SC133 on _DH11188.sp11172=_SC133.id where [_DH11188].iddoc='{0}'", idTN), conn);
                    da.SelectCommand = cmdTN;
                    da.Fill(dtTN);
                }
                conn.Close();
            }
            return dtTN;
        }


        /// <summary>
        /// Таблица со всеми ценами на заданный товар
        /// </summary>
        /// <returns></returns>
        public DataTable ListPrice()
        {
            DataTable dtPrice = new DataTable();

            using (SqlConnection conn = new SqlConnection(SQLcon))
            {
                SqlDataAdapter da = new SqlDataAdapter();
                conn.Open();
                //получаем все цены по товару
                SqlCommand cmdCeny = new SqlCommand(string.Format("SELECT _DT48386.iddoc, _DT48386.sp48380 as idtov, _DT48386.sp48384 as CenaR, _DT48386.sp53404 as Cena0, _DH48386.sp48376 as data  from _DT48386 inner join _DH48386 on _DT48386.iddoc=_DH48386.iddoc where _DT48386.sp48380='{0}'", idtov), conn);
                da.SelectCommand = cmdCeny;
                da.Fill(dtPrice);
                conn.Close();
            }
            return dtPrice;
        }


        /// <summary>
        /// Полное наименование товара
        /// </summary>
        /// <returns></returns>
        public string FullName()
        {
            string str;
            using (SqlConnection conn = new SqlConnection(SQLcon))
            {
                SqlDataAdapter da = new SqlDataAdapter();
                conn.Open();
                SqlCommand cmdBLOB = new SqlCommand(string.Format("SELECT fieldid, objid, blockno, block from _1SBLOB where fieldid='3U' and objid='{0}'", idtov), conn);
                da.SelectCommand = cmdBLOB;
                da.Fill(dsDATA, "BLOB");
                str = BLOBstringDS("3U", dsDATA.Tables["BLOB"]);
                conn.Close();
            }
            return str;
        }
    }

}
