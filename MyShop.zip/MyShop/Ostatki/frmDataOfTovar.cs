﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace MyShop
{
    public partial class FrmDataOfTovar : Form
    {

        InfoTovarForm1S infoNew;

        string _idtov;
        string _SCODE;

        bool IsShowDescription = false;
        bool IsShowPrice = false;
        bool IsShowDoc = false;
        bool IsShowQR = false;

        public FrmDataOfTovar(string idtov)
        {
            InitializeComponent();

            infoNew = new InfoTovarForm1S(idtov);

            _idtov = idtov;

            Console.WriteLine(idtov);

            Cursor = Cursors.WaitCursor;
            lblCODE.Text = infoNew.CODE_1C;
            txtNameTovar.Text = infoNew.ShortName;
            this.Text += ": " + infoNew.ShortName;
            txtFullName.Text = infoNew.FullName();
            dgCeny.AutoGenerateColumns = false;
            dg1.AutoGenerateColumns = false;
            Cursor = Cursors.Default;
        }




        private void BtnOK_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void OpenTN()
        {
            if (dg1.Rows.Count > 0)
            {
                string id;//id TN
                int index;

                index = dg1.CurrentRow.Index;
                id = dg1["iddoc", index].Value.ToString();

                frmTNpost fTn = new frmTNpost(id)
                {
                    idtov = _idtov//передаем код товара
                };
                fTn.ShowDialog();
            }

        }

        private void BtnViewDoc_Click(object sender, EventArgs e)
        {
            OpenTN();
        }



        private void FrmDataOfTovar_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Escape)
            {
                this.Close();
            }
        }


        private void TabInfo_Click(object sender, EventArgs e)
        {
            if (dgCeny.Rows.Count > 0)
            {
                int x = dgCeny.Rows.Count - 1;
                dgCeny.FirstDisplayedScrollingRowIndex = x;
                dgCeny.Rows[x].Selected = true;
            }
        }

        private void tabInfo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(tabInfo.SelectedTab.Name);
            switch (tabInfo.SelectedTab.Name)
            {
                case "tabDescr":
                    ShowDescr();
                    break;
                case "tabCeny":
                    ShowPrice();
                    break;
                case "tabDocIn":
                    ShowDocIn();
                    break;
                case "tabQR":
                    ShowQR();
                    break;
                default:
                    break;
            }
        }

        private void ShowQR()
        {
            if (IsShowQR == false)
            {
                txtSCODE.Text = infoNew.QRCODE();

                IsShowQR = true;
            }
        }

        private void ShowDocIn()//Таблица входных документов (ТН)
        {
            if (IsShowDoc == false)
            {
                dg1.DataSource = infoNew.ListTN();
                IsShowDoc = true;
            }
        }

        
        private void ShowPrice()//Таблица цен
        {

            if (IsShowPrice == false)
            {
                DataTable dtCen;
                dtCen = infoNew.ListPrice();
                dgCeny.DataSource = dtCen;

                //выводим график изменения цены
                if (dtCen.Rows.Count > 1)
                {
                    chart1.Visible = true;
                    dgCeny.Dock = DockStyle.None;
                    chart1.Titles.Add("График изменения цены");
                    foreach (DataRow dr in dtCen.Rows)
                    {
                        chart1.Series[0].Points.AddXY(dr["data"], dr["CenaR"]);
                    }

                }
                else
                {
                    chart1.Visible = false;
                    dgCeny.Dock = DockStyle.Fill;
                }

                IsShowPrice = true;
            }
        }

        private void ShowDescr()//Описание товара
        {
            if (IsShowDescription == false)
            {
                string descr=infoNew.Description();
                string Country = infoNew.NameCountry();
                txtDescr.Text = descr;
                string strana = "Страна ввоза: ";
                if (string.IsNullOrEmpty(txtDescr.Text))
                {
                    txtDescr.Text = strana + Country;
                }
                else
                {
                    if (descr.Contains(strana))
                    {
                        txtDescr.Text = descr;
                    }
                    else
                    {
                        txtDescr.Text = descr + "\r\n" + strana + Country;
                    }
                }
                IsShowDescription = true;
            }

        }

        private void dg1_DoubleClick_1(object sender, EventArgs e)
        {
            OpenTN();
        }

        private void dg1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.ColumnIndex == 2 && e.RowIndex >= 0 && dg1[e.ColumnIndex, e.RowIndex].Selected)
            {
                btnShowDocPost.Visible = true;
                btnShowDocPost.Height = e.CellBounds.Height - 1;
                btnShowDocPost.Width = e.CellBounds.Height;
                btnShowDocPost.Location = new Point(e.CellBounds.X  + dg1.Location.X +(e.CellBounds.Width - btnShowDocPost.Width - 1), e.CellBounds.Y + dg1.Location.Y);
            }
            else
            {
                btnShowDocPost.Visible = false;
            }
        }

        private void btnShowDocPost_Click(object sender, EventArgs e)
        {
            OpenTN();
        }
    }
}
