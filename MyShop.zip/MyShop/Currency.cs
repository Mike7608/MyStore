﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Text.RegularExpressions;
using System.Globalization;
using System.IO;
using System.Data.SqlClient;
using System.Data;


class Currency
{
    string[] DBstr;

    string path;
    string SQLcon;
    MyShop.Settings set = new MyShop.Settings();
    /// <summary>
    /// Таблица валют
    /// </summary>
    public Money[] TableCurrency;
    public delegate void CurrencyHandler();
    public event CurrencyHandler InsertRowSQL;
    public event CurrencyHandler ReadCurrencyFormHTTP;
    public event CurrencyHandler ReadCurrencyFromSQL;

    public Currency()
    {
        path = Directory.GetCurrentDirectory() + "\\kurs.val";

        SQLcon = set.SQLconnectionString;
    }

    /// <summary>
    /// Поиск по аббревиатуре валюты из трёх букв
    /// </summary>
    /// <param name="Abbr">Например: USD</param>
    /// <returns></returns>
    public Money Find(string Abbr)
    {
        Money mr = new Money();
        foreach (Money m in TableCurrency)
        {
            if (m.Abbreviation == Abbr)
            {
                mr = m;
                break;
            }
        }
        return mr;
    }

    /// <summary>
    /// Поиск по международному коду валюты
    /// </summary>
    /// <param name="ID">Международный код</param>
    /// <returns></returns>
    public Money Find(int ID)
    {
        Money mr = new Money();
        foreach (Money m in TableCurrency)
        {
            if (m.ID == ID)
            {
                mr = m;
                break;
            }
        }
        return mr;
    }

    private void SaveDBtoFile(string text)
    {

        using (FileStream fstream = new FileStream(path, FileMode.OpenOrCreate))
        {
            // преобразуем строку в байты
            byte[] array = System.Text.Encoding.Default.GetBytes(text);
            // запись массива байтов в файл
            fstream.Write(array, 0, array.Length);
        }
    }

    private string LoadDBfromFile()
    {
        string db;
        using (FileStream fstream = File.OpenRead(path))
        {
            // преобразуем строку в байты
            byte[] array = new byte[fstream.Length];
            // считываем данные
            fstream.Read(array, 0, array.Length);
            // декодируем байты в строку
            db = System.Text.Encoding.Default.GetString(array);

        }
        return db;
    }

    /// <summary>
    /// Удаляет файл Kurs.val
    /// </summary>
    public void DeleteFileKurs()
    {
        FileInfo fileInf = new FileInfo(path);
        if (fileInf.Exists)
        {
            fileInf.Delete();
        }
    }

    /// <summary>
    /// Процедура полечения курсов валют с HTTP сервера на текущий момент
    /// </summary>
    /// <param name="http"></param>
    public void GetRate(string http)
    {
        WebClient wc = new WebClient();
        string db;

    start:
        FileInfo fileInf = new FileInfo(path);
        if (!fileInf.Exists)
        {
            //string htt = "https://www.nbrb.by/api/exrates/rates?periodicity=0";
            wc.Encoding = Encoding.UTF8;
            try
            {
                db = wc.DownloadString(http);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

            //сохранить строку в файл
            SaveDBtoFile(db);
            Init();
        }
        else
        {
            DateTime date = fileInf.LastWriteTime;
            if (date.Date < DateTime.Now.Date)
            {
                DeleteFileKurs();
                goto start;
            }
            else
            {
                Init();
            }
        }

        if (ReadCurrencyFormHTTP != null)
        {
            ReadCurrencyFormHTTP();
        }
    }


    private void Init()
    {

        try
        {
            string db = null;
            db = LoadDBfromFile();

            //пример строки с валютами
            //{\"Cur_ID\":170,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"AUD\",\"Cur_Scale\":1,\"Cur_Name\":\"РђРІСЃС‚СЂР°Р»РёР№СЃРєРёР№ РґРѕР»Р»Р°СЂ\",\"Cur_OfficialRate\":1.6901},
            //{\"Cur_ID\":191,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"BGN\",\"Cur_Scale\":1,\"Cur_Name\":\"Р‘РѕР»РіР°СЂСЃРєРёР№ Р»РµРІ\",\"Cur_OfficialRate\":1.4029},
            //{\"Cur_ID\":290,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"UAH\",\"Cur_Scale\":100,\"Cur_Name\":\"Р“СЂРёРІРµРЅ\",\"Cur_OfficialRate\":9.0146},
            //{\"Cur_ID\":291,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"DKK\",\"Cur_Scale\":10,\"Cur_Name\":\"Р”Р°С‚СЃРєРёС… РєСЂРѕРЅ\",\"Cur_OfficialRate\":3.6835},
            //{\"Cur_ID\":145,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"USD\",\"Cur_Scale\":1,\"Cur_Name\":\"Р”РѕР»Р»Р°СЂ РЎРЁРђ\",\"Cur_OfficialRate\":2.4300},
            //{\"Cur_ID\":292,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"EUR\",\"Cur_Scale\":1,\"Cur_Name\":\"Р•РІСЂРѕ\",\"Cur_OfficialRate\":2.7435},
            //{\"Cur_ID\":293,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"PLN\",\"Cur_Scale\":10,\"Cur_Name\":\"Р—Р»РѕС‚С‹С…\",\"Cur_OfficialRate\":6.1300},
            //{\"Cur_ID\":303,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"IRR\",\"Cur_Scale\":100000,\"Cur_Name\":\"РСЂР°РЅСЃРєРёС… СЂРёР°Р»РѕРІ\",\"Cur_OfficialRate\":5.7857},
            //{\"Cur_ID\":294,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"ISK\",\"Cur_Scale\":100,\"Cur_Name\":\"РСЃР»Р°РЅРґСЃРєРёС… РєСЂРѕРЅ\",\"Cur_OfficialRate\":1.7288},
            //{\"Cur_ID\":295,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"JPY\",\"Cur_Scale\":100,\"Cur_Name\":\"Р™РµРЅ\",\"Cur_OfficialRate\":2.2754},
            //{\"Cur_ID\":23,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"CAD\",\"Cur_Scale\":1,\"Cur_Name\":\"РљР°РЅР°РґСЃРєРёР№ РґРѕР»Р»Р°СЂ\",\"Cur_OfficialRate\":1.7864},
            //{\"Cur_ID\":304,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"CNY\",\"Cur_Scale\":10,\"Cur_Name\":\"РљРёС‚Р°Р№СЃРєРёС… СЋР°РЅРµР№\",\"Cur_OfficialRate\":3.4697},
            //{\"Cur_ID\":72,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"KWD\",\"Cur_Scale\":1,\"Cur_Name\":\"РљСѓРІРµР№С‚СЃРєРёР№ РґРёРЅР°СЂ\",\"Cur_OfficialRate\":7.8924},
            //{\"Cur_ID\":296,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"MDL\",\"Cur_Scale\":10,\"Cur_Name\":\"РњРѕР»РґР°РІСЃРєРёС… Р»РµРµРІ\",\"Cur_OfficialRate\":1.4190},
            //{\"Cur_ID\":286,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"NZD\",\"Cur_Scale\":1,\"Cur_Name\":\"РќРѕРІРѕР·РµР»Р°РЅРґСЃРєРёР№ РґРѕР»Р»Р°СЂ\",\"Cur_OfficialRate\":1.5969},
            //{\"Cur_ID\":297,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"NOK\",\"Cur_Scale\":10,\"Cur_Name\":\"РќРѕСЂРІРµР¶СЃРєРёС… РєСЂРѕРЅ\",\"Cur_OfficialRate\":2.5629},
            //{\"Cur_ID\":298,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"RUB\",\"Cur_Scale\":100,\"Cur_Name\":\"Р РѕСЃСЃРёР№СЃРєРёС… СЂСѓР±Р»РµР№\",\"Cur_OfficialRate\":3.4118},
            //{\"Cur_ID\":299,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"XDR\",\"Cur_Scale\":1,\"Cur_Name\":\"РЎР”Р(РЎРїРµС†РёР°Р»СЊРЅС‹Рµ РїСЂР°РІР° Р·Р°РёРјСЃС‚РІРѕРІР°РЅРёСЏ)\",\"Cur_OfficialRate\":3.3668},
            //{\"Cur_ID\":119,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"SGD\",\"Cur_Scale\":1,\"Cur_Name\":\"РЎРёРЅРіР°РїСѓСЂcРєРёР№ РґРѕР»Р»Р°СЂ\",\"Cur_OfficialRate\":1.7464},
            //{\"Cur_ID\":300,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"KGS\",\"Cur_Scale\":100,\"Cur_Name\":\"РЎРѕРјРѕРІ\",\"Cur_OfficialRate\":3.1224},
            //{\"Cur_ID\":301,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"KZT\",\"Cur_Scale\":1000,\"Cur_Name\":\"РўРµРЅРіРµ\",\"Cur_OfficialRate\":5.8773},
            //{\"Cur_ID\":302,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"TRY\",\"Cur_Scale\":10,\"Cur_Name\":\"РўСѓСЂРµС†РєРёС… Р»РёСЂ\",\"Cur_OfficialRate\":3.5396},
            //{\"Cur_ID\":143,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"GBP\",\"Cur_Scale\":1,\"Cur_Name\":\"Р¤СѓРЅС‚ СЃС‚РµСЂР»РёРЅРіРѕРІ\",\"Cur_OfficialRate\":3.0640},
            //{\"Cur_ID\":305,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"CZK\",\"Cur_Scale\":100,\"Cur_Name\":\"Р§РµС€СЃРєРёС… РєСЂРѕРЅ\",\"Cur_OfficialRate\":10.2861},
            //{\"Cur_ID\":306,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"SEK\",\"Cur_Scale\":10,\"Cur_Name\":\"РЁРІРµРґСЃРєРёС… РєСЂРѕРЅ\",\"Cur_OfficialRate\":2.6384},
            //{\"Cur_ID\":130,\"Date\":\"2020 - 07 - 11T00: 00:00\",\"Cur_Abbreviation\":\"CHF\",\"Cur_Scale\":1,\"Cur_Name\":\"РЁРІРµР№С†Р°СЂСЃРєРёР№ С„СЂР°РЅРє\",\"Cur_OfficialRate\":2.5804}

            int x = TotalRow(db);//получаем количество строк

            TableCurrency = new Money[x];

            DBstr = new string[x];


            int start = 0;
            int index = 0;
            do
            {
                int y = db.IndexOf("{", start);
                int y2 = db.IndexOf("}", y);
                int len = y2 - y + 1;
                DBstr[index] = db.Substring(y, len);
                start = y2;
                if (start > 0)
                    index++;
            } while (index < x);

            Init2(DBstr);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
    }


    private void Init2(string[] DB)
    {
        int x = 0;
        foreach (string str in DB)
        {
            string tmp0 = str.Substring(1, str.Length - 2);//удаляем фигурные кавычки {}
            string[] tmp = tmp0.Split(',');
            TableCurrency[x] = new Money(tmp[0].Substring(9), tmp[1].Substring(8, tmp[1].Length - 9), tmp[2].Substring(20, tmp[2].Length - 21), tmp[3].Substring(12), tmp[4].Substring(12, tmp[4].Length - 13), tmp[5].Substring(19));
            x++;
        }

    }


    /// <summary>
    /// Процедура возвращает количество строк в базе
    /// </summary>
    /// <param name="row"></param>
    /// <returns></returns>
    private int TotalRow(string row)
    {
        int b_n = 0;
        int count = 0;
        do
        {
            b_n = row.IndexOf("Cur_ID", b_n + 1);
            if (b_n > 0)
                count++;
        } while (b_n > 0);

        return count;
    }

    /// <summary>
    /// Процедура полечения курсов валют из базы SQL сервера
    /// </summary>
    /// <param name="date">Дата требуемого курса валют</param>
    public void GetRate(DateTime date)
    {
        DataTable dtSQ;
        int x=1000;
        do
        {
            dtSQ = GetRateSQL(date);
            date = date.Subtract(TimeSpan.FromDays(1));
            x--;
            if (x == 0) break;
        }
        while (dtSQ.Rows.Count == 0);

        if (dtSQ.Rows.Count > 0)
        {
            TableCurrency = new Money[dtSQ.Rows.Count];

            int index;
            for (index = 0; index<dtSQ.Rows.Count; index++) 
            {
                DataRow dr = dtSQ.Rows[index];
                object rate =dr["rate"];
                TableCurrency[index] = new Money("0", dr["date"].ToString(), dr["name"].ToString(), dr["scale"].ToString(), "", rate.ToString().Replace(",", "."));
            }
        }

        if (ReadCurrencyFromSQL != null)
        {
            ReadCurrencyFromSQL();
        }

    }

    private DataTable GetRateSQL(DateTime date)
    {
        DataTable dtSQ = new DataTable();
        string cmd = string.Format("SELECT * from Currency where date='{0}'", date);

        using (SqlConnection con = new SqlConnection(SQLcon))
        {
            SqlCommand cmdSQ = new SqlCommand(cmd, con);
            SqlDataAdapter da = new SqlDataAdapter(cmdSQ);
            con.Open();
            da.Fill(dtSQ);
            con.Close();
        }

        return dtSQ;
    }

    public bool TrueCurrencySQL(DateTime date)
    {
        bool val=false;
        DateTime d=new DateTime(1,1,1);
        string cmd = $"SELECT top 1 [date] from [Currency] where date='{date}'";
        using (SqlConnection con = new SqlConnection(SQLcon))
        {
            SqlCommand cmdSQ = new SqlCommand(cmd, con);

            con.Open();
            SqlDataReader dr1 = cmdSQ.ExecuteReader();
            while (dr1.Read())
            { d = dr1.GetDateTime(0); }
            con.Close();
        }

        if (d.ToString() != "01.01.0001 0:00:00")
        {
            val = true;
        }
        return val;
    }

    private void InsertCurrencyInBase(Money money)
    {
            string cmd = $"INSERT INTO [Currency] (date, name, scale, rate) values ('{money.Date}', '{money.Abbreviation}', '{money.Scale}', '{money.OfficialRate.ToString().Replace(",",".")}');";
            using (SqlConnection con = new SqlConnection(SQLcon))
            {
                SqlCommand cmdSQ = new SqlCommand(cmd, con);

                con.Open();
                SqlDataReader dr1 = cmdSQ.ExecuteReader();
                con.Close();

                if (InsertRowSQL != null)
                {
                    InsertRowSQL();
                }
            }

    }

    /// <summary>
    /// Процедура сохранения курсов валют в базе SQL
    /// </summary>
    public void SaveCurrencyInBase(Money[] money)
    {
        foreach(Money m in money)
        {
            InsertCurrencyInBase(m);
        }
    }
}

class Money
{
    private int _id;
    private DateTime _date;
    private string _abbreviation;
    private double _scale;
    private string _name;
    private double _officialRate;


    public Money(string Cur_ID, string Date, string Cur_Abbreviation, string Cur_Scale, string Cur_Name, string Cur_OfficialRate)
    {
        _id = Convert.ToInt32(Cur_ID);
        _date = Convert.ToDateTime(Date);
        _abbreviation = Cur_Abbreviation;
        _scale = Convert.ToDouble(Cur_Scale);
        _name = Cur_Name;
        _officialRate = Convert.ToDouble(Cur_OfficialRate, CultureInfo.InvariantCulture);

    }

    public Money()
    {

    }

    //public Money(string[,] val)
    //{
    ////Cur_ID
    //Regex rgx = new Regex("Cur_ID\":([0-9]+)");
    //string i= rgx.Match(val).Value;
    //string[] i0;
    //i0 = i.Split(':');
    //_id = Convert.ToInt32(i0[1]);

    ////Cur_Abbreviation
    //rgx = new Regex("Cur_Abbreviation\":\"([A-Z]+)\"");
    //i = rgx.Match(val).Value;
    //i0 = i.Split(':');
    //_abbreviation = i0[1].Trim('"');

    ////Cur_Scale
    //rgx = new Regex("Cur_Scale\":([0-9]+)");
    //i = rgx.Match(val).Value;
    //i0 = i.Split(':');
    //_scale = Convert.ToDouble(i0[1]);

    ////Cur_OfficialRate
    //rgx = new Regex("Cur_OfficialRate\":([0-9]+\\.[0-9]+)");
    //i = rgx.Match(val).Value;
    //i0 = i.Split(':');
    //_officialRate = Convert.ToDouble(i0[1], CultureInfo.InvariantCulture);

    ////Cur_Name
    //int a;
    //a = val.IndexOf("Cur_Name");
    //int b = val.IndexOf("\",\"", a + 11);
    //_name = val.Substring(a + 11, b-(a+11));
    //}

    public int ID
    {
        get
        {
            return _id;
        }
    }

    public string Abbreviation
    {
        get
        {
            return _abbreviation;
        }
    }

    public double Scale
    {
        get
        {
            return _scale;
        }
    }

    public string Name
    {
        get
        {
            return _name;
        }
    }

    public double OfficialRate
    {
        get
        {
            return _officialRate;
        }
    }

    public DateTime Date
    {
        get
        {
            return _date;
        }
    }

}
