﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop
{
    public partial class FindTextCena : UserControl
    {
        string _txt1 = "Товар";
        string _txt2 = "Цена";

        Color ColorHelpText = Color.FromArgb(201, 201, 201);

        public delegate void ButtonFindHandler(object sender, EventArgs e);
        public event ButtonFindHandler FindClick;
        public event ButtonFindHandler FindTextChanged;

        public delegate void FindTextBoxKeyPress(object sender, KeyPressEventArgs e);
        public event FindTextBoxKeyPress FindKeyPress;

        Image imgFind = global::MyShop.Properties.Resources.icons8_поиск_241;

        public string HelpTextFind 
        {
            get
            {
                return _txt1;
            }
            set
            {
                _txt1 = value;
                if (string.IsNullOrEmpty(TextFind))
                {
                    txtFind.Text = value;
                }
            }
        }
        public string HelpTextCena
        {
            get
            {
                return _txt2;
            }
            set
            {
                _txt2 = value;
                if (string.IsNullOrEmpty(TextCena))
                {
                    txtCena.Text = value;
                }
            }
        }

        public Color BorderColor { get; set; }

        public int BorederTickness { get; set; }

        public Color FindTextBackColor { get; set; }

        public Color FindTextForeColor { get; set; }

        public int TextLenght { get; set; }
        public int CenaLenght { get; set; }

        public string TextFind { get; set; }
        public string TextCena { get; set; }

        public void FindCenaFocus()
        {
            txtCena.Focus();
        }
        public void FintTextFocus()
        {
            txtFind.Focus();
        }
        public FindTextCena()
        {
            InitializeComponent();


            BorderColor = Color.LightGray;
            BorederTickness = 2;
            FindTextBackColor = Color.White;
            FindTextForeColor = Color.Black;
            this.BackColor = FindTextBackColor;
            this.ForeColor = FindTextForeColor;
            txtFind.ForeColor = ColorHelpText;
            txtCena.ForeColor = ColorHelpText;
            this.btnFind.Image = imgFind;

            if (string.IsNullOrEmpty(TextCena))
            {
                txtCena.BackColor = FindTextBackColor;
                txtCena.ForeColor = ColorHelpText;
                txtCena.Text = HelpTextCena;
            }

            if(string.IsNullOrEmpty(TextFind))
            {
                txtFind.BackColor = FindTextBackColor;
                txtFind.ForeColor = ColorHelpText;
                txtFind.Text = HelpTextFind;
            }

        }

        private void txtFind_Enter(object sender, EventArgs e)
        {
            if (txtFind.Text == HelpTextFind & txtFind.ForeColor == ColorHelpText)
            {
                txtFind.Text = null;
                txtFind.ForeColor = FindTextForeColor;
                TextLenght = 0;
                TextFind = null;
            }
        }

        private void txtFind_Leave(object sender, EventArgs e)
        {
            if (txtFind.Text == null || txtFind.Text == "")
            {
                txtFind.Text = HelpTextFind;
                txtFind.ForeColor = ColorHelpText;
                TextLenght = 0;
                TextFind = null;
            }
        }

        private void FindText_Resize(object sender, EventArgs e)
        {
            this.Height = tableLayoutPanel1.Height;
            this.Refresh();

        }

        

        private void btnFind_Click(object sender, EventArgs e)
        {
            //if(TextLenght>0)
            //{
            //    this.btnFind.Image = imgCancel;
            //}

            if (FindClick != null)
            {
                FindClick(sender, e);
            }

        }

        private void txtFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (FindKeyPress != null)
            {
                FindKeyPress(sender, e);
            }
        }

        private void FindText_Load(object sender, EventArgs e)
        {
            this.BackColor = FindTextBackColor;
            tableLayoutPanel1.BackColor = FindTextBackColor;


            this.Height = tableLayoutPanel1.Height;
            //txtCena.Text = HelpTextCena;
            //txtFind.Text = HelpTextFind;
        }

        private void txtFind_TextChanged(object sender, EventArgs e)
        {
            if (txtFind.Text == HelpTextFind)
            {
                TextLenght = 0;
                TextFind = null;
            }
            else
            { 
                TextLenght = txtFind.Text.Length;
                TextFind = txtFind.Text;
            }


            if (FindTextChanged != null)
            {
                FindTextChanged(sender, e);
            }
        }

        private void txtCena_Enter(object sender, EventArgs e)
        {
            if (txtCena.Text == HelpTextCena & txtCena.ForeColor == ColorHelpText)
            {
                txtCena.Text = null;
                txtCena.ForeColor = FindTextForeColor;
                CenaLenght = 0;
                TextCena = null;
            }
        }

        private void txtCena_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCena.Text))
            {
                txtCena.Text = HelpTextCena;
                txtCena.ForeColor = ColorHelpText;
                CenaLenght = 0;
                TextCena = null;
            }
        }

        private void txtCena_TextChanged(object sender, EventArgs e)
        {
            if (txtCena.Text == HelpTextCena)
            {
                TextLenght = 0;
                TextCena = null;
            }
            else
            {
                CenaLenght = txtCena.Text.Length;
                TextCena = txtCena.Text;
            }


            if (FindTextChanged != null)
            {
                FindTextChanged(sender, e);
            }
        }

        private void txtCena_KeyPress(object sender, KeyPressEventArgs e)
        {
                if (FindKeyPress != null)
                {
                    FindKeyPress(sender, e);
                }
        }


        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(BorderColor, BorederTickness);
            e.Graphics.DrawRectangle(pen, BorederTickness - 1, BorederTickness - 1, tableLayoutPanel1.Width - BorederTickness, tableLayoutPanel1.Height - BorederTickness);
            e.Graphics.DrawLine(pen, new Point(txtCena.Location.X - 6, txtCena.Location.Y - 4), new Point(txtCena.Location.X - 6, txtCena.Location.Y + 35));
        }

        public void TextClear()
        {
            //txtCena.Text = null;
            //txtFind.Text = null;
            TextCena = null;
            TextFind = null;
            CenaLenght = 0;
            TextLenght = 0;
            txtFind.Text = HelpTextFind;
            txtFind.ForeColor = ColorHelpText;
            txtCena.Text = HelpTextCena;
            txtCena.ForeColor = ColorHelpText;
        }
        /// <summary>
        /// Процедура преобразует строку слов в массив слов
        /// </summary>
        /// <param name="val">Входная строка</param>
        /// <param name="sep">Символ разделитель</param>
        /// <returns></returns>
        public ArrayList ArrayWord(string val, char sep)
        {
            ArrayList arrayList = new ArrayList();
            if(!string.IsNullOrEmpty(val))
            { 
                arrayList.AddRange(val.Split(sep));
                int x = 0;
                do
                {
                    string s = arrayList[x].ToString().Trim();

                    if (string.IsNullOrEmpty(s))
                    {
                        arrayList.RemoveAt(x);// удаляем пустышки
                        x--;
                    }
                    x++;
                }
                while (x < arrayList.Count);
            }
            return arrayList;
        }

        /// <summary>
        /// процедура конвертирует строку в decimal значение
        /// </summary>
        /// <param name="str">входная строка</param>
        /// <returns>значение тип decimal</returns>
        public decimal ToDecimal(string str)
        {
            string dec = null;
            decimal val=0;
            if (!string.IsNullOrEmpty(str))
            {
                try
                {
                    dec = str.Replace(',', '.');
                    val = Convert.ToDecimal(dec, CultureInfo.InvariantCulture);

                }
                catch
                {
                    throw new Exception("Ошибка! Значение должно быть числовым!");
                }
            }
            return val;
        }


        public virtual DataTable FilteredTable(DataTable dataTable, string[] NameColumn, string NameColumnDigits, string ValStr, string ValDig)
        {
            DataTable dt;
            dt = dataTable.Copy();

            //разбиваем ValStr на слова
            ArrayList ListW;
            ListW = ArrayWord(ValStr, ' ');

            decimal Cen1;
            string filter=null;
            try
            {
                DataTable dtRet;

                //конвертируем строку в число
                Cen1 = ToDecimal(ValDig);

                if (ListW.Count > 0)
                {
                    foreach(string W in ListW)
                    {
                        filter = StringToFilter(W, NameColumn);

                        dt.DefaultView.RowFilter = filter;
                        dtRet = dt.DefaultView.ToTable();
                        dt.Clear();
                        dt = dtRet.DefaultView.ToTable();
                    }
                }
                if(!string.IsNullOrEmpty(ValDig))
                {
                    filter = $"[{NameColumnDigits}]={Cen1.ToString().Replace(',', '.')}";
                    dt.DefaultView.RowFilter = filter;
                    dtRet = dt.DefaultView.ToTable();
                    dt.Clear();
                    dt = dtRet.DefaultView.ToTable();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка поисковой строки", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dt.Clear();
            }
            
            return dt;
        }

        private string StringToFilter(string word, string[] NameColumn)
        {
            string str = null;
            int x = 0;
            foreach (string T in NameColumn)
            {
                x++;
                str += string.Format("convert([{0}], 'System.String') like '*{1}*'", T, word);

                if (x < NameColumn.Length)
                {
                    str += " OR ";

                }
            }
            return str;
        }

        private void txtFind_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Insert)
            {
                e.Handled = true;
            }
        }

        private void FindTextCena_Paint(object sender, PaintEventArgs e)
        {
            //Font fontText = new Font("Arial", 9, FontStyle.Regular);
            //e.Graphics.DrawString(HelpTextFind, fontText, Brushes.Gray,5,5);
        }
    }
}
