﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using QRCoder;

namespace CennikWorkNOT
{
    public class QRbox
    {
        public string Text { get; set; }

        public Point Location { get; set; }

        public Size Size { get; set; }

        public Point CenninkLocation { get; set; }

        public void Paint(Graphics gr, int zoom)
        {
            Zoom z = new Zoom(zoom);
            QRCodeGenerator QG = new QRCodeGenerator();
            var MyData = QG.CreateQrCode(Text, QRCodeGenerator.ECCLevel.H);
            var code = new QRCoder.QRCode(MyData);
            Image image = code.GetGraphic(50);
            Point loc = new Point(CenninkLocation.X + z.NewValue(Location.X), CenninkLocation.Y + z.NewValue(Location.Y));
            RectangleF rec = new RectangleF(loc, z.NewSize(Size));
            gr.DrawImage(image, rec);
        }
    }
}
