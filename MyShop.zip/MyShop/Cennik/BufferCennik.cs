﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyShop.Cennik
{
    public static class BufferCennik
    {
        public static  string idtov {get;set;}

        public static string code { get; set; }


        public static string NameTovar { get; set; }

        public static decimal Cena { get; set; }

        public static string FilterText { get; set; }

        public static string FilterCena { get; set; }

        public static void Clear()
        {
            idtov = null;
            code = null;
            NameTovar = null;
            Cena = 0M;
        }
        
    }
}
