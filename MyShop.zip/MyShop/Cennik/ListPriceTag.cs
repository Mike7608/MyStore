﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace PriceTag
{
    public class ListPriceTag
    {
        public List<Tag> ListTag = new List<Tag>();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Path">Путь к файлам ценника</param>
        /// <param name="ext">расширение файла ценника. Например: *.ptag</param>
        public ListPriceTag(string Path, string ext)
        {
            DirectoryInfo di = new DirectoryInfo(Path);
            int index = 0;

            foreach (var fi in di.GetFiles(ext))
            {
                Tag t = new Tag();
                t.XMLload(fi.FullName);
                ListTag.Add(t);
                index++;
            }
        }
    }
}
