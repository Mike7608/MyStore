﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyShop.MAGAZIN;
using PriceTag;

namespace PriceTag
{
    public partial class ControlPriceTag : UserControl
    {

        #region ПЕРЕМЕННЫЕ

        private int _zoom = 100;

        private ListPriceTag listPiceTag;

        private Tag tag= new Tag();

        private PriceTagInfo _info = new PriceTagInfo();

        private int priceTagDefault = 1;

        #endregion

        #region СВОЙСТВА

        public int Zoom
        {
            get { return _zoom; }
            set { _zoom = value; }
        }

        public int PriceTagDefault
        {
            get { return priceTagDefault; }
            set {
                priceTagDefault = value;
                SetPriceTagDefault();
            }
        }

        public bool ControlPanelVisible
        {
            get { return toolStrip1.Visible; }
            set { toolStrip1.Visible = value; }
        }

        public PriceTagInfo Info
        {
            get { return _info; }
            set { _info = value; }
        }

        public Tag PriceTag
        {
            get { return tag; }
            set { tag = value; }
        }

        #endregion

        public ControlPriceTag()
        {
            InitializeComponent();
            listPiceTag = new ListPriceTag(Application.StartupPath, "*.ptag");

            tag.priceTagInfo = Info;
            ZoomPanels();
        }

        private void ControlPriceTag_Load(object sender, EventArgs e)
        {
            ZoomPanels();


            //Выводим величину масштаба на экран
            ComboBoxZoom.Text = Zoom.ToString() + "%";

            //получаем список найденных форм ценника и заполняем список
            foreach (Tag t in listPiceTag.ListTag)
            {
                comboListForm.Items.Add(t.Name);
            }

            SetPriceTagDefault();

        }

        private void SetPriceTagDefault()
        {
            try
            {
                //Выводим название ценника по умолчанию
                if (listPiceTag.ListTag.Count > 0)//& listPiceTag.ListTag != null
                {
                    comboListForm.Text = listPiceTag.ListTag[priceTagDefault].Name;
                }
            }
            catch
            {
                comboListForm.Text = "";
            }

        }

        private void ControlPriceTag_Resize(object sender, EventArgs e)
        {
            ZoomPanels();
        }



        private void comboListForm_SelectedIndexChanged(object sender, EventArgs e)
        {
            tag = listPiceTag.ListTag[comboListForm.SelectedIndex];
            tag.priceTagInfo = Info;
            this.priceTagDefault = comboListForm.SelectedIndex;
            ZoomPanels();
        }

        private void panelPriceTag_Paint(object sender, PaintEventArgs e)
        {
            tag.Zoom = Zoom;
            //e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            tag.Paint(e.Graphics);
        }

        private void btnZoomPlus_Click(object sender, EventArgs e)
        {
            if (Zoom <= 490)
            {
                Zoom += 10;
                tag.Zoom = Zoom;
                ComboBoxZoom.Text = Zoom.ToString() + "%";
                ZoomPanels();
            }
        }

        private void btnZoomMinus_Click(object sender, EventArgs e)
        {
            if (Zoom >= 15)
            {
                Zoom -= 10;
                tag.Zoom = Zoom;
                ComboBoxZoom.Text = Zoom.ToString() + "%";
                ZoomPanels();
            }
        }

        private void ComboBoxZoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            Zoom = Convert.ToInt32(ComboBoxZoom.Text.TrimEnd('%'));
            tag.Zoom = Zoom;
            ZoomPanels();
        }

        private void ZoomPanels()
        {
            Zoom z = new Zoom(Zoom);

            panelFon.Size = new Size(z.NewValue(tag.Size.Width+20), z.NewValue(tag.Size.Height+20));

            panelPriceTag.Location = new Point(z.NewValue(10), z.NewValue(10));
            panelFon.Location = new Point(panelFon.Location.X+1, panelFon.Location.Y+1);

            panelPriceTag.Size = z.NewSize(tag.Size);

            if (panelFon.Width < panelMain.Width | panelFon.Height < panelMain.Height)
            {
                panelFon.Location = new Point((panelMain.Width - panelFon.Width) / 2, (panelMain.Height - panelFon.Height) / 2);
            }

            panelPriceTag.Refresh();

        }



        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ZoomPanels();
            frmInfoSales info = new frmInfoSales();
            info.ShowAlert("Изображение обновлено", "Ценник", frmInfoSales.EnmType.Info);

        }

        private void ComboBoxZoom_TextChanged(object sender, EventArgs e)
        {
            int z = Zoom;
            try
            {
                Zoom = Convert.ToInt32(ComboBoxZoom.Text);
            }
            catch
            {
                Zoom = z;
            }
            tag.Zoom = Zoom;
            ZoomPanels();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            ZoomPanels();
        }
    }
}
