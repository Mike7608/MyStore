﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace CennikWorkNOT
{
    public class PaintCennik
    {

        private  int _zoom;
        public LabelText Caption;
        public LabelText InfoTovar;
        public LabelText Info1C;
        public LabelText CenaTovara;
        public LabelText kop;
        public QRbox QRcode;

        public int zoom
        {
            get
            {
                return _zoom;
            }
            set
            {
                _zoom = value;
                Refresh();
            }
        }

        private void Refresh()
        {
            Caption.zoom = _zoom;
            InfoTovar.zoom = _zoom;
            Info1C.zoom = _zoom;
            CenaTovara.zoom = _zoom;
            kop.zoom = _zoom;
        }

        /// <summary>
        /// Размер ценника
        /// </summary>
        public Size Size { get; set; }

        /// <summary>
        /// Цвет фона ценника
        /// </summary>
        public Color BackColor { get; set; }

        /// <summary>
        /// Позиция ценника
        /// </summary>
        public Point Location { get; set; }

        /// <summary>
        /// Цвет рамочки ценника
        /// </summary>
        public Color BorderColor { get; set; }

        /// <summary>
        /// Рамочка ценника
        /// </summary>
        public int BorderThickness { get; set; }


        public PaintCennik()
        {
            Caption = new LabelText();
            InfoTovar = new LabelText();
            Info1C = new LabelText();
            CenaTovara = new LabelText();
            kop = new LabelText();
            QRcode = new QRbox();
            zoom = 100;
            BackColor = Color.White;
            Size = new Size(355, 255);//90x65mm/355*255
            BorderColor = Color.Black;
            BorderThickness = 1;
        }

        public void Paint(Graphics gr)
        {
            Zoom z = new Zoom(zoom);
            //Рисуем фон ценника
            Size NewSizeCennic = z.NewSize(Size);
            Rectangle price = new Rectangle(Location, NewSizeCennic);
            Brush br = new SolidBrush(BackColor);
            gr.FillRectangle(br, price);

            Caption.CenninkLocation = Location;
            Caption.Paint(gr);

            ////рисуем информацию о товаре

            InfoTovar.CenninkLocation = Location;
            InfoTovar.Paint(gr);

            ////Информация о поступлении

            Info1C.CenninkLocation = Location;
            Info1C.Paint(gr);

            //int x=Caption
            ////рисуем фон под ценой
            //gr.FillRectangle(new SolidBrush(Color.LightGreen), Location.X + z.NewValue(x), Location.Y + z.NewValue(y), z.NewValue(Size.Width - x - x), z.NewValue(75));

            ////рисуем цену
            //y += 15;
            string[] c = new string[2];
            c[0] = "0";
            c[1] = "00";
            if (!string.IsNullOrEmpty(CenaTovara.Text))
            {
                string val = CenaTovara.Text;
                if (val.IndexOf(',') > 0)
                {
                    c = val.Split(',');
                }
                else
                {
                    c[0] = val;
                }

            }

            //CenaTovara.Location = new Point(Location.X + z.NewValue(x+105), Location.Y + z.NewValue(y));
            CenaTovara.CenninkLocation = Location;
            CenaTovara.Text = c[0];
            CenaTovara.Paint(gr);

            //рисуем копейки

            kop.CenninkLocation = Location;
            kop.Text = c[1];
            kop.Paint(gr);

            CenaTovara.Text = c[0] + ',' + c[1];

            //Рисуем QR код
            if (!string.IsNullOrEmpty(QRcode.Text))
            {
                QRcode.CenninkLocation = Location;
                QRcode.Paint(gr,zoom);
            }

            //Рисуем рамочку вокруг ценника
            if (BorderThickness > 0)
            {
                gr.DrawRectangle(new Pen(BorderColor, BorderThickness),(Location.X+(BorderThickness/2)), (Location.Y+(BorderThickness/2)), z.NewValue(Size.Width-BorderThickness), z.NewValue(Size.Height-BorderThickness));
            }
        }

    }
    
}
