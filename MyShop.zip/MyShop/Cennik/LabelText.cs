﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace CennikWorkNOT
{
    public class LabelText
    {
        private int z;
        Point _location;
        public Point Location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }
        }

        public  Size Size { get; set; }

        public string Text { get; set; }

        public  Color BackColor { get; set; }
        
        public Color ForeColor { get; set; }

        public Font Font { get; set; }

        StringFormat sf = new StringFormat();
        
        public StringAlignment HirizontalAlignment { get; set; }

        public StringAlignment VerticallAlignment { get; set; }
        public int zoom
        {
            get
            {
                return z;
            }
            set
            {
                z = value;
            }
        }

        public Point CenninkLocation { get; set; }
        public LabelText()
        {
            BackColor = Color.White;
            ForeColor = Color.Black;
            Font = new Font("Arial", 8, FontStyle.Regular);
            HirizontalAlignment = StringAlignment.Near;
            VerticallAlignment = StringAlignment.Center;
            Location = new Point(0, 0);
        }

        public void Paint(Graphics gr)
        {
            //3.937
            Zoom zoom = new Zoom(z);
            sf.Alignment = HirizontalAlignment;
            sf.LineAlignment = VerticallAlignment;
            Point loc = new Point(CenninkLocation.X + zoom.NewValue(Location.X), CenninkLocation.Y + zoom.NewValue(Location.Y));
            RectangleF rec = new RectangleF(loc, zoom.NewSize(Size));
            gr.FillRectangle(new SolidBrush(BackColor),loc.X, loc.Y, zoom.NewValue(Size.Width), zoom.NewValue(Size.Height));
            Font f = new Font(Font.FontFamily, zoom.NewValue(Font.Size), Font.Style);
            gr.DrawString(Text, f, new SolidBrush(ForeColor), rec, sf);
        }

    }
}
