﻿
namespace MyShop.Cennik
{
    partial class FrmCennikiMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCennikiMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            PriceTag.PriceTagInfo priceTagInfo1 = new PriceTag.PriceTagInfo();
            PriceTag.Tag tag1 = new PriceTag.Tag();
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnExit = new MyShop.MyButton();
            this.label2 = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.panelNavigation = new System.Windows.Forms.Panel();
            this.panelPrint = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnPrint = new MyShop.MyButton();
            this.radioButtonSelectedPrint = new System.Windows.Forms.RadioButton();
            this.radioButtonAllPrint = new System.Windows.Forms.RadioButton();
            this.BtnDubl = new MyShop.MyButton();
            this.BtnCreate = new MyShop.MyButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelSeparator = new System.Windows.Forms.Panel();
            this.BtnEdit = new MyShop.MyButton();
            this.btnClearTable = new MyShop.MyButton();
            this.BtnDelete = new MyShop.MyButton();
            this.panelDG = new System.Windows.Forms.Panel();
            this.dg = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nDoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameTovar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelCennik = new System.Windows.Forms.Panel();
            this.controlPriceTag1 = new PriceTag.ControlPriceTag();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panelTop.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.panelNavigation.SuspendLayout();
            this.panelPrint.SuspendLayout();
            this.panelDG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.panelCennik.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panelTop.Controls.Add(this.btnExit);
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1041, 68);
            this.panelTop.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkCyan;
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CadetBlue;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = global::MyShop.Properties.Resources.arrow_left_w_24;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExit.Location = new System.Drawing.Point(3, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(52, 63);
            this.btnExit.TabIndex = 7;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.CadetBlue;
            this.label2.Location = new System.Drawing.Point(78, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(310, 47);
            this.label2.TabIndex = 0;
            this.label2.Text = "Список ценников";
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelBottom.Controls.Add(this.panelNavigation);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 503);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1041, 77);
            this.panelBottom.TabIndex = 1;
            // 
            // panelNavigation
            // 
            this.panelNavigation.Controls.Add(this.panelPrint);
            this.panelNavigation.Controls.Add(this.BtnDubl);
            this.panelNavigation.Controls.Add(this.BtnCreate);
            this.panelNavigation.Controls.Add(this.panel1);
            this.panelNavigation.Controls.Add(this.panelSeparator);
            this.panelNavigation.Controls.Add(this.BtnEdit);
            this.panelNavigation.Controls.Add(this.btnClearTable);
            this.panelNavigation.Controls.Add(this.BtnDelete);
            this.panelNavigation.Location = new System.Drawing.Point(264, 0);
            this.panelNavigation.Name = "panelNavigation";
            this.panelNavigation.Size = new System.Drawing.Size(504, 77);
            this.panelNavigation.TabIndex = 3;
            // 
            // panelPrint
            // 
            this.panelPrint.Controls.Add(this.label1);
            this.panelPrint.Controls.Add(this.BtnPrint);
            this.panelPrint.Controls.Add(this.radioButtonSelectedPrint);
            this.panelPrint.Controls.Add(this.radioButtonAllPrint);
            this.panelPrint.Enabled = false;
            this.panelPrint.Location = new System.Drawing.Point(265, 0);
            this.panelPrint.Name = "panelPrint";
            this.panelPrint.Size = new System.Drawing.Size(165, 77);
            this.panelPrint.TabIndex = 2;
            this.panelPrint.EnabledChanged += new System.EventHandler(this.panelPrint_EnabledChanged);
            this.panelPrint.Paint += new System.Windows.Forms.PaintEventHandler(this.panelPrint_Paint);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Gray;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(0, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Просмотр и печать";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BtnPrint
            // 
            this.BtnPrint.BackColor = System.Drawing.Color.DimGray;
            this.BtnPrint.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPrint.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPrint.ForeColor = System.Drawing.Color.White;
            this.BtnPrint.Image = global::MyShop.Properties.Resources.print_search_24_w;
            this.BtnPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnPrint.Location = new System.Drawing.Point(99, 17);
            this.BtnPrint.Name = "BtnPrint";
            this.BtnPrint.Size = new System.Drawing.Size(58, 54);
            this.BtnPrint.TabIndex = 2;
            this.BtnPrint.Text = "Печать";
            this.BtnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.BtnPrint, "Просмотор и печать [Ctrl+P]");
            this.BtnPrint.UseVisualStyleBackColor = false;
            this.BtnPrint.Click += new System.EventHandler(this.BtnPrint_Click);
            // 
            // radioButtonSelectedPrint
            // 
            this.radioButtonSelectedPrint.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.radioButtonSelectedPrint.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButtonSelectedPrint.Location = new System.Drawing.Point(10, 35);
            this.radioButtonSelectedPrint.Name = "radioButtonSelectedPrint";
            this.radioButtonSelectedPrint.Size = new System.Drawing.Size(84, 32);
            this.radioButtonSelectedPrint.TabIndex = 0;
            this.radioButtonSelectedPrint.Text = "Выбранные записи";
            this.radioButtonSelectedPrint.UseVisualStyleBackColor = true;
            // 
            // radioButtonAllPrint
            // 
            this.radioButtonAllPrint.AutoSize = true;
            this.radioButtonAllPrint.Checked = true;
            this.radioButtonAllPrint.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.radioButtonAllPrint.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButtonAllPrint.Location = new System.Drawing.Point(10, 21);
            this.radioButtonAllPrint.Name = "radioButtonAllPrint";
            this.radioButtonAllPrint.Size = new System.Drawing.Size(74, 16);
            this.radioButtonAllPrint.TabIndex = 0;
            this.radioButtonAllPrint.TabStop = true;
            this.radioButtonAllPrint.Text = "Все записи";
            this.radioButtonAllPrint.UseVisualStyleBackColor = true;
            // 
            // BtnDubl
            // 
            this.BtnDubl.BackColor = System.Drawing.Color.DimGray;
            this.BtnDubl.Enabled = false;
            this.BtnDubl.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnDubl.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnDubl.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnDubl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDubl.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDubl.ForeColor = System.Drawing.Color.White;
            this.BtnDubl.Image = global::MyShop.Properties.Resources.copy24w;
            this.BtnDubl.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnDubl.Location = new System.Drawing.Point(66, 6);
            this.BtnDubl.Name = "BtnDubl";
            this.BtnDubl.Size = new System.Drawing.Size(58, 64);
            this.BtnDubl.TabIndex = 0;
            this.BtnDubl.Text = "Копия";
            this.BtnDubl.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.BtnDubl, "Копировать текущую запись [Ctrl+Insert]");
            this.BtnDubl.UseVisualStyleBackColor = false;
            this.BtnDubl.Click += new System.EventHandler(this.BtnDubl_Click);
            // 
            // BtnCreate
            // 
            this.BtnCreate.BackColor = System.Drawing.Color.DimGray;
            this.BtnCreate.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnCreate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnCreate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCreate.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCreate.ForeColor = System.Drawing.Color.White;
            this.BtnCreate.Image = global::MyShop.Properties.Resources.icons8_сложение_241;
            this.BtnCreate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnCreate.Location = new System.Drawing.Point(2, 6);
            this.BtnCreate.Name = "BtnCreate";
            this.BtnCreate.Size = new System.Drawing.Size(58, 64);
            this.BtnCreate.TabIndex = 0;
            this.BtnCreate.Text = "Создать";
            this.BtnCreate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.BtnCreate, "Создать новый ценник [Insert]");
            this.BtnCreate.UseVisualStyleBackColor = false;
            this.BtnCreate.Click += new System.EventHandler(this.BtnCreate_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Location = new System.Drawing.Point(436, 11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2, 55);
            this.panel1.TabIndex = 1;
            // 
            // panelSeparator
            // 
            this.panelSeparator.BackColor = System.Drawing.Color.Gray;
            this.panelSeparator.Location = new System.Drawing.Point(257, 11);
            this.panelSeparator.Name = "panelSeparator";
            this.panelSeparator.Size = new System.Drawing.Size(2, 55);
            this.panelSeparator.TabIndex = 1;
            // 
            // BtnEdit
            // 
            this.BtnEdit.BackColor = System.Drawing.Color.DimGray;
            this.BtnEdit.Enabled = false;
            this.BtnEdit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnEdit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnEdit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEdit.Font = new System.Drawing.Font("Segoe UI", 6.5F);
            this.BtnEdit.ForeColor = System.Drawing.Color.White;
            this.BtnEdit.Image = global::MyShop.Properties.Resources.icons8_редактировать_241;
            this.BtnEdit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnEdit.Location = new System.Drawing.Point(130, 6);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(58, 64);
            this.BtnEdit.TabIndex = 0;
            this.BtnEdit.Text = "Изменить";
            this.BtnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.BtnEdit, "Изменить текущую запись [F2]");
            this.BtnEdit.UseVisualStyleBackColor = false;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // btnClearTable
            // 
            this.btnClearTable.BackColor = System.Drawing.Color.DimGray;
            this.btnClearTable.Enabled = false;
            this.btnClearTable.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnClearTable.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClearTable.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnClearTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearTable.Font = new System.Drawing.Font("Segoe UI", 6.5F);
            this.btnClearTable.ForeColor = System.Drawing.Color.White;
            this.btnClearTable.Image = ((System.Drawing.Image)(resources.GetObject("btnClearTable.Image")));
            this.btnClearTable.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClearTable.Location = new System.Drawing.Point(443, 6);
            this.btnClearTable.Name = "btnClearTable";
            this.btnClearTable.Size = new System.Drawing.Size(58, 64);
            this.btnClearTable.TabIndex = 0;
            this.btnClearTable.Text = "Очистить таблицу";
            this.btnClearTable.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.btnClearTable, "Удалить все записи [Ctrl+Delete]");
            this.btnClearTable.UseVisualStyleBackColor = false;
            this.btnClearTable.Click += new System.EventHandler(this.btnClearTable_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.BackColor = System.Drawing.Color.DimGray;
            this.BtnDelete.Enabled = false;
            this.BtnDelete.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.BtnDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDelete.Font = new System.Drawing.Font("Segoe UI", 6.5F);
            this.BtnDelete.ForeColor = System.Drawing.Color.White;
            this.BtnDelete.Image = global::MyShop.Properties.Resources.icons8_мусор_241;
            this.BtnDelete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnDelete.Location = new System.Drawing.Point(194, 6);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(58, 64);
            this.BtnDelete.TabIndex = 0;
            this.BtnDelete.Text = "Удалить";
            this.BtnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.BtnDelete, "Удалить выбранную(ые) запись(и) [Delete]");
            this.BtnDelete.UseVisualStyleBackColor = false;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // panelDG
            // 
            this.panelDG.Controls.Add(this.dg);
            this.panelDG.Controls.Add(this.panelCennik);
            this.panelDG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDG.Location = new System.Drawing.Point(0, 68);
            this.panelDG.Name = "panelDG";
            this.panelDG.Size = new System.Drawing.Size(1041, 435);
            this.panelDG.TabIndex = 2;
            // 
            // dg
            // 
            this.dg.AllowUserToAddRows = false;
            this.dg.AllowUserToDeleteRows = false;
            this.dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.code,
            this.data,
            this.nDoc,
            this.NameTovar,
            this.descr,
            this.cena,
            this.scode});
            this.dg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg.Location = new System.Drawing.Point(0, 0);
            this.dg.Name = "dg";
            this.dg.Size = new System.Drawing.Size(707, 435);
            this.dg.TabIndex = 0;
            this.dg.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dg_RowsAdded);
            this.dg.DoubleClick += new System.EventHandler(this.dg_DoubleClick);
            this.dg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dg_KeyDown);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "Код";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            this.id.Width = 50;
            // 
            // code
            // 
            this.code.DataPropertyName = "code";
            this.code.HeaderText = "Код товара 1С";
            this.code.Name = "code";
            // 
            // data
            // 
            this.data.DataPropertyName = "data";
            this.data.HeaderText = "Дата документа поступления";
            this.data.Name = "data";
            this.data.Width = 80;
            // 
            // nDoc
            // 
            this.nDoc.DataPropertyName = "nDoc";
            this.nDoc.HeaderText = "Номер документа поступления";
            this.nDoc.Name = "nDoc";
            this.nDoc.Width = 80;
            // 
            // NameTovar
            // 
            this.NameTovar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NameTovar.DataPropertyName = "NameTovar";
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.NameTovar.DefaultCellStyle = dataGridViewCellStyle1;
            this.NameTovar.HeaderText = "Наименование товара";
            this.NameTovar.MinimumWidth = 200;
            this.NameTovar.Name = "NameTovar";
            // 
            // descr
            // 
            this.descr.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.descr.DataPropertyName = "descr";
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.descr.DefaultCellStyle = dataGridViewCellStyle2;
            this.descr.HeaderText = "Информация о товаре";
            this.descr.MinimumWidth = 200;
            this.descr.Name = "descr";
            // 
            // cena
            // 
            this.cena.DataPropertyName = "Cena";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.Format = "N2";
            this.cena.DefaultCellStyle = dataGridViewCellStyle3;
            this.cena.HeaderText = "Цена товара";
            this.cena.Name = "cena";
            this.cena.Width = 80;
            // 
            // scode
            // 
            this.scode.DataPropertyName = "scode";
            this.scode.HeaderText = "QR код товара";
            this.scode.Name = "scode";
            this.scode.Width = 200;
            // 
            // panelCennik
            // 
            this.panelCennik.Controls.Add(this.controlPriceTag1);
            this.panelCennik.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelCennik.Location = new System.Drawing.Point(707, 0);
            this.panelCennik.Name = "panelCennik";
            this.panelCennik.Size = new System.Drawing.Size(334, 435);
            this.panelCennik.TabIndex = 1;
            // 
            // controlPriceTag1
            // 
            this.controlPriceTag1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.controlPriceTag1.ControlPanelVisible = true;
            this.controlPriceTag1.Dock = System.Windows.Forms.DockStyle.Top;
            priceTagInfo1.Caption = null;
            priceTagInfo1.Description = null;
            priceTagInfo1.Price = 0F;
            priceTagInfo1.QRcode = null;
            priceTagInfo1.TagInfo = null;
            this.controlPriceTag1.Info = priceTagInfo1;
            this.controlPriceTag1.Location = new System.Drawing.Point(0, 0);
            this.controlPriceTag1.Margin = new System.Windows.Forms.Padding(3, 35, 3, 35);
            this.controlPriceTag1.Name = "controlPriceTag1";
            tag1.BackColor = System.Drawing.Color.White;
            tag1.BorderColor = System.Drawing.Color.Black;
            tag1.BorderThickness = 0F;
            tag1.Location = new System.Drawing.Point(0, 0);
            tag1.Name = "Standard";
            tag1.Size = new System.Drawing.Size(355, 255);
            tag1.Zoom = 70;
            this.controlPriceTag1.PriceTag = tag1;
            this.controlPriceTag1.PriceTagDefault = 1;
            this.controlPriceTag1.Size = new System.Drawing.Size(334, 254);
            this.controlPriceTag1.TabIndex = 0;
            this.controlPriceTag1.Zoom = 70;
            // 
            // FrmCennikiMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1041, 580);
            this.Controls.Add(this.panelDG);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "FrmCennikiMain";
            this.Text = "Список ценников";
            this.Activated += new System.EventHandler(this.FrmCennikiMain_Activated);
            this.Resize += new System.EventHandler(this.FrmCennikiMain_Resize);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelBottom.ResumeLayout(false);
            this.panelNavigation.ResumeLayout(false);
            this.panelPrint.ResumeLayout(false);
            this.panelPrint.PerformLayout();
            this.panelDG.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.panelCennik.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelBottom;
        private MyButton BtnDelete;
        private MyButton BtnEdit;
        private MyButton BtnDubl;
        private MyButton BtnCreate;
        private System.Windows.Forms.Panel panelDG;
        private System.Windows.Forms.DataGridView dg;
        private System.Windows.Forms.Panel panelCennik;
        private System.Windows.Forms.Panel panelSeparator;
        private MyButton BtnPrint;
        private System.Windows.Forms.Panel panelNavigation;
        private System.Windows.Forms.RadioButton radioButtonSelectedPrint;
        private System.Windows.Forms.RadioButton radioButtonAllPrint;
        private System.Windows.Forms.Panel panel1;
        private MyButton btnClearTable;
        private System.Windows.Forms.Panel panelPrint;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolTip toolTip1;
        private PriceTag.ControlPriceTag controlPriceTag1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn code;
        private System.Windows.Forms.DataGridViewTextBoxColumn data;
        private System.Windows.Forms.DataGridViewTextBoxColumn nDoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameTovar;
        private System.Windows.Forms.DataGridViewTextBoxColumn descr;
        private System.Windows.Forms.DataGridViewTextBoxColumn cena;
        private System.Windows.Forms.DataGridViewTextBoxColumn scode;
        private System.Windows.Forms.Label label2;
        private MyButton btnExit;
    }
}