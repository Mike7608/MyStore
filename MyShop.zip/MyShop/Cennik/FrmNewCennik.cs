﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using PriceTag;

namespace MyShop.Cennik
{
    public partial class FrmNewCennik : Form
    {
        Settings set = new Settings();
        const string StranaProizvodstva = "Страна производства: ";
        private string idtov { get; set; }
        private DataRow dr;

        SCODE SCODE;
        DataTable dt;

        DataTable strana;
        int LenghtDescr;


        public FrmNewCennik(DataRow dataRow, DataTable strany)
        {
            InitializeComponent();
            strana = strany;

            SCODE = new SCODE();

            dt = Global.mainDataSet.Tables["Cennik"];
            dr = dataRow;

            if (dr!=null)
            {
                //форма как редактирование
                idtov = dr["idtov"].ToString();
                dateTimePicker1.Value = (DateTime)dr["data"];
                txtNameTovar.Text = dr["NameTovar"].ToString();
                DescrAndStrana(dr["descr"].ToString());
                txtSCODE.Text = dr["scode"].ToString();
                txtNomerTN.Text = dr["nDoc"].ToString();
                txtCODE.Text = dr["code"].ToString();
                txtCena.Value = decimal.Parse(dr["cena"].ToString());

                controlPriceTag1.PriceTagDefault = (int)dr["type"];

                SCODE.Find(idtov, txtCODE.Text);

                AllDataToCennik();
                controlPriceTag1.Refresh();

                button1.Enabled = false;
                btnInfo.Enabled = true;

                if (!string.IsNullOrEmpty(idtov)) { BtnSaveDESCR.Enabled = true; }

                this.Text =  "[" + dr[0].ToString() + "] - " + txtNameTovar.Text + " - [Редактор ценника]";
            }
            else
            {
                //форма как ввод новой записи
                dateTimePicker1.Value = DateTime.Now;
                controlPriceTag1.PriceTagDefault = Properties.Settings.Default.DefaultPriceTag;
                BtnSaveDESCR.Enabled = false;
            }


        }

        private string Description()
        {
            string val = txtDescr.Text;
            // если страна производства указана тогда добавлем строку со страной производства
            if (comboStranaProizv.Text.Length > 0)
            {
                val+= "\r\n" + StranaProizvodstva + comboStranaProizv.Text;
            }
            return val;
        }

        private void DescrAndStrana(string val)
        {
            if (!string.IsNullOrEmpty(val))
            {
                int index = val.IndexOf(StranaProizvodstva);
                if (index >= 0)
                {
                    txtDescr.Text = val.Substring(0, index-2);
                    string[] m = val.Substring(index).Split(':');
                    comboStranaProizv.Text = m[1].Trim();
                }
            }
            else
            {
                txtDescr.Text = "";
            }

        }


        private void AllDataToCennik()
        {
            controlPriceTag1.Info.Caption = txtNameTovar.Text;
            controlPriceTag1.Info.Price = (float)txtCena.Value;

            controlPriceTag1.Info.Description = Description();
            controlPriceTag1.Info.QRcode = txtSCODE.Text;
            Info1Cchanged();

        }
        private void txtNameTovar_TextChanged(object sender, EventArgs e)
        {
            controlPriceTag1.Info.Caption = txtNameTovar.Text;
            controlPriceTag1.Refresh();
            //this.Text = txtNameTovar.Text + " - [Редактор ценника]";
        }

        private void txtSCODE_TextChanged(object sender, EventArgs e)
        {
            lblTotalSCODE.Text = txtSCODE.Text.Length.ToString();

        }

        private void txtCena_TextChanged(object sender, EventArgs e)
        {
            controlPriceTag1.Info.Price = (float)txtCena.Value;
            controlPriceTag1.Refresh();
        }

        private void txtDescr_TextChanged(object sender, EventArgs e)
        {
            controlPriceTag1.Info.Description = Description();
            controlPriceTag1.Refresh();

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            Info1Cchanged();
        }

        private void Info1Cchanged()
        {
            string str;
            str = txtCODE.Text + " | " + dateTimePicker1.Value.ToShortDateString() + " | " + txtNomerTN.Text;
            controlPriceTag1.Info.TagInfo = str;
            controlPriceTag1.Refresh();
        }

        private void txtNomerTN_TextChanged(object sender, EventArgs e)
        {
            Info1Cchanged();
        }

        private void txtCODE_TextChanged(object sender, EventArgs e)
        {
            Info1Cchanged();
        }

        private void txtSCODE_Leave(object sender, EventArgs e)
        {
            //QR code
            controlPriceTag1.Info.QRcode = txtSCODE.Text;
            controlPriceTag1.Refresh();
        }

        private void ReadTNData()
        {

            SqlDataReader descr;
            using (SqlConnection connSQL = new SqlConnection(set.SQLconnectionString))
            {
                connSQL.Open();
                string SQlstr = string.Format("SELECT TOP (1) _DH11188.SP27331, _DH11188.SP27330 FROM _DH11188 INNER JOIN _DT11188 ON _DH11188.IDDOC = _DT11188.IDDOC WHERE(_DT11188.SP11179 = '{0}') ORDER BY _DH11188.SP27331 DESC;", idtov);
                SqlCommand cmd = new SqlCommand(SQlstr, connSQL);
                descr = cmd.ExecuteReader();
                while (descr.Read())
                {
                    dateTimePicker1.Value = Convert.ToDateTime(descr[0]);
                    txtNomerTN.Text = descr[1].ToString();
                }
                connSQL.Close();
            }



        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {

            if (dr!=null)
            {
                dr.BeginEdit();
                dr["scode"] = txtSCODE.Text;
                dr["data"] = dateTimePicker1.Value;
                dr["nDoc"] = txtNomerTN.Text;
                dr["NameTovar"] = txtNameTovar.Text;
                dr["descr"] = Description();
                dr["Cena"] = txtCena.Value;
                dr["type"] = controlPriceTag1.PriceTagDefault;
                dr.EndEdit();
            }
            else
            {
                //добавляем нужные данные в табдицу ценника
                dr= Global.mainDataSet.Tables["Cennik"].NewRow();
                dr["idtov"] = idtov;    
                dr["code"] = txtCODE.Text;    
                dr["scode"] = txtSCODE.Text;    
                dr["data"] = dateTimePicker1.Value;    
                dr["nDoc"] = txtNomerTN.Text;    
                dr["NameTovar"] = txtNameTovar.Text;    
                dr["descr"] = Description();
                dr["Cena"] = txtCena.Value;    
                dr["type"] = controlPriceTag1.PriceTagDefault;
                dt.Rows.Add(dr);
            }

            //Сохраняем новый QR код в базе SQL
            if (txtCODE.Text.Length > 0)
            {
                if (string.IsNullOrEmpty(SCODE.row.IDTOV))
                {
                    //insert row
                    SCODE.row.IDTOV = idtov;
                    SCODE.row.CODE = txtCODE.Text;
                    SCODE.row.SCODE = txtSCODE.Text;
                    SCODE.Insert(SCODE.row);
                }
                else
                {
                    //update
                    SCODE.row.SCODE = txtSCODE.Text;
                    SCODE.Update(SCODE.row);
                }
            }


            this.Close();
        }

        private void BtnSaveDESCR_Click(object sender, EventArgs e)
        {
            SaveDescr();
        }


        private void SaveDescr()
        {

            if (string.IsNullOrEmpty(SCODE.row.IDTOV))
            {
                SCODE.InsertDescr(Description(), idtov, txtCODE.Text);
                SCODE.Find(idtov, txtCODE.Text);//находим эту запись в базе для получения id
            }
            else
            {
                SCODE.UpdateDescr(Description());

            }



        }



        private void FrmNewCennik_Load(object sender, EventArgs e)
        {
            LoadStrany();
            comboStranaProizv_SelectedValueChanged(null, null);

            //System.Drawing.Font f = new System.Drawing.Font(controlPriceTag1.PriceTag.LabelBoxes[1].Font.Name, controlPriceTag1.PriceTag.LabelBoxes[1].Font.Size, controlPriceTag1.PriceTag.LabelBoxes[1].Font.FontStyle);
            //richDescr.Font = f;
            //toolStripStyleText1.Font = f;
        }

        private void LoadStrany()
        {
            foreach(DataRow dr in strana.Rows)
            {
                string Name = dr["DESCR"].ToString();
                if (Name != "Наименование")
                {
                    comboStranaProizv.Items.Add(Name);
                }
            }


        }

        private void comboStranaProizv_SelectedValueChanged(object sender, EventArgs e)
        {
            controlPriceTag1.Info.Description = Description();
            controlPriceTag1.Refresh();
        }


        private void btnInfo_Click(object sender, EventArgs e)
        {
            FrmDataOfTovar frmInfo = new FrmDataOfTovar(idtov);
            frmInfo.ShowDialog();
        }

        private void txtDescr_Enter(object sender, EventArgs e)
        {
            LenghtDescr = txtDescr.Text.Length;
        }

        private void txtDescr_Leave(object sender, EventArgs e)
        {
            if (LenghtDescr != txtDescr.Text.Length & !string.IsNullOrEmpty(idtov))
            {
                BtnSaveDESCR.Enabled = true;
            }
        }

        private void FrmNewCennik_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData) 
            {
                case Keys.Insert:
                    if (button1.Enabled)
                    {
                        button1_Click_1(null, null);
                    }
                    break;
                case Keys.Control | Keys.I:
                    if (btnInfo.Enabled)
                    {
                        btnInfo_Click(null, null);
                    }
                    break;
                case Keys.Control | Keys.S:
                    if (BtnSaveDESCR.Enabled)
                    {
                        SaveDescr();
                    }
                    break;
            }

        }

        private void FrmNewCennik_Resize(object sender, EventArgs e)
        {
            panel2.Location = new Point((panelBottom.Width - panel2.Width) / 2, 6);
            controlPriceTag1.Refresh();
        }

        private void FrmNewCennik_Shown(object sender, EventArgs e)
        {
            FrmNewCennik_Resize(null, null);
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            Ostatki.frmOstatkiCurrent frm = new Ostatki.frmOstatkiCurrent();
            frm.BtnPrintVisible = false;
            frm.btnCreateCennik.Visible = false;
            frm.Panel2Visible = true;
            frm.StartPosition = FormStartPosition.CenterParent;
            //frm.StartPosition = FormStartPosition.CenterScreen;
            if (frm.ShowDialog() == DialogResult.OK)
            {
                SCODE = new SCODE();
                txtNameTovar.Text = BufferCennik.NameTovar;
                txtCODE.Text = BufferCennik.code;
                idtov = BufferCennik.idtov;
                txtCena.Value = BufferCennik.Cena;
                SCODE.Find(idtov, txtCODE.Text);
                DescrAndStrana(SCODE.row.Descr);
                txtSCODE.Text = SCODE.row.SCODE;
                ReadTNData();
                btnInfo.Enabled = true;
                BtnSaveDESCR.Enabled = true;
                //Thread t = new Thread(RefreshCennik);
                //t.Start();
                AllDataToCennik();
                //controlPriceTag1.Refresh();
            }
        }

        private void btnOpenInExplore_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q="+txtNameTovar.SelectedText.Replace(' ', '+')+"+onliner");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtNameTovar_SelectionChanged(object sender, EventArgs e)
        {
            if (txtNameTovar.SelectedText.Length > 0)
            {
                btnOpenInExplore.Enabled = true;
            }
            else
            {
                btnOpenInExplore.Enabled = false;
            }
        }

        private void btnClearCountry_Click(object sender, EventArgs e)
        {
            comboStranaProizv.Text = null;
            controlPriceTag1.Info.Description = Description();
            controlPriceTag1.Refresh();
        }

        private void panel1_Resize(object sender, EventArgs e)
        {
            if (panel1.Width < 400) panel1.Width = 400;
        }
    }
}
