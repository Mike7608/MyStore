﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PriceTag;

namespace MyShop.Cennik
{
    public partial class FrmCennikiMain : Form
    {
        BindingSource bs = new BindingSource();
        DataTable dt;
        DataTable strany;
        Tag ptag = new Tag();
        SQLmodule sql = new SQLmodule();
        Cenniki.Cennik cennik;
        ListPriceTag listPtag = new ListPriceTag(Application.StartupPath, "*.ptag");

        public FrmCennikiMain()
        {
            InitializeComponent();

            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;

            cennik = new Cenniki.Cennik();
            dt = cennik.DataTable();
            strany = new DataTable();

            strany.Columns.Add("CODE", typeof(string));
            strany.Columns.Add("DESCR", typeof(string));

            controlPriceTag1.PriceTagDefault= Properties.Settings.Default.DefaultPriceTag;

            bs.PositionChanged += Bs_PositionChanged;
            dg.Paint += Dg_Paint;

            //назначаем стиль таблице
            MyStyleDataGrid styleDataGrid = new MyStyleDataGrid();
            styleDataGrid.Default(dg);
            dg.MultiSelect = true;

            //настраиваем колонки
            dg.AutoGenerateColumns = false;
            bs.DataSource = dt;
            dg.DataSource = bs;

            PanelNavigationPosition();

            sql.SQLselect("SELECT CODE, DESCR FROM _SC27082", strany);

        }



        private void Dg_Paint(object sender, PaintEventArgs e)
        {
            MK.Procedures procedures = new MK.Procedures();
            procedures.PaintNullDataString(dg, e);
        }

        private void PanelNavigationPosition()
        {
            panelNavigation.Location = new Point((this.Width - panelNavigation.Width) / 2, 0);
        }
        private void Bs_PositionChanged(object sender, EventArgs e)
        {
            if (bs.Count > 0)
            {
                //BtnCreate.Enabled = true;
                BtnDelete.Enabled = true;
                BtnDubl.Enabled = true;
                BtnEdit.Enabled = true;
                panelPrint.Enabled = true;
                btnClearTable.Enabled = true;
                DataRow dr = currentRow;
                controlPriceTag1.PriceTagDefault = (int)dr["type"];
                controlPriceTag1.Info.Caption=dr["NameTovar"].ToString();
                controlPriceTag1.Info.Description = dr["descr"].ToString();
                string data = ((DateTime)dr["data"]).ToShortDateString();
                controlPriceTag1.Info.TagInfo = dr["code"].ToString() + " | " + data + " | " + dr["ndoc"].ToString();
                controlPriceTag1.Info.Price =  Convert.ToSingle(dr["cena"]);
                controlPriceTag1.Info.QRcode = dr["scode"].ToString();

                controlPriceTag1.Refresh();
            }
            else
            {
                CennikNull();
                //panel2.Refresh();
                BtnDelete.Enabled = false;
                BtnDubl.Enabled = false;
                BtnEdit.Enabled = false;
                panelPrint.Enabled = false;
                btnClearTable.Enabled = false;
                BtnCreate.Focus();
            }
        }

        //private int AutoZoom()
        //{
        //    double z=100;
        //        double x, y;
        //        x = ptag.Size.Width;
        //        y = panelPreviewTag.Width-(panel2.Location.X*2);
        //        z = (y / x)*100;
        //    if (z > 100) z = 100;
        //    return (int)z;
        //}

        private void CennikNull()
        {
            ptag.priceTagInfo.Caption = "";
            ptag.priceTagInfo.Description = "";
            ptag.priceTagInfo.TagInfo = "";
            ptag.priceTagInfo.Price = 0;
            ptag.priceTagInfo.QRcode = "";
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            FrmNewCennik frm = new FrmNewCennik(null, strany);
            //frm.WindowState = FormWindowState.Maximized;
            Global.OpenForm(frm);
            bs.Position = bs.Count;
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            EditRow();
        }

        private void EditRow()
        {

            FrmNewCennik frm = new FrmNewCennik(currentRow, strany);

            Global.OpenForm(frm);

            //if (frmJournalSALES == null || frmJournalSALES.IsDisposed)
            //{
            //    frmJournalSALES = new MAGAZIN.FrmJournalSALES
            //    {
            //        MdiParent = this,
            //        WindowState = FormWindowState.Maximized
            //    };
            //    frmJournalSALES.Show();
            //}
            //else
            //{
            //    frmJournalSALES.Activate();
            //}
        }

        public DataRow currentRow
        {
            get
            {
                int position = this.BindingContext[bs].Position;
                if (position > -1)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DeleteSelectedRows();
        }

        private void DeleteSelectedRows()
        {
            DataGridViewSelectedRowCollection dgvsrc = dg.SelectedRows;
            MAGAZIN.frmInfoSales info = new MAGAZIN.frmInfoSales();

            try
            {

                int[] index = new int[dgvsrc.Count];
                DialogResult result;
                if (dgvsrc.Count > 1)
                {
                    result = MessageBox.Show("Внимание! Удалить выбранные позиции?", "Таблица ценников", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                }
                else
                {
                    result = DialogResult.Yes;
                }
                if(result== DialogResult.Yes)
                {
                    int x = 0;
                    foreach(DataGridViewRow dr in dgvsrc)
                    {
                        DataRow DR = (DataRow)((DataRowView)dr.DataBoundItem).Row;

                        index[x] =(int) DR["id"];
                        x++;
                    }

                    //удаляем выбранные позиции
                    x = 0;
                    do
                    {
                        DataRow dr = Global.mainDataSet.Tables["Cennik"].Rows.Find(index[x]);
                        dr.Delete();
                        x++;
                    }
                    while (x < index.Length);
                    dt.AcceptChanges();
                }


                info.ShowAlert("Выбранные записи удалены", "Список ценников", MAGAZIN.frmInfoSales.EnmType.Error);

                dg.Focus();
            }
            catch
            {
                info.ShowAlert("Нет выбранных записей для удаления", "Ошибка", MAGAZIN.frmInfoSales.EnmType.Error);
                //MessageBox.Show(,"Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void BtnDubl_Click(object sender, EventArgs e)
        {
            DataRow dr = Global.mainDataSet.Tables["Cennik"].NewRow();
            dr["idtov"] = currentRow["idtov"];
            dr["code"] = currentRow["code"];
            dr["scode"] = currentRow["scode"];
            dr["NameTovar"] = currentRow["NameTovar"];
            dr["descr"] = currentRow["descr"];
            dr["data"] = currentRow["data"];
            dr["nDoc"] = currentRow["nDoc"];
            dr["type"] = currentRow["type"];
            dr["cena"] = currentRow["cena"];
            Global.mainDataSet.Tables["Cennik"].Rows.Add(dr);

            bs.Position = bs.Count;

            MAGAZIN.frmInfoSales info = new MAGAZIN.frmInfoSales();
            info.ShowAlert("Запись скопирована и добавлена в конеце списка", "Копия строки", MAGAZIN.frmInfoSales.EnmType.Info);

            dg.Focus();
        }

        private void dg_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            controlPriceTag1.Refresh();
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            if (bs.Count > 0)
            {
                if (radioButtonAllPrint.Checked)
                {
                    PrintCennik prnCen = new PrintCennik(dt, listPtag);

                    FrmPrintPreview prn = new FrmPrintPreview(prnCen)
                    {
                        MdiParent = Global.mainForm

                    };
                    prn.Show();
                }
                else
                {
                    MK.Procedures mkp = new MK.Procedures();
                    PrintCennik prnCen = new PrintCennik(mkp.SelectedRows(dg), listPtag);
                    FrmPrintPreview prn = new FrmPrintPreview(prnCen)
                    {
                        MdiParent = Global.mainForm

                    };
                    prn.Show();
                }

            }
        }

        private void FrmCennikiMain_Resize(object sender, EventArgs e)
        {
            PanelNavigationPosition();
            dg.Refresh();
        }

        private void dg_DoubleClick(object sender, EventArgs e)
        {
            if(dg.SelectedColumns.Count>=0 & dg.SelectedRows.Count >= 0)
            {
                EditRow();
            }
        }

        private void btnClearTable_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Будут удалены все записи в текущей таблице! Продолжить?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(result== DialogResult.Yes)
            {
                dg.DataSource = null;
                dt.Clear();
                dg.DataSource = bs;
                MAGAZIN.frmInfoSales info = new MAGAZIN.frmInfoSales();
                info.ShowAlert("Список ценников для печати очищен полностью", "Список ценников", MAGAZIN.frmInfoSales.EnmType.Error);
                dg.Focus();

            }
        }

        private void panelPrint_EnabledChanged(object sender, EventArgs e)
        {
            if (panelPrint.Enabled)
            {
                BtnPrint.Enabled = true;
                BtnPrint.ForeColor = Color.White;
                radioButtonAllPrint.Enabled = true;
                radioButtonAllPrint.ForeColor = Color.White;
                radioButtonSelectedPrint.Enabled = true;
                radioButtonSelectedPrint.ForeColor = Color.White;
            }
            else
            {
                BtnPrint.Enabled = false;
                BtnPrint.ForeColor = Color.Black;
                radioButtonAllPrint.ForeColor = Color.Black;
                radioButtonAllPrint.Enabled = false;
                radioButtonSelectedPrint.Enabled = false;
                radioButtonSelectedPrint.ForeColor = Color.Black;
            }
        }

        private void panelPrint_Paint(object sender, PaintEventArgs e)
        {
            Pen borderPen = new Pen(Brushes.Gray, 1);
            e.Graphics.DrawRectangle(borderPen, 0,2, panelPrint.Width-1, panelPrint.Height-5);
        }



        private void dg_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                case Keys.Insert:
                    BtnCreate_Click(null, null);
                    break;
                case Keys.Delete:
                    DeleteSelectedRows();
                    break;
                case Keys.F2:
                    EditRow();
                    break;
                case Keys.Control | Keys.Insert:
                    BtnDubl_Click(null, null);
                    break;
                case Keys.Control | Keys.P:
                    BtnPrint_Click(null, null);
                    break;
                case Keys.Control | Keys.Delete:
                    btnClearTable_Click(null, null);
                    break;
            }
        }

        private void FrmCennikiMain_Activated(object sender, EventArgs e)
        {
            dg.Focus();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            ptag.Paint(e.Graphics);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
