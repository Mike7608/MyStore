﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace MyShop.Cenniki
{
    class Cennik
    {
        #region  ===СОБЫТИЯ===

        public delegate void CennikHandler(string Message);
        public event CennikHandler Notify;

        #endregion

        DataTable dt;
        DataTable dtTN=new DataTable();
        SQLmodule SQLmod = new SQLmodule();

        public Cennik()
        {
            //Если таблица уже существует тогда только назначаем
            if (Global.mainDataSet.Tables.Contains("Cennik"))
            {
                dt = Global.mainDataSet.Tables["Cennik"];
            }
            else
            {
                //иначе создаём таблицу
                CreateTable();
            }

        }

        public void CreateTable()
        {
                dt = new DataTable("Cennik");
                dt.Columns.Add("id", typeof(int));//id
                dt.Columns.Add("idtov", typeof(string));//id 1C
                dt.Columns.Add("code", typeof(string));//код 1С
                dt.Columns.Add("data", typeof(DateTime));//дата поступления
                dt.Columns.Add("nDoc", typeof(string));//номер документа
                dt.Columns.Add("NameTovar", typeof(string));//наименование товара
                dt.Columns.Add("descr", typeof(string));//описание товара
                dt.Columns.Add("Cena", typeof(decimal));//цена товара
                dt.Columns.Add("scode", typeof(string));//штрих код товара
                dt.Columns.Add("type", typeof(int));//тип ценника
                dt.Columns["id"].AutoIncrement = true;
                dt.Columns["id"].AutoIncrementSeed = 1;
                dt.Columns["id"].AutoIncrementStep = 1;
                dt.Columns["id"].AllowDBNull = false;
                dt.Columns["id"].Unique = true;
                Global.mainDataSet.Tables.Add(dt);
                var keys = new DataColumn[1];
                keys[0] = dt.Columns["id"];
                dt.PrimaryKey = keys;
        }

        public void AddRow(string idtov, string code, DateTime data, string NoDoc, string NameTovar, string descr, decimal Cena, string scode) 
        {
            //type??

            DataRow dr = Global.mainDataSet.Tables["Cennik"].NewRow();
            dr["idtov"] = idtov;
            dr["code"] = code;
            dr["data"] = data;
            dr["nDoc"] = NoDoc;
            dr["NameTovar"] = NameTovar;
            dr["descr"] = descr;
            dr["Cena"] = Cena;
            dr["scode"] = scode;
            dr["type"] = Properties.Settings.Default.DefaultPriceTag;
            Global.mainDataSet.Tables["Cennik"].Rows.Add(dr);
        }

        public DataTable DataTable()
        {
            return dt;
        }

        public void CreateCennik(string idtov,  bool ShowMessage)
        {
            CodeCena cc = CodeCena1C(idtov);

            ReadListTN(idtov);

            DateTime data = DateTime.Now;
            string Nomer = "";

            if (dtTN.Rows.Count > 0)
            {
                data =Convert.ToDateTime(dtTN.Rows[0]["Data"]);
                Nomer = dtTN.Rows[0]["Nomer"].ToString();
            }


            SCODE sCODE = new SCODE();
            sCODE.Find(idtov, cc.Code);

            AddRow(idtov, cc.Code, data, Nomer, cc.Name, sCODE.row.Descr, cc.Cena, sCODE.row.SCODE);

            if (Notify != null && ShowMessage == true)
            {
                Notify("Ценник '" + cc.Name + "' свормирован успушно.");

            }
        }

        public void CreateCennik(string idtov, DateTime DataTN, string NomerTN, bool ShowMessage)
        {
            CodeCena cc = CodeCena1C(idtov);

            SCODE sCODE = new SCODE();
            sCODE.Find(idtov, cc.Code);

            AddRow(idtov, cc.Code, DataTN, NomerTN, cc.Name, sCODE.row.Descr, cc.Cena, sCODE.row.SCODE);

            if (Notify != null && ShowMessage==true)
            {
                Notify("Ценник '" + cc.Name + "' свормирован успушно.");

            }
        }

        public CodeCena CodeCena1C(string Idtov)
        {
            DataTable rem;
            rem = Global.mainDataSet.Tables["REMAINS"];

            CodeCena cc = new CodeCena();

            foreach (DataRow dr in rem.Rows)
            {
                if (dr["idtov"].ToString() == Idtov)
                {
                    cc.Code = dr["code"].ToString();
                    cc.Cena = Convert.ToDecimal(dr["Cena"]);
                    cc.Name = dr["NameTovar"].ToString();
                }
            }

            return cc;
        }

        /// <summary>
        /// Получаем список ТН
        /// </summary>
        private void ReadListTN(string idtov)
        {
            SQLmod.SQLselect(string.Format("SELECT TOP (1) _DH11188.SP27331 AS Data, _DH11188.SP27330 AS Nomer FROM _DH11188 INNER JOIN _DT11188 ON _DH11188.IDDOC = _DT11188.IDDOC WHERE(_DT11188.SP11179 = '{0}')", idtov), dtTN);
        }

    }

    class CodeCena
    {
        public string Code;
        public decimal Cena;
        public string Name;

        public CodeCena()
        {
            Cena = 0;
            Code = null;
            Name = null;
        }

    }

}
