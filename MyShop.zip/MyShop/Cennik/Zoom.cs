﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PriceTag
{
    public  class Zoom
    {
        private int zoom;
        public Zoom(int value)
        {
            zoom = value;
        }
        public  int NewValue(int val)
        {
            float v;
            v = ( (float)val * (float)zoom) / 100f;
            if (v < 0) v = 0;
            return (int)v;
        }

        public  float NewValue(float val)
        {
            float v;
            v = (val * zoom) / 100;
            if (v < 0) v = 0;
            return v;
        }
        public  Size NewSize(Size s)
        {
            int w = s.Width;
            int h = s.Height;
            Size val = new Size(NewValue(w), NewValue(h));
            return val;
        }
    }
}
