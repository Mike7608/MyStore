﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Xml;
using QRCoder;
using System.Windows.Forms;
using System.IO;

namespace PriceTag
{
    public class Tag
    {
        //
        // 1 px = 0.26458333 mm
        //
        /// <summary>
        /// Масштаб. По умолчанию 100%
        /// </summary>
        public int Zoom { get; set; }
        /// <summary>
        /// Наименование ценника
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Координаты
        /// </summary>
        public Point Location { get; set; }
        /// <summary>
        /// Размер
        /// </summary>
        public Size Size { get; set; }
        /// <summary>
        /// Цвет фона
        /// </summary>
        public Color BackColor { get; set; }
        /// <summary>
        /// Толщина рамочки
        /// </summary>
        public float BorderThickness { get; set; }
        /// <summary>
        /// Цвет рамочки
        /// </summary>
        public Color BorderColor { get; set; }

        /// <summary>
        /// Список LabelBox
        /// </summary>
        public List<LabelBox> LabelBoxes = new List<LabelBox>();

        /// <summary>
        /// Информация для отображения на ценнике (Наименование товара, описание товара, цена и т.д.)
        /// </summary>
        public PriceTagInfo priceTagInfo = new PriceTagInfo();

        /// <summary>
        /// QR ссылка или код товара
        /// </summary>
        public QRBox QRBox;

        public Tag()
        {
            Name = "Standard";
            Size = new Size(355, 255);
            BackColor = Color.White;
            BorderThickness = 0;
            BorderColor = Color.Black;
            Zoom = 100;
        }


        public void Paint(Graphics e)
        {
            Zoom z = new Zoom(Zoom);

            //рисуем фон ценника 
            RectangleF FormatCennika = new RectangleF(new Point(z.NewValue(Location.X), z.NewValue(Location.Y)), new Size(z.NewValue(Size.Width), z.NewValue(Size.Height)));
            e.FillRectangle(new SolidBrush(BackColor), FormatCennika);

            //Выводим все LabelBox-ы
            foreach (LabelBox labelBox in LabelBoxes)
            {
                string format = labelBox.Text;

                switch (labelBox.Name.ToLower())
                {
                    case "caption":
                        labelBox.Text = priceTagInfo.Caption;
                        break;
                    case "description":
                        labelBox.Text = priceTagInfo.Description;
                        break;
                    case "taginfo":
                        labelBox.Text = priceTagInfo.TagInfo;
                        break;
                    case "price":
                        labelBox.Text = FormatPrice(priceTagInfo.Price, format);
                        break;
                }

                PaintLabelBox(labelBox, e);
                labelBox.Text = format;
            }

            float bt;
            if (QRBox != null)
            {
                if (QRBox.Visible)
                {
                    //выводим QR код
                    if (!string.IsNullOrEmpty(priceTagInfo.QRcode))
                    {
                        Point point = QRBox.Location;//сохраняем координаты
                        QRBox.Location = new Point(z.NewValue(Location.X + point.X), z.NewValue(Location.Y + point.Y));
                        QRBox.Value = priceTagInfo.QRcode;
                        QRBox.Paint(e, Zoom);//выводим QR код


                        bt = z.NewValue(QRBox.BorderThickness);

                        //рисуем рамку QRBox
                        if (bt > 0)
                        {
                            e.DrawRectangle(new Pen(new SolidBrush(QRBox.BorderColor), bt), QRBox.Location.X + (bt / 2), QRBox.Location.Y + (bt / 2), z.NewValue(QRBox.Size) - (bt), z.NewValue(QRBox.Size) - (bt));
                        }

                        QRBox.Location = point; //восстанавливаем координаты
                    }
                }
            }


            bt = z.NewValue(BorderThickness);

            if (bt > 0)
            {
                //рамка ценника
                e.DrawRectangle(new Pen(new SolidBrush(BorderColor), bt), FormatCennika.Location.X + (bt / 2), FormatCennika.Location.Y + (bt / 2), FormatCennika.Size.Width - bt, FormatCennika.Size.Height - bt);
            }


            //// Create pen.
            //Pen blackPen = new Pen(Color.Black, 1);

            //// Create coordinates of rectangle to bound ellipse.
            //float x = 0.0F;
            //float y = 0.0F;
            //float width = 20.0F;
            //float height = 20.0F;

            //// Create start and sweep angles on ellipse.
            //float startAngle = 180.0F;
            //float sweepAngle = 90.0F;

            //// Draw arc to screen.
            //e.Graphics.DrawArc(blackPen, x, y, width, height, startAngle, sweepAngle);
          
        }

        private string FormatPrice(float price, string format)
        {
            string p1 = string.Format("{0:f2}", price);
            string [] p=p1.Split('.', ',');
            string s = format;

            if (format.IndexOf("{rub}")>=0)
            {
                s = s.Replace("{rub}", p[0]);
            }

            if (format.IndexOf("{kop}") >=0)
            {
                s = s.Replace("{kop}", p[1]);
            }

            return s;
        }

        private void PaintLabelBox(LabelBox labelBox, Graphics e)
        {
            if (labelBox.Visible)
            {

                Zoom z = new Zoom(Zoom);
                //цвет текста
                Brush br = new SolidBrush(labelBox.ForeColor);

                //рисуем цвет фона LabelBox
                RectangleF rF = new RectangleF(new Point( z.NewValue(labelBox.Location.X+Location.X), z.NewValue(labelBox.Location.Y+Location.Y)), z.NewSize(labelBox.Size));
                e.FillRectangle(new SolidBrush(labelBox.BackColor), rF);

                //рисуем текст
                StringFormat sf = new StringFormat();
                RectangleF rFt = new RectangleF(new Point(z.NewValue(labelBox.Location.X + Location.X + labelBox.Margin.Left), z.NewValue(labelBox.Location.Y + Location.Y + labelBox.Margin.Top)), new Size(z.NewValue(labelBox.Size.Width - labelBox.Margin.Left - labelBox.Margin.Right), z.NewValue(labelBox.Size.Height - labelBox.Margin.Top - labelBox.Margin.Bottom)));
                sf.Alignment = labelBox.HorizontalAlignment;
                sf.LineAlignment = labelBox.VerticalAlignment;
                e.DrawString(labelBox.Text, new System.Drawing.Font(labelBox.Font.Name, z.NewValue(labelBox.Font.Size), labelBox.Font.FontStyle), br, rFt, sf);

                float bt = z.NewValue(labelBox.BorderThickness);
                //рисуем рамку LabelBox
                if (bt > 0)
                {
                    e.DrawRectangle(new Pen(new SolidBrush(labelBox.BorderColor), bt), z.NewValue(labelBox.Location.X + Location.X) +  (bt / 2), z.NewValue(labelBox.Location.Y + Location.Y) + (bt / 2), z.NewValue(labelBox.Size.Width) - bt, z.NewValue(labelBox.Size.Height) - bt);
                }
            }

        }

        public void XMLload(string path)
        {
            XmlDocument doc = new XmlDocument();
                doc.Load(path);

                var root = doc.DocumentElement;

                Name = root.Attributes["name"].Value;


                foreach (XmlElement node in root.ChildNodes)
                {
                    switch (node.Name)
                    {
                        case "LabelBox":
                            LoadLabelBox(node);
                            break;
                        case "Size":
                            Size = new Size(Convert.ToInt32(node.GetAttribute("width")), Convert.ToInt32(node.GetAttribute("height")));
                            break;
                        case "BackColor":
                            BackColor = ColorTranslator.FromHtml(node.InnerText);
                            break;
                        case "BorderColor":
                            BorderColor= ColorTranslator.FromHtml(node.InnerText);
                            break;
                        case "BorderThickness":
                            BorderThickness = Convert.ToSingle(node.InnerText);
                            break;
                        case "QRBox":
                            LoadQRBox(node);
                        break;
                    }
                }
        }

        private void LoadQRBox(XmlElement element)
        {
            QRBox p = new QRBox();

            foreach(XmlElement node in element)
            {

                switch (node.Name)
                {
                    case "Location":
                        p.Location = new Point(Convert.ToInt32(node.GetAttribute("x")), Convert.ToInt32(node.GetAttribute("y")));
                        break;
                    case "Size":
                        p.Size = Convert.ToSingle(node.InnerText);
                        break;
                    case "BorderThickness":
                        p.BorderThickness = Convert.ToInt32(node.InnerText);
                        break;
                    case "BorderColor":
                        p.BorderColor = ColorTranslator.FromHtml(node.InnerText);
                        break;
                    case "Visible":
                        p.Visible = Convert.ToBoolean(node.InnerText);
                        break;
                    case "Value":
                        p.Value = node.InnerText;
                        break;
                }
            }
            QRBox = new QRBox();
            QRBox = p;
        }

        private void LoadLabelBox(XmlElement element)
        {
            LabelBox lb = new LabelBox();

                foreach(XmlElement node in element)
                {
                    if (element.HasAttributes)
                    {
                        lb.Name = element.Attributes["name"].Value;
                    }


                    switch (node.Name)
                    {
                        case "Font":
                            Font f1 = new Font();
                            f1.Name = node.GetAttribute("name");
                            f1.Size = Convert.ToSingle(node.GetAttribute("size"));
                            f1.FontStyle = f1.FontStyleFromString(node.GetAttribute("style"));
                            lb.Font = f1;
                            break;
                        case "Location":
                            lb.Location = new Point(Convert.ToInt32(node.GetAttribute("x")), Convert.ToInt32(node.GetAttribute("y")));
                            break;
                        case "Size":
                            lb.Size = new Size(Convert.ToInt32(node.GetAttribute("width")), Convert.ToInt32(node.GetAttribute("height")));
                            break;
                        case "BackColor":
                            lb.BackColor = ColorTranslator.FromHtml(node.InnerText);
                            break;
                        case "ForeColor":
                            lb.ForeColor = ColorTranslator.FromHtml(node.InnerText);
                            break;
                        case "HorizontalAlignment":
                            StringAlignment hAlignment = (StringAlignment)Enum.Parse(typeof(StringAlignment), node.InnerText);
                            lb.HorizontalAlignment = hAlignment;
                            break;
                        case "VerticalAlignment":
                            StringAlignment vAlignment = (StringAlignment)Enum.Parse(typeof(StringAlignment), node.InnerText);
                            lb.VerticalAlignment = vAlignment;
                            break;
                        case "Text":
                            lb.Text = node.InnerText;
                            break;
                        case "BorderThickness":
                            lb.BorderThickness = Convert.ToInt32(node.InnerText);
                            break;
                        case "BorderColor":
                            lb.BorderColor = ColorTranslator.FromHtml(node.InnerText);
                            break;
                        case "Visible":
                            lb.Visible =Convert.ToBoolean(node.InnerText);
                            break;
                        case "Margin":
                            lb.Margin.Left = Convert.ToInt32(node.GetAttribute("left"));
                            lb.Margin.Top = Convert.ToInt32(node.GetAttribute("top"));
                            lb.Margin.Right = Convert.ToInt32(node.GetAttribute("right"));
                            lb.Margin.Bottom = Convert.ToInt32(node.GetAttribute("bottom"));
                            break;
                    }
                }

            LabelBoxes.Add(lb);
        }



    }


    public class LabelBox
    {
        public string Name { get; set; }
        public Point Location { get; set; }
        public Size Size { get; set; }
        public Color BackColor { get; set; }
        public Color ForeColor { get; set; }
        public string Text { get; set; }
        public StringAlignment HorizontalAlignment { get; set; }
        public StringAlignment VerticalAlignment { get; set; }
        public float BorderThickness { get; set; }
        public Color BorderColor { get; set; }
        public bool Visible { get; set; }

        public Font Font = new Font();

        private Margin _margin= new Margin();
        public Margin Margin
        {
            get
            {
                return _margin;
            }
            set
            {
                _margin = value;
            }
        }
        public LabelBox()
        {
            Name = "LabelBox";
            Location = new Point(0, 0);
            Size = new Size(50, 20);
            BackColor = Color.White;
            ForeColor = Color.Black;
            Text = "LabelBox";
            Font.Name = "Arial";
            Font.Size = 10;
            Font.FontStyle = FontStyle.Regular;
            BorderThickness = 0;
            BorderColor = Color.Black;
            Visible = true;
            HorizontalAlignment = StringAlignment.Near;
            VerticalAlignment = StringAlignment.Center;
        }
    }

    public class Font
    {
        public Font() { }
        public Font(string name, float size, FontStyle fontStyle)
        {
            Name = name;
            Size = size;
            FontStyle = fontStyle;
        }
        public string Name { get; set; }
        public float Size { get; set; }
        public FontStyle FontStyle { get; set; }

        public FontStyle FontStyleFromString(string fontStyle)
        {
            FontStyle style = (FontStyle)Enum.Parse(typeof(FontStyle), fontStyle);
            return style;
        }
    }

    public class Margin
    {
        private int _all;
        public int All
        {
            get
            {
                return _all;
            }
            set
            {
                _all = value;
                Top = _all;
                Bottom = _all;
                Left = _all;
                Right = _all;
            }
        }
        public  int Top { get; set; }
        public  int Bottom { get; set; }
        public  int Left { get; set; }
        public  int Right { get; set; }

        public Margin() { }
    }

    public class QRBox
    {
        public Point Location { get; set; }
        public float Size { get; set; }
        public float BorderThickness { get; set; }
        public Color BorderColor { get; set; }
        public bool Visible { get; set; }
        public string Value { get; set; }

        public QRBox() 
        {
            Location = new Point(0, 0);
            Size = 40;
            BorderThickness = 0;
            BorderColor = Color.Black;
            Visible = true;
            Value = "";
        }

        public void Paint(Graphics gr, int zoom)
        {
            Zoom z = new Zoom(zoom);
            QRCodeGenerator QG = new QRCodeGenerator();
            var MyData = QG.CreateQrCode(Value, QRCodeGenerator.ECCLevel.H);
            var code = new QRCode(MyData);
            Image image = code.GetGraphic(50);
            RectangleF rec = new RectangleF(Location.X, Location.Y, z.NewValue(Size), z.NewValue(Size));
            gr.DrawImage(image, rec);
        }
    }

    public class PriceTagInfo
    {
        /// <summary>
        /// Наименование товара и т.д.
        /// </summary>
        public string Caption { get; set; }

        /// <summary>
        /// Описание товара
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Дополнительная информация о товаре, т.е. номер ТН, дата поступления, код в базе и т.д.
        /// </summary>
        public string TagInfo { get; set; }

        /// <summary>
        /// Строка или интернет ссылка будет отображаться как QR код
        /// </summary>
        public string QRcode { get; set; }

        /// <summary>
        /// Цена товара за 1 единицу
        /// </summary>
        public float Price { get; set; }

    }

}
