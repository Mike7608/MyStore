﻿
namespace MyShop.Cennik
{
    partial class FrmNewCennik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            PriceTag.PriceTagInfo priceTagInfo1 = new PriceTag.PriceTagInfo();
            PriceTag.Tag tag1 = new PriceTag.Tag();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BtnSaveDESCR = new System.Windows.Forms.Button();
            this.BtnOK = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.txtCODE = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtCena = new MyShop.NumberBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblTotalSCODE = new System.Windows.Forms.Label();
            this.txtSCODE = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnClearCountry = new System.Windows.Forms.Button();
            this.comboStranaProizv = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnInfo = new System.Windows.Forms.Button();
            this.txtDescr = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnOpenInExplore = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtNameTovar = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomerTN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.controlPriceTag1 = new PriceTag.ControlPriceTag();
            this.panelBottom.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.Color.DarkGray;
            this.panelBottom.Controls.Add(this.panel2);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 548);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1016, 63);
            this.panelBottom.TabIndex = 21;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.BtnSaveDESCR);
            this.panel2.Controls.Add(this.BtnOK);
            this.panel2.Controls.Add(this.BtnCancel);
            this.panel2.Location = new System.Drawing.Point(321, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(337, 54);
            this.panel2.TabIndex = 22;
            // 
            // BtnSaveDESCR
            // 
            this.BtnSaveDESCR.BackColor = System.Drawing.SystemColors.Control;
            this.BtnSaveDESCR.Enabled = false;
            this.BtnSaveDESCR.Image = global::MyShop.Properties.Resources.floppy64;
            this.BtnSaveDESCR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSaveDESCR.Location = new System.Drawing.Point(231, 8);
            this.BtnSaveDESCR.Name = "BtnSaveDESCR";
            this.BtnSaveDESCR.Size = new System.Drawing.Size(102, 35);
            this.BtnSaveDESCR.TabIndex = 25;
            this.BtnSaveDESCR.Text = "Сохранить";
            this.BtnSaveDESCR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.BtnSaveDESCR, "Сохранить описание товара в базе данных");
            this.BtnSaveDESCR.UseVisualStyleBackColor = false;
            this.BtnSaveDESCR.Click += new System.EventHandler(this.BtnSaveDESCR_Click);
            // 
            // BtnOK
            // 
            this.BtnOK.BackColor = System.Drawing.SystemColors.Control;
            this.BtnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOK.Location = new System.Drawing.Point(3, 8);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(102, 35);
            this.BtnOK.TabIndex = 23;
            this.BtnOK.Text = "OK";
            this.toolTip1.SetToolTip(this.BtnOK, "Принять все изменения и выйти");
            this.BtnOK.UseVisualStyleBackColor = false;
            this.BtnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.SystemColors.Control;
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.Location = new System.Drawing.Point(111, 8);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(102, 35);
            this.BtnCancel.TabIndex = 24;
            this.BtnCancel.Text = "Отмена";
            this.toolTip1.SetToolTip(this.BtnCancel, "Отменить все изменения и выйти");
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // txtCODE
            // 
            this.txtCODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtCODE.Location = new System.Drawing.Point(122, 86);
            this.txtCODE.Name = "txtCODE";
            this.txtCODE.ReadOnly = true;
            this.txtCODE.Size = new System.Drawing.Size(119, 20);
            this.txtCODE.TabIndex = 17;
            this.txtCODE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCODE.TextChanged += new System.EventHandler(this.txtCODE_TextChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.txtCena);
            this.groupBox5.Location = new System.Drawing.Point(286, 384);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(299, 121);
            this.groupBox5.TabIndex = 18;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Цена товара:";
            // 
            // txtCena
            // 
            this.txtCena.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCena.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtCena.Location = new System.Drawing.Point(20, 49);
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(261, 33);
            this.txtCena.TabIndex = 19;
            this.txtCena.Text = "0";
            this.txtCena.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCena.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtCena.TextChanged += new System.EventHandler(this.txtCena_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.lblTotalSCODE);
            this.groupBox4.Controls.Add(this.txtSCODE);
            this.groupBox4.Location = new System.Drawing.Point(12, 294);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(573, 84);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "QR код";
            // 
            // lblTotalSCODE
            // 
            this.lblTotalSCODE.AutoSize = true;
            this.lblTotalSCODE.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTotalSCODE.Location = new System.Drawing.Point(15, 17);
            this.lblTotalSCODE.Name = "lblTotalSCODE";
            this.lblTotalSCODE.Size = new System.Drawing.Size(10, 12);
            this.lblTotalSCODE.TabIndex = 9;
            this.lblTotalSCODE.Text = "0";
            this.lblTotalSCODE.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtSCODE
            // 
            this.txtSCODE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSCODE.Location = new System.Drawing.Point(14, 31);
            this.txtSCODE.MaxLength = 255;
            this.txtSCODE.Multiline = true;
            this.txtSCODE.Name = "txtSCODE";
            this.txtSCODE.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSCODE.Size = new System.Drawing.Size(553, 40);
            this.txtSCODE.TabIndex = 10;
            this.txtSCODE.TextChanged += new System.EventHandler(this.txtSCODE_TextChanged);
            this.txtSCODE.Leave += new System.EventHandler(this.txtSCODE_Leave);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.btnClearCountry);
            this.groupBox2.Controls.Add(this.comboStranaProizv);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btnInfo);
            this.groupBox2.Controls.Add(this.txtDescr);
            this.groupBox2.Location = new System.Drawing.Point(12, 92);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(573, 201);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Описание товара";
            // 
            // btnClearCountry
            // 
            this.btnClearCountry.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearCountry.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClearCountry.Location = new System.Drawing.Point(529, 161);
            this.btnClearCountry.Name = "btnClearCountry";
            this.btnClearCountry.Size = new System.Drawing.Size(27, 27);
            this.btnClearCountry.TabIndex = 30;
            this.btnClearCountry.Text = "X";
            this.toolTip1.SetToolTip(this.btnClearCountry, "Очистить поле \"Страна производства\"");
            this.btnClearCountry.UseVisualStyleBackColor = true;
            this.btnClearCountry.Click += new System.EventHandler(this.btnClearCountry_Click);
            // 
            // comboStranaProizv
            // 
            this.comboStranaProizv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboStranaProizv.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboStranaProizv.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboStranaProizv.FormattingEnabled = true;
            this.comboStranaProizv.Location = new System.Drawing.Point(154, 162);
            this.comboStranaProizv.Name = "comboStranaProizv";
            this.comboStranaProizv.Size = new System.Drawing.Size(375, 25);
            this.comboStranaProizv.TabIndex = 7;
            this.comboStranaProizv.SelectedValueChanged += new System.EventHandler(this.comboStranaProizv_SelectedValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Страна производства:";
            // 
            // btnInfo
            // 
            this.btnInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInfo.Enabled = false;
            this.btnInfo.Image = global::MyShop.Properties.Resources.info24b;
            this.btnInfo.Location = new System.Drawing.Point(535, 24);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(32, 31);
            this.btnInfo.TabIndex = 29;
            this.toolTip1.SetToolTip(this.btnInfo, "Информация о товаре [Ctrl+i]");
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // txtDescr
            // 
            this.txtDescr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDescr.Font = new System.Drawing.Font("Arial", 9.75F);
            this.txtDescr.Location = new System.Drawing.Point(11, 24);
            this.txtDescr.MaxLength = 1000;
            this.txtDescr.Multiline = true;
            this.txtDescr.Name = "txtDescr";
            this.txtDescr.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescr.Size = new System.Drawing.Size(518, 130);
            this.txtDescr.TabIndex = 5;
            this.txtDescr.TextChanged += new System.EventHandler(this.txtDescr_TextChanged);
            this.txtDescr.Enter += new System.EventHandler(this.txtDescr_Enter);
            this.txtDescr.Leave += new System.EventHandler(this.txtDescr_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnOpenInExplore);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtNameTovar);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(573, 80);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Наименование товара";
            // 
            // btnOpenInExplore
            // 
            this.btnOpenInExplore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpenInExplore.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnOpenInExplore.Enabled = false;
            this.btnOpenInExplore.Image = global::MyShop.Properties.Resources.earth_view;
            this.btnOpenInExplore.Location = new System.Drawing.Point(489, 47);
            this.btnOpenInExplore.Name = "btnOpenInExplore";
            this.btnOpenInExplore.Size = new System.Drawing.Size(25, 25);
            this.btnOpenInExplore.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btnOpenInExplore, "Открыть в браузере");
            this.btnOpenInExplore.UseVisualStyleBackColor = true;
            this.btnOpenInExplore.Click += new System.EventHandler(this.btnOpenInExplore_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(488, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 26);
            this.button1.TabIndex = 2;
            this.button1.Text = "Выбрать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtNameTovar
            // 
            this.txtNameTovar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNameTovar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNameTovar.Location = new System.Drawing.Point(11, 17);
            this.txtNameTovar.Name = "txtNameTovar";
            this.txtNameTovar.Size = new System.Drawing.Size(476, 57);
            this.txtNameTovar.TabIndex = 3;
            this.txtNameTovar.Text = "";
            this.txtNameTovar.SelectionChanged += new System.EventHandler(this.txtNameTovar_SelectionChanged);
            this.txtNameTovar.TextChanged += new System.EventHandler(this.txtNameTovar_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "Номер ТН:";
            // 
            // txtNomerTN
            // 
            this.txtNomerTN.Location = new System.Drawing.Point(122, 55);
            this.txtNomerTN.MaxLength = 20;
            this.txtNomerTN.Name = "txtNomerTN";
            this.txtNomerTN.Size = new System.Drawing.Size(118, 25);
            this.txtNomerTN.TabIndex = 15;
            this.txtNomerTN.TextChanged += new System.EventHandler(this.txtNomerTN_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Дата ТН:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(122, 24);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(118, 25);
            this.dateTimePicker1.TabIndex = 13;
            this.dateTimePicker1.Value = new System.DateTime(2020, 12, 26, 0, 0, 0, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtCODE);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtNomerTN);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(12, 384);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(268, 121);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Информация о поступлении";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 17);
            this.label5.TabIndex = 16;
            this.label5.Text = "Код товара 1С:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 548);
            this.panel1.TabIndex = 0;
            this.panel1.Resize += new System.EventHandler(this.panel1_Resize);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.splitter1.Location = new System.Drawing.Point(600, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 548);
            this.splitter1.TabIndex = 30;
            this.splitter1.TabStop = false;
            // 
            // controlPriceTag1
            // 
            this.controlPriceTag1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.controlPriceTag1.ControlPanelVisible = true;
            this.controlPriceTag1.Dock = System.Windows.Forms.DockStyle.Fill;
            priceTagInfo1.Caption = null;
            priceTagInfo1.Description = null;
            priceTagInfo1.Price = 0F;
            priceTagInfo1.QRcode = null;
            priceTagInfo1.TagInfo = null;
            this.controlPriceTag1.Info = priceTagInfo1;
            this.controlPriceTag1.Location = new System.Drawing.Point(603, 0);
            this.controlPriceTag1.Margin = new System.Windows.Forms.Padding(3, 7458, 3, 7458);
            this.controlPriceTag1.Name = "controlPriceTag1";
            tag1.BackColor = System.Drawing.Color.White;
            tag1.BorderColor = System.Drawing.Color.Black;
            tag1.BorderThickness = 0F;
            tag1.Location = new System.Drawing.Point(0, 0);
            tag1.Name = "Standard";
            tag1.Size = new System.Drawing.Size(355, 255);
            tag1.Zoom = 100;
            this.controlPriceTag1.PriceTag = tag1;
            this.controlPriceTag1.PriceTagDefault = 1;
            this.controlPriceTag1.Size = new System.Drawing.Size(413, 548);
            this.controlPriceTag1.TabIndex = 20;
            this.controlPriceTag1.Zoom = 100;
            // 
            // FrmNewCennik
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1016, 611);
            this.Controls.Add(this.controlPriceTag1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelBottom);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.KeyPreview = true;
            this.Name = "FrmNewCennik";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Создание или редактирование ценника";
            this.Load += new System.EventHandler(this.FrmNewCennik_Load);
            this.Shown += new System.EventHandler(this.FrmNewCennik_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmNewCennik_KeyDown);
            this.Resize += new System.EventHandler(this.FrmNewCennik_Resize);
            this.panelBottom.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.TextBox txtCODE;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtSCODE;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox txtDescr;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomerTN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblTotalSCODE;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnOK;
        private NumberBox txtCena;
        private System.Windows.Forms.ComboBox comboStranaProizv;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Panel panel1;
        private PriceTag.ControlPriceTag controlPriceTag1;
        private System.Windows.Forms.RichTextBox txtNameTovar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button BtnSaveDESCR;
        private System.Windows.Forms.Button btnOpenInExplore;
        private System.Windows.Forms.Button btnClearCountry;
    }
}