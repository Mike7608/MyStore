﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using PriceTag;
using System.Drawing.Printing;

namespace MyShop.Cennik
{
    public partial class PrintCennik : PrintDocument
    {
        private DataTable dt= new DataTable();
        private ListPriceTag listPtg;

        //private int CurrentPage;

        private int xRow;


        //private int FromPage = 1;
        //private int ToPage = 1;

        public PrintCennik(DataTable dataTable, ListPriceTag list)
        {
            InitializeComponent();

            listPtg = list;

            dt = dataTable.Copy();

            if (dt.Columns.Contains("SizeTag") == false)
            {
                DataColumn dc = new DataColumn("SizeTag", typeof(string));
                dt.Columns.Add(dc);
            }


            dt = SortBySizeTag(dt);


            this.DefaultPageSettings.Landscape = true;
            this.DefaultPageSettings.Margins.Right = 30;
            this.DefaultPageSettings.Margins.Top = 20;
            this.DefaultPageSettings.Margins.Left = 30;
            this.DefaultPageSettings.Margins.Bottom = 20;
            xRow = 0;
        }

        private DataTable SortBySizeTag(DataTable dt)
        {
            foreach(DataRow dr in dt.Rows)
            {
                dr.BeginEdit();
                dr["SizeTag"] = SizeTag((int)dr["type"]);
                dr.EndEdit();
            }

            DataView dv = dt.DefaultView;
            dv.Sort = "SizeTag desc";//Сортируем по убыванию
            DataTable sortedDT = dv.ToTable();
            return sortedDT;
        }

        private string SizeTag(int index)
        {
            return listPtg.ListTag[index].Size.Width.ToString() + ":" + listPtg.ListTag[index].Size.Height.ToString();
        }


        private void PrintCennik_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //CurrentPage++;

            int posX = e.MarginBounds.Left, posY = e.MarginBounds.Top;
            int x;
            int Hi=0;

            for (x = xRow; x < dt.Rows.Count; x++)
            {
                DataRow dr = dt.Rows[x];
                Tag tag = new Tag();
                int iType = (int)dr["type"];
                tag = listPtg.ListTag[iType];//по форме стиля получаем размеры
                tag.Zoom = 100;

                if (posX == e.MarginBounds.Left)
                {
                    Hi = tag.Size.Height;
                }

                if (tag.Size.Height < Hi)
                {
                    posX = e.MarginBounds.Left;
                    posY += Hi+1;
                    Hi = tag.Size.Height;
                }

                if (posY >= e.MarginBounds.Top & posY <= e.MarginBounds.Bottom - tag.Size.Height)
                {
                    if (posX >= e.MarginBounds.Left & posX <= e.MarginBounds.Right - tag.Size.Width)
                    {


                        tag.priceTagInfo.Caption = dr["NameTovar"].ToString();
                        tag.priceTagInfo.Description = dr["descr"].ToString();
                        tag.priceTagInfo.TagInfo = dr["code"].ToString() + " | " + ((DateTime)dr["data"]).ToShortDateString() + " | " + dr["nDoc"].ToString();
                        tag.priceTagInfo.Price = Convert.ToSingle(dr["cena"]);
                        tag.priceTagInfo.QRcode = dr["scode"].ToString();
                        tag.Location = new System.Drawing.Point(posX, posY);
                        tag.Paint(e.Graphics);                   
                        posX += tag.Size.Width + 1;



                        if (posX >= e.MarginBounds.Right-tag.Size.Width)
                        {

                            posX = e.MarginBounds.Left;
                            posY += tag.Size.Height + 1;
                        }
                    }
                }
                else
                {

                    //if (CurrentPage<FromPage)
                    //{
                    //    posX = e.MarginBounds.Left;
                    //    posY = e.MarginBounds.Top;
                    //    e.Graphics.Clear(System.Drawing.Color.White);
                    //    CurrentPage++;
                    //}
                    //else
                    //{ 
                        e.HasMorePages = true;
                        xRow=x;
                        break;
                    //}


                }



            }

        }

        private void PrintCennik_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            //CurrentPage = 0;
            //FromPage = this.DefaultPageSettings.PrinterSettings.FromPage;
            //ToPage = this.DefaultPageSettings.PrinterSettings.ToPage;
        }

        private void PrintCennik_EndPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            xRow = 0;
            //this.DefaultPageSettings.PrinterSettings.FromPage = 1;
            //this.DefaultPageSettings.PrinterSettings.ToPage = CurrentPage;
            //this.DefaultPageSettings.PrinterSettings.MaximumPage = CurrentPage;
            //this.DefaultPageSettings.PrinterSettings.MinimumPage = 1;
            //this.DefaultPageSettings.Landscape = true;

        }
    }
}
