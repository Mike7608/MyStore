﻿
namespace PriceTag
{
    partial class ControlPriceTag
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.comboListForm = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnUpdate = new System.Windows.Forms.ToolStripButton();
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelFon = new System.Windows.Forms.Panel();
            this.panelPriceTag = new System.Windows.Forms.Panel();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.btnZoomMinus = new System.Windows.Forms.ToolStripButton();
            this.ComboBoxZoom = new System.Windows.Forms.ToolStripComboBox();
            this.btnZoomPlus = new System.Windows.Forms.ToolStripButton();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.toolStrip1.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.panelFon.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.toolStripContainer1.BottomToolStripPanel.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.comboListForm,
            this.toolStripSeparator1,
            this.btnUpdate});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(286, 25);
            this.toolStrip1.TabIndex = 21;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(102, 22);
            this.toolStripLabel1.Text = "Формат ценника:";
            // 
            // comboListForm
            // 
            this.comboListForm.AutoSize = false;
            this.comboListForm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboListForm.Name = "comboListForm";
            this.comboListForm.Size = new System.Drawing.Size(150, 23);
            this.comboListForm.SelectedIndexChanged += new System.EventHandler(this.comboListForm_SelectedIndexChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnUpdate
            // 
            this.btnUpdate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnUpdate.Image = global::MyShop.Properties.Resources.icons8_перезапуск_24;
            this.btnUpdate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(23, 22);
            this.btnUpdate.Text = "Обновить изображение";
            this.btnUpdate.ToolTipText = "Обновить изображение";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // panelMain
            // 
            this.panelMain.AutoScroll = true;
            this.panelMain.Controls.Add(this.panelFon);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(543, 352);
            this.panelMain.TabIndex = 23;
            // 
            // panelFon
            // 
            this.panelFon.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelFon.Controls.Add(this.panelPriceTag);
            this.panelFon.Location = new System.Drawing.Point(3, 3);
            this.panelFon.Name = "panelFon";
            this.panelFon.Size = new System.Drawing.Size(303, 205);
            this.panelFon.TabIndex = 23;
            // 
            // panelPriceTag
            // 
            this.panelPriceTag.BackColor = System.Drawing.SystemColors.Window;
            this.panelPriceTag.Location = new System.Drawing.Point(10, 10);
            this.panelPriceTag.Name = "panelPriceTag";
            this.panelPriceTag.Size = new System.Drawing.Size(282, 187);
            this.panelPriceTag.TabIndex = 0;
            this.panelPriceTag.Paint += new System.Windows.Forms.PaintEventHandler(this.panelPriceTag_Paint);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel3,
            this.btnZoomMinus,
            this.ComboBoxZoom,
            this.btnZoomPlus});
            this.toolStrip2.Location = new System.Drawing.Point(3, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(219, 25);
            this.toolStrip2.TabIndex = 24;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(62, 22);
            this.toolStripLabel3.Text = "Масштаб:";
            // 
            // btnZoomMinus
            // 
            this.btnZoomMinus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnZoomMinus.Image = global::MyShop.Properties.Resources.zoomD;
            this.btnZoomMinus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnZoomMinus.Name = "btnZoomMinus";
            this.btnZoomMinus.Size = new System.Drawing.Size(23, 22);
            this.btnZoomMinus.Text = "Уменьшить";
            this.btnZoomMinus.ToolTipText = "Уменьшить";
            this.btnZoomMinus.Click += new System.EventHandler(this.btnZoomMinus_Click);
            // 
            // ComboBoxZoom
            // 
            this.ComboBoxZoom.Items.AddRange(new object[] {
            "500%",
            "400%",
            "300%",
            "200%",
            "100%",
            "90%",
            "80%",
            "70%",
            "60%",
            "50%",
            "40%",
            "30%",
            "20%",
            "10%",
            "5%"});
            this.ComboBoxZoom.Name = "ComboBoxZoom";
            this.ComboBoxZoom.Size = new System.Drawing.Size(75, 25);
            this.ComboBoxZoom.SelectedIndexChanged += new System.EventHandler(this.ComboBoxZoom_SelectedIndexChanged);
            this.ComboBoxZoom.TextChanged += new System.EventHandler(this.ComboBoxZoom_TextChanged);
            // 
            // btnZoomPlus
            // 
            this.btnZoomPlus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnZoomPlus.Image = global::MyShop.Properties.Resources.zoomA;
            this.btnZoomPlus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnZoomPlus.Name = "btnZoomPlus";
            this.btnZoomPlus.Size = new System.Drawing.Size(23, 22);
            this.btnZoomPlus.Text = "Увеличить";
            this.btnZoomPlus.Click += new System.EventHandler(this.btnZoomPlus_Click);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.BottomToolStripPanel
            // 
            this.toolStripContainer1.BottomToolStripPanel.Controls.Add(this.toolStrip2);
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.panelMain);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(543, 352);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(543, 402);
            this.toolStripContainer1.TabIndex = 25;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // ControlPriceTag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "ControlPriceTag";
            this.Size = new System.Drawing.Size(543, 402);
            this.Load += new System.EventHandler(this.ControlPriceTag_Load);
            this.Resize += new System.EventHandler(this.ControlPriceTag_Resize);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.panelFon.ResumeLayout(false);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.toolStripContainer1.BottomToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.BottomToolStripPanel.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox comboListForm;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnUpdate;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelFon;
        private System.Windows.Forms.Panel panelPriceTag;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton btnZoomMinus;
        private System.Windows.Forms.ToolStripComboBox ComboBoxZoom;
        private System.Windows.Forms.ToolStripButton btnZoomPlus;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
    }
}
