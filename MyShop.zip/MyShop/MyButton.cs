﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop
{
    public partial class MyButton : Button
    {
        public MyButton()
        {
            InitializeComponent();
            base.Width = 58;
            base.Height = 64;
            base.FlatStyle = FlatStyle.Flat;
            base.ForeColor = Color.White;
            base.BackColor = Color.DimGray;
            base.FlatAppearance.BorderColor = Color.Gray;
            base.FlatAppearance.MouseDownBackColor = Color.FromArgb(64, 64, 64);
            base.FlatAppearance.MouseOverBackColor = Color.Gray;
            base.TextAlign = ContentAlignment.BottomCenter;
            base.Font = new Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            base.ImageAlign = ContentAlignment.TopCenter;
        }
    }
}
