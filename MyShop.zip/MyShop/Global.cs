﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.Data;

namespace MyShop
{
    static class Global
    {

        static public string NameTableOstatki
        {
            get
            {
                return "REMAINS";
            }
        }


        static public Font Default = new Font("Segoe UI", 10, FontStyle.Regular);

        static public frmMain mainForm;

        static public KursValut[] KursValuts = new KursValut[3];
        
        static public float KursPerescheta { get; set; }

        static public DataSet mainDataSet = new DataSet();

        static public string SqlConnectionString { get; set; }

        static public PrintDocument printDocument { get; set; }

        static public void OpenForm(Form frm)
        {

            foreach (Form form in Global.mainForm.MdiChildren)
            {
                if (form.Text == frm.Text)
                {
                    form.Activate();
                }
                else
                {
                    frm.MdiParent = Global.mainForm;
                    frm.Show();
                }
            }

        }

        public class KursValut
        {
            public string Name { get; set; }
            public int Scale { get; set; }
            public float Rate { get; set; }
        }
    }
}
