﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Drawing;

namespace MyShop.MAGAZIN
{
    /// <summary>
    /// Вывод на печать товарного чека
    /// </summary>
    class PrintPreviewSalesReceipt:System.Drawing.Printing.PrintDocument
    {
        DataTable _dt;
        Rekvizits r = new Rekvizits();
        DateTime _data;
        public PrintPreviewSalesReceipt(DataTable dt, DateTime data)
        {
            _dt = dt;
            _data = data;
            this.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintPreviewSalesReceipt_PrintPage);
            r.Load();
          
        }


        private void PrintPreviewSalesReceipt_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int posX = 80, posY = 60;

            Font fontTitleBold = new Font("Arial", 10, FontStyle.Bold);
            Font fontText = new Font("Arial", 9, FontStyle.Regular);
            Font fontTitleMain = new Font("Arial", 14, FontStyle.Bold);

            e.Graphics.DrawString(r.Name, fontTitleBold, Brushes.Black, posX, posY);
            posY += 22;
            e.Graphics.DrawString("УНП: " + r.UNP, fontText, Brushes.Black, posX, posY);
            posY += 17;
            e.Graphics.DrawString(r.Adres, fontText, Brushes.Black, posX, posY);
            posY += 17;
            e.Graphics.DrawString("тел./факс: "+r.Phone, fontText, Brushes.Black, posX, posY);
            posY += 17;
            e.Graphics.DrawString("E-mail: "+r.e_mail, fontText, Brushes.Black, posX, posY);
            posY += 17;
            e.Graphics.DrawString("ТОВАРНЫЙ ЧЕК", fontTitleMain, Brushes.Black, posX+250, posY);
            posY += 26;

            TextBoxHeadTable("№",posX, posY, 30, 25, e);//30
            TextBoxHeadTable("Наименование товара/услуги", posX + 30, posY, 300, 25, e);//300
            TextBoxHeadTable("Ед.изм.", posX + 30 + 300, posY, 50, 25, e);//50
            TextBoxHeadTable("Кол-во", posX + 30 + 300 + 50, posY, 50, 25, e);//50
            TextBoxHeadTable("Цена", posX + 30 + 300 + 50 + 50, posY, 60, 25, e);//60 Цена (без НДС)
            TextBoxHeadTable("Сумма", posX + 30 + 300 + 50 + 50 + 60, posY, 60, 25, e);//60 Сумма (без НДС)
            TextBoxHeadTable("НДС,", posX + 30 + 300 + 50 + 50 + 60 + 60, posY, 30, 25, e);//30 НДС, %
            TextBoxHeadTable("Сумма НДС", posX + 30 + 300 + 50 + 50 + 60 + 60 + 30, posY, 60, 25, e);//60
            TextBoxHeadTable("Всего с НДС", posX + 30 + 300 + 50 + 50 + 60 + 60 + 30 + 60, posY, 60, 25, e);//60

            Font font2 = new Font("Arial", 6, FontStyle.Regular);
            e.Graphics.DrawString("п/п", font2, Brushes.Black, posX + 10, posY + 12);
            e.Graphics.DrawString("(без НДС)", font2, Brushes.Black, posX + 440, posY + 12);
            e.Graphics.DrawString("(без НДС)", font2, Brushes.Black, posX + 500, posY + 12);
            e.Graphics.DrawString("%", font2, Brushes.Black, posX + 558, posY + 12);
            
            posY += 32;

            int x = 0;
            double itKol=0, itSummBezNDS=0, itSummaNDS=0, itSummaSnds=0;
            foreach(DataRow dr in _dt.Rows)
            {
                //if (dr["Sel"].ToString() == "True")
                //{
                    e.Graphics.DrawString((x + 1).ToString(), fontText, Brushes.Black, posX, posY); // номер по порядку
                    RectangleF NameTov = new RectangleF(posX+30+2, posY, 300, 17);

                    e.Graphics.DrawString(dr["DESCR"].ToString(), fontText, Brushes.Black, NameTov);//наименование товара

                    e.Graphics.DrawString("шт.", fontText, Brushes.Black, posX + 30 + 300 + 10, posY); //шт.

                    double Kol = Convert.ToDouble(dr["Kol"]);
                    itKol += Kol;
                    Single lw = e.Graphics.MeasureString(Kol.ToString(), fontText).Width;//получаем длину строки
                    RectangleF KolF = new RectangleF(posX + 30 + 300 + 50+(50-lw-5), posY, 50, 17);
                    e.Graphics.DrawString(Kol.ToString().Replace(",000",""), fontText, Brushes.Black, KolF);

                    double Cena, Summa, stavkaNDS, SummaBezNDS, SummaNDS, CenaBezNDS;
                    Cena =  Convert.ToDouble(dr["Cena"]);
                    Summa = Convert.ToDouble(dr["Summa"]);
                    itSummaSnds += Summa;
                    stavkaNDS = r.StavkaNDS;
                    SummaNDS = (Summa * stavkaNDS) / (100 + stavkaNDS);
                    itSummaNDS += SummaNDS;
                    SummaBezNDS = Summa-SummaNDS;
                    itSummBezNDS += SummaBezNDS;
                    CenaBezNDS = SummaBezNDS / Kol;

                    //Цена без НДС
                    lw = e.Graphics.MeasureString(string.Format("{0:f}",CenaBezNDS), fontText).Width;//получаем длину строки
                    RectangleF CenaF = new RectangleF(posX + 30 + 300 + 50 + 50 +(60 - lw - 5), posY, 60, 17);
                    e.Graphics.DrawString(string.Format("{0:f}", CenaBezNDS), fontText, Brushes.Black, CenaF);

                    //Сумма без НДС
                    lw = e.Graphics.MeasureString(string.Format("{0:f}", SummaBezNDS), fontText).Width;//получаем длину строки
                    RectangleF SF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60+ (60 - lw - 5), posY, 60, 17);
                    e.Graphics.DrawString(string.Format("{0:f}", SummaBezNDS), fontText, Brushes.Black, SF);

                    //Ставка НДС
                    lw = e.Graphics.MeasureString(string.Format("{0}", stavkaNDS), fontText).Width;//получаем длину строки
                    SF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60 + 60+ (30 - lw - 5), posY, 30, 17);
                    e.Graphics.DrawString(string.Format("{0}", stavkaNDS), fontText, Brushes.Black, SF);

                    //Сумма НДС
                    lw = e.Graphics.MeasureString(string.Format("{0:f}", SummaNDS), fontText).Width;//получаем длину строки
                    SF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60 + 60 + 30 +(60 - lw - 5), posY, 60, 17);
                    e.Graphics.DrawString(string.Format("{0:f}", SummaNDS), fontText, Brushes.Black, SF);

                    //Сумма c НДС
                    lw = e.Graphics.MeasureString(string.Format("{0:f}", Summa), fontText).Width;//получаем длину строки
                    SF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60 + 60 + 30 + 60 + (60 - lw - 5), posY, 60, 17);
                    e.Graphics.DrawString(string.Format("{0:f}", Summa), fontText, Brushes.Black, SF);
                    x++;
                    posY += 17;
                //}

            }

            posY += 5;
            e.Graphics.DrawLine(new Pen(Brushes.Black, 1), posX, posY, 680+e.MarginBounds.Left, posY);
            posY += 5;

            Font fontTextBold = new Font("Arial", 9, FontStyle.Bold);

            e.Graphics.DrawString("ИТОГО:", fontTextBold, Brushes.Black, posX + 32, posY);

            //Итого количество
            Single l = e.Graphics.MeasureString(itKol.ToString(), fontTextBold).Width;//получаем длину строки
            RectangleF iF = new RectangleF(posX + 30 + 300 + 50 + (50 - l - 5), posY, 50, 17);
            e.Graphics.DrawString(itKol.ToString(), fontTextBold, Brushes.Black, iF);


            //Итого Сумма без НДС
            l = e.Graphics.MeasureString(string.Format("{0:f}", itSummBezNDS), fontTextBold).Width;//получаем длину строки
            iF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60 +  (60 - l - 5), posY, 60, 17);
            e.Graphics.DrawString(string.Format("{0:f}", itSummBezNDS), fontTextBold, Brushes.Black, iF);


            // Сумма НДС
            l = e.Graphics.MeasureString(string.Format("{0:f}", itSummaNDS), fontTextBold).Width;//получаем длину строки
            iF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60 + 60 + 30 + (60 - l - 5), posY, 60, 17);
            e.Graphics.DrawString(string.Format("{0:f}", itSummaNDS), fontTextBold, Brushes.Black, iF);

            // Сумма c НДС
            l = e.Graphics.MeasureString(string.Format("{0:f}", itSummaSnds), fontTextBold).Width;//получаем длину строки
            iF = new RectangleF(posX + 30 + 300 + 50 + 50 + 60 + 60 + 30 + 60 + (60 - l - 5), posY, 60, 17);
            e.Graphics.DrawString(string.Format("{0:f}", itSummaSnds), fontTextBold, Brushes.Black, iF);

            posY += 30;

            NumberToTextRUS numtotext = new NumberToTextRUS();

            string[] Val=string.Format("{0:f}", itSummaSnds).Split(',');
            int rub, kop;
            rub = Convert.ToInt32(Val[0]);
            kop = Convert.ToInt32(Val[1]);
            e.Graphics.DrawString("ВСЕГО С НДС: " + numtotext.Str(rub) + "руб. " + kop.ToString() + " коп.", fontTextBold, Brushes.Black, posX, posY);
            posY += 20;
            string[] ValNDS = string.Format("{0:f}", itSummaNDS).Split(',');
            rub = Convert.ToInt32(ValNDS[0]);
            kop = Convert.ToInt32(ValNDS[1]);
            e.Graphics.DrawString("Сумма НДС: " + numtotext.Str(rub) + "руб. "+ kop.ToString() + " коп.", fontTextBold, Brushes.Black, posX, posY);

            posY += 30;

            e.Graphics.DrawString("Дата: " + _data.ToShortDateString(), fontText, Brushes.Black, posX, posY);
            posY += 50;
            e.Graphics.DrawString("М.П.                                    Подпись___________________________________", fontText, Brushes.Black, posX+150, posY);

        }

        private void TextBoxHeadTable(string Text, float PosX, float PosY, float Width, float Height, System.Drawing.Printing.PrintPageEventArgs e)
        {

            Font fontMain = new Font("Arial", 6, FontStyle.Regular);
            RectangleF R = new RectangleF(PosX, PosY, Width, Height);
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240,240,240)), R);
            e.Graphics.DrawRectangle(new Pen(Color.Black, 1), PosX, PosY, Width, Height);

            float posXnew = (Width - e.Graphics.MeasureString(Text, fontMain).Width) / 2;
            RectangleF Rt = new RectangleF(PosX+2 + posXnew, PosY+2, Width-4, Height-4);
            e.Graphics.DrawString(Text, fontMain, Brushes.Black, Rt);
        }
}
}
