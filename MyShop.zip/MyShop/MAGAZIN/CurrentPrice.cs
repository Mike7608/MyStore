﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.MAGAZIN
{
    public partial class CurrentPrice : UserControl
    {
        Color _colorText;
        Color _colorDigits;
        Font _fontText1;
        Font _fontText2;
        Font _fontDig1;
        Font _fontDig2;
        decimal _price;
        int _bordertik;
        Color _borderColor;
        public Color ColorText
        {
            get
            {
                return _colorText;
            }
            set
            {
                _colorText = value;
                lblText1.ForeColor = value;
                lblText2.ForeColor = value;
            }
        }

        public Color ColorDigits
        {
            get
            {
                return _colorDigits;
            }
            set
            {
                _colorDigits = value;
                lblDig1.ForeColor = value;
                lblDig2.ForeColor = value;
            }
        }

        public Font FontText1
        {
            get
            {
                return _fontText1;
            }
            set
            {
                _fontText1 = value;
                lblText1.Font = value;
            }
        }

        public Font FontText2
        {
            get
            {
                return _fontText2;
            }
            set
            {
                _fontText2 = value;
                lblText2.Font = value;
            }
        }

        public Font FontDigits1
        {
            get
            {
                return _fontDig1;
            }
            set
            {
                _fontDig1 = value;
                lblDig1.Font = value;
            }
        }

        public Font FontDigits2
        {
            get
            {
                return _fontDig2;
            }
            set
            {
                _fontDig2 = value;
                lblDig2.Font = value;
            }
        }

        public string Text1
        {
            get
            {
                return lblText1.Text;
            }
            set
            {
                lblText1.Text = value;
            }
        }

        public string Text2
        {
            get
            {
                return lblText2.Text;
            }
            set
            {
                lblText2.Text = value;
            }
        }

        public decimal Price
        {
            get { return _price; }
            set 
            { 
                _price = value;
                CenaToRubKop(value);
            }
        }


        public int BorderThickness
        {
            get { return _bordertik; }
            set { _bordertik = value; }
        }

        public Color BorderColor
        {
            get { return _borderColor; }
            set
            {
                _borderColor = value;

            }
        }


        public CurrentPrice()
        {
            InitializeComponent();

            ColorDigits = Color.White;
            ColorText = Color.White;
            FontText1 = new Font("Segoe UI", 14);
            FontText2 = new Font("Segoe UI", 10);
            FontDigits1 = new Font("Segoe UI Semibold", 22, FontStyle.Bold);
            FontDigits2 = new Font("Segoe UI Semibold", 18, FontStyle.Bold);
            Price = 10.10M;
            BorderColor = Color.White;
            BorderThickness = 0;

            Graphics g = this.CreateGraphics();
            Rectangle rectangle = new Rectangle(0 + (BorderThickness / 2), 0 + (BorderThickness / 2), this.Width - BorderThickness, this.Height - BorderThickness);
            Pen pen = new Pen(BorderColor, 2);
            g.DrawRectangle(pen, rectangle);
        }

        private void CenaToRubKop(decimal cena)
        {
            decimal RUB;
            int kop;
            decimal tmpR = Math.Truncate(cena);
            RUB = (int)tmpR;
            decimal tmp = cena - RUB;
            kop = (int)(tmp * 100);
            lblDig1.Text = RUB.ToString();
            if (kop < 10)
            {
                lblDig2.Text = "0" + kop.ToString();
            }
            else
            {
                lblDig2.Text = kop.ToString();
            }
        }

        private void CurrentPrice_Paint(object sender, PaintEventArgs e)
        {
            if (BorderThickness > 0)
            {
                Rectangle rectangle = new Rectangle(0 + (BorderThickness / 2), 0 + (BorderThickness / 2), this.Width - BorderThickness, this.Height - BorderThickness);
                Pen pen = new Pen(BorderColor, BorderThickness);
                e.Graphics.DrawRectangle(pen, rectangle);
            }
        }


    }
}
