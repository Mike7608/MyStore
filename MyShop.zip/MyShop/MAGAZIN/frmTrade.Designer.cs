﻿
namespace MyShop.MAGAZIN
{
    partial class FrmTrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTrade));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnExit = new MyShop.MyButton();
            this.panelBasketInfo = new System.Windows.Forms.Panel();
            this.panelBasket = new System.Windows.Forms.Panel();
            this.lblBasketKol = new System.Windows.Forms.Label();
            this.panelIcon = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblBasketSumma = new System.Windows.Forms.Label();
            this.btnFilterClear = new System.Windows.Forms.Button();
            this.findTextCena1 = new MyShop.FindTextCena();
            this.label1 = new System.Windows.Forms.Label();
            this.dgTovar = new System.Windows.Forms.DataGridView();
            this.CODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameTovar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.добавитьВКорзинуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.корзинаТоваровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.информацияОТовареToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripSales = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.обновитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.установитьснятьОШИБКУToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьПримечаниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.печатьТоварногоЧекаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblSummaSales = new System.Windows.Forms.Label();
            this.btnInfo = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.contextMenuStripPrice = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ценаВходнаяtoolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ценаРеализацииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ценаПоКурсуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentPriceVhod = new MyShop.MAGAZIN.CurrentPrice();
            this.currentPriceCena = new MyShop.MAGAZIN.CurrentPrice();
            this.currentPricePoKursu = new MyShop.MAGAZIN.CurrentPrice();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelButtonDG = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.uscInfoTovar1 = new MyShop.Ostatki.uscInfoTovar();
            this.panelTop.SuspendLayout();
            this.panelBasketInfo.SuspendLayout();
            this.panelBasket.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTovar)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStripSales.SuspendLayout();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.contextMenuStripPrice.SuspendLayout();
            this.panelButtonDG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelTop.Controls.Add(this.btnExit);
            this.panelTop.Controls.Add(this.panelBasketInfo);
            this.panelTop.Controls.Add(this.btnFilterClear);
            this.panelTop.Controls.Add(this.findTextCena1);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1179, 76);
            this.panelTop.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DimGray;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = global::MyShop.Properties.Resources.arrow_left_w_24;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExit.Location = new System.Drawing.Point(3, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(52, 63);
            this.btnExit.TabIndex = 5;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panelBasketInfo
            // 
            this.panelBasketInfo.Controls.Add(this.panelBasket);
            this.panelBasketInfo.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBasketInfo.Location = new System.Drawing.Point(986, 0);
            this.panelBasketInfo.Name = "panelBasketInfo";
            this.panelBasketInfo.Size = new System.Drawing.Size(193, 76);
            this.panelBasketInfo.TabIndex = 3;
            // 
            // panelBasket
            // 
            this.panelBasket.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelBasket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelBasket.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBasket.Controls.Add(this.lblBasketKol);
            this.panelBasket.Controls.Add(this.panelIcon);
            this.panelBasket.Controls.Add(this.label2);
            this.panelBasket.Controls.Add(this.lblBasketSumma);
            this.panelBasket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelBasket.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.panelBasket.Location = new System.Drawing.Point(11, 8);
            this.panelBasket.Name = "panelBasket";
            this.panelBasket.Size = new System.Drawing.Size(172, 60);
            this.panelBasket.TabIndex = 6;
            this.panelBasket.Click += new System.EventHandler(this.panelBasket_Click);
            this.panelBasket.Paint += new System.Windows.Forms.PaintEventHandler(this.panelBasket_Paint);
            this.panelBasket.MouseEnter += new System.EventHandler(this.panelBasket_MouseEnter);
            this.panelBasket.MouseLeave += new System.EventHandler(this.panelBasket_MouseLeave);
            // 
            // lblBasketKol
            // 
            this.lblBasketKol.BackColor = System.Drawing.Color.Transparent;
            this.lblBasketKol.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBasketKol.ForeColor = System.Drawing.Color.White;
            this.lblBasketKol.Location = new System.Drawing.Point(44, 5);
            this.lblBasketKol.Margin = new System.Windows.Forms.Padding(0);
            this.lblBasketKol.Name = "lblBasketKol";
            this.lblBasketKol.Size = new System.Drawing.Size(25, 25);
            this.lblBasketKol.TabIndex = 2;
            this.lblBasketKol.Text = "0";
            this.lblBasketKol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblBasketKol, "Суммароное количество товаров в корзине");
            this.lblBasketKol.TextChanged += new System.EventHandler(this.lblBasketKol_TextChanged);
            this.lblBasketKol.Paint += new System.Windows.Forms.PaintEventHandler(this.lblBasketKol_Paint);
            // 
            // panelIcon
            // 
            this.panelIcon.BackColor = System.Drawing.Color.Transparent;
            this.panelIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelIcon.BackgroundImage")));
            this.panelIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelIcon.Location = new System.Drawing.Point(17, 5);
            this.panelIcon.Name = "panelIcon";
            this.panelIcon.Size = new System.Drawing.Size(43, 38);
            this.panelIcon.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "КОРЗИНА";
            // 
            // lblBasketSumma
            // 
            this.lblBasketSumma.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold);
            this.lblBasketSumma.ForeColor = System.Drawing.Color.White;
            this.lblBasketSumma.Location = new System.Drawing.Point(63, 24);
            this.lblBasketSumma.Margin = new System.Windows.Forms.Padding(0);
            this.lblBasketSumma.Name = "lblBasketSumma";
            this.lblBasketSumma.Size = new System.Drawing.Size(104, 32);
            this.lblBasketSumma.TabIndex = 4;
            this.lblBasketSumma.Text = "0,00";
            this.lblBasketSumma.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.toolTip1.SetToolTip(this.lblBasketSumma, "Сумма корзины [F9]");
            this.lblBasketSumma.TextChanged += new System.EventHandler(this.lblBasketSumma_TextChanged);
            // 
            // btnFilterClear
            // 
            this.btnFilterClear.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnFilterClear.FlatAppearance.BorderSize = 2;
            this.btnFilterClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilterClear.Image = ((System.Drawing.Image)(resources.GetObject("btnFilterClear.Image")));
            this.btnFilterClear.Location = new System.Drawing.Point(657, 17);
            this.btnFilterClear.Name = "btnFilterClear";
            this.btnFilterClear.Size = new System.Drawing.Size(35, 35);
            this.btnFilterClear.TabIndex = 2;
            this.toolTip1.SetToolTip(this.btnFilterClear, "Сбросить поиск [Ctrl+Delete]");
            this.btnFilterClear.UseVisualStyleBackColor = true;
            this.btnFilterClear.Click += new System.EventHandler(this.BtnFilterClear_Click);
            // 
            // findTextCena1
            // 
            this.findTextCena1.BackColor = System.Drawing.Color.White;
            this.findTextCena1.BorderColor = System.Drawing.Color.LightGray;
            this.findTextCena1.BorederTickness = 2;
            this.findTextCena1.CenaLenght = 0;
            this.findTextCena1.FindTextBackColor = System.Drawing.Color.White;
            this.findTextCena1.FindTextForeColor = System.Drawing.Color.Black;
            this.findTextCena1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findTextCena1.ForeColor = System.Drawing.Color.Black;
            this.findTextCena1.HelpTextCena = "Цена";
            this.findTextCena1.HelpTextFind = "Код и/или наименование товара";
            this.findTextCena1.Location = new System.Drawing.Point(217, 17);
            this.findTextCena1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.findTextCena1.Name = "findTextCena1";
            this.findTextCena1.Size = new System.Drawing.Size(439, 35);
            this.findTextCena1.TabIndex = 1;
            this.findTextCena1.TextCena = null;
            this.findTextCena1.TextFind = null;
            this.findTextCena1.TextLenght = 0;
            this.toolTip1.SetToolTip(this.findTextCena1, "Поиск товаров [Ins]");
            this.findTextCena1.FindClick += new MyShop.FindTextCena.ButtonFindHandler(this.findTextCena1_FindClick);
            this.findTextCena1.FindKeyPress += new MyShop.FindTextCena.FindTextBoxKeyPress(this.FindTextCena1_FindKeyPress);
            this.findTextCena1.Leave += new System.EventHandler(this.findTextCena1_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(84, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Найти товар:";
            // 
            // dgTovar
            // 
            this.dgTovar.AllowUserToAddRows = false;
            this.dgTovar.AllowUserToDeleteRows = false;
            this.dgTovar.BackgroundColor = System.Drawing.Color.White;
            this.dgTovar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgTovar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgTovar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CODE,
            this.NameTovar,
            this.kol,
            this.Cena});
            this.dgTovar.ContextMenuStrip = this.contextMenuStrip1;
            this.dgTovar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgTovar.Location = new System.Drawing.Point(0, 0);
            this.dgTovar.MultiSelect = false;
            this.dgTovar.Name = "dgTovar";
            this.dgTovar.RowHeadersWidth = 45;
            this.dgTovar.Size = new System.Drawing.Size(877, 505);
            this.dgTovar.TabIndex = 1;
            this.dgTovar.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgTovar_CellDoubleClick);
            this.dgTovar.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgTovar_CellPainting);
            this.dgTovar.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgTovar_RowPostPaint);
            this.dgTovar.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgTovar_RowPrePaint);
            this.dgTovar.SelectionChanged += new System.EventHandler(this.DgTovar_SelectionChanged);
            this.dgTovar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DgTovar_KeyDown);
            // 
            // CODE
            // 
            this.CODE.DataPropertyName = "CODE";
            this.CODE.HeaderText = "Код 1С";
            this.CODE.Name = "CODE";
            this.CODE.Width = 110;
            // 
            // NameTovar
            // 
            this.NameTovar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NameTovar.DataPropertyName = "NameTovar";
            this.NameTovar.HeaderText = "Наименование товара";
            this.NameTovar.Name = "NameTovar";
            // 
            // kol
            // 
            this.kol.DataPropertyName = "kol";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.kol.DefaultCellStyle = dataGridViewCellStyle2;
            this.kol.HeaderText = "Количество";
            this.kol.Name = "kol";
            this.kol.Width = 60;
            // 
            // Cena
            // 
            this.Cena.DataPropertyName = "Cena";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N2";
            this.Cena.DefaultCellStyle = dataGridViewCellStyle3;
            this.Cena.HeaderText = "Цена";
            this.Cena.Name = "Cena";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьВКорзинуToolStripMenuItem,
            this.корзинаТоваровToolStripMenuItem,
            this.toolStripMenuItem1,
            this.информацияОТовареToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(236, 76);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // добавитьВКорзинуToolStripMenuItem
            // 
            this.добавитьВКорзинуToolStripMenuItem.Image = global::MyShop.Properties.Resources.add24b;
            this.добавитьВКорзинуToolStripMenuItem.Name = "добавитьВКорзинуToolStripMenuItem";
            this.добавитьВКорзинуToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.добавитьВКорзинуToolStripMenuItem.Text = "Добавить в корзину";
            this.добавитьВКорзинуToolStripMenuItem.Click += new System.EventHandler(this.ДобавитьВКорзинуToolStripMenuItem_Click);
            // 
            // корзинаТоваровToolStripMenuItem
            // 
            this.корзинаТоваровToolStripMenuItem.Image = global::MyShop.Properties.Resources.basket24w;
            this.корзинаТоваровToolStripMenuItem.Name = "корзинаТоваровToolStripMenuItem";
            this.корзинаТоваровToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.корзинаТоваровToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.корзинаТоваровToolStripMenuItem.Text = "Корзина товаров";
            this.корзинаТоваровToolStripMenuItem.Click += new System.EventHandler(this.корзинаТоваровToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(232, 6);
            // 
            // информацияОТовареToolStripMenuItem
            // 
            this.информацияОТовареToolStripMenuItem.Image = global::MyShop.Properties.Resources.info24b;
            this.информацияОТовареToolStripMenuItem.Name = "информацияОТовареToolStripMenuItem";
            this.информацияОТовареToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.информацияОТовареToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.информацияОТовареToolStripMenuItem.Text = "Информация о товаре";
            this.информацияОТовареToolStripMenuItem.Click += new System.EventHandler(this.ИнформацияОТовареToolStripMenuItem_Click);
            // 
            // contextMenuStripSales
            // 
            this.contextMenuStripSales.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.обновитьToolStripMenuItem,
            this.установитьснятьОШИБКУToolStripMenuItem,
            this.изменитьПримечаниеToolStripMenuItem,
            this.печатьТоварногоЧекаToolStripMenuItem});
            this.contextMenuStripSales.Name = "contextMenuStripSales";
            this.contextMenuStripSales.Size = new System.Drawing.Size(68, 92);
            // 
            // обновитьToolStripMenuItem
            // 
            this.обновитьToolStripMenuItem.Name = "обновитьToolStripMenuItem";
            this.обновитьToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // установитьснятьОШИБКУToolStripMenuItem
            // 
            this.установитьснятьОШИБКУToolStripMenuItem.Name = "установитьснятьОШИБКУToolStripMenuItem";
            this.установитьснятьОШИБКУToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // изменитьПримечаниеToolStripMenuItem
            // 
            this.изменитьПримечаниеToolStripMenuItem.Name = "изменитьПримечаниеToolStripMenuItem";
            this.изменитьПримечаниеToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // печатьТоварногоЧекаToolStripMenuItem
            // 
            this.печатьТоварногоЧекаToolStripMenuItem.Name = "печатьТоварногоЧекаToolStripMenuItem";
            this.печатьТоварногоЧекаToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // lblSummaSales
            // 
            this.lblSummaSales.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSummaSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSummaSales.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold);
            this.lblSummaSales.ForeColor = System.Drawing.Color.White;
            this.lblSummaSales.Location = new System.Drawing.Point(997, 5);
            this.lblSummaSales.Name = "lblSummaSales";
            this.lblSummaSales.Size = new System.Drawing.Size(176, 40);
            this.lblSummaSales.TabIndex = 2;
            this.lblSummaSales.Text = "0,00";
            this.toolTip1.SetToolTip(this.lblSummaSales, "Сумма реализаций за текущий день");
            this.lblSummaSales.Click += new System.EventHandler(this.LblSummaSales_Click);
            // 
            // btnInfo
            // 
            this.btnInfo.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnInfo.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnInfo.FlatAppearance.BorderColor = System.Drawing.Color.OliveDrab;
            this.btnInfo.FlatAppearance.BorderSize = 0;
            this.btnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInfo.Image = global::MyShop.Properties.Resources.icons8_Info_24;
            this.btnInfo.Location = new System.Drawing.Point(23, 0);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(36, 31);
            this.btnInfo.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btnInfo, "Информация о товаре");
            this.btnInfo.UseVisualStyleBackColor = false;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            this.btnInfo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnInfo_MouseMove);
            // 
            // BtnAdd
            // 
            this.BtnAdd.BackColor = System.Drawing.Color.Green;
            this.BtnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BtnAdd.Dock = System.Windows.Forms.DockStyle.Right;
            this.BtnAdd.FlatAppearance.BorderColor = System.Drawing.Color.OliveDrab;
            this.BtnAdd.FlatAppearance.BorderSize = 0;
            this.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAdd.Image = global::MyShop.Properties.Resources.icons8_сложение_241;
            this.BtnAdd.Location = new System.Drawing.Point(59, 0);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(34, 31);
            this.BtnAdd.TabIndex = 3;
            this.toolTip1.SetToolTip(this.BtnAdd, "Добавить в корзину");
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            this.BtnAdd.MouseMove += new System.Windows.Forms.MouseEventHandler(this.BtnAdd_MouseMove);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Image = global::MyShop.Properties.Resources.update24w;
            this.btnUpdate.Location = new System.Drawing.Point(951, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(40, 40);
            this.btnUpdate.TabIndex = 3;
            this.toolTip1.SetToolTip(this.btnUpdate, "Обновить результат");
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(719, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Сумма реализации за текущий день:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.lblSummaSales);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 581);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1179, 56);
            this.panel1.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.ContextMenuStrip = this.contextMenuStripPrice;
            this.flowLayoutPanel1.Controls.Add(this.currentPriceVhod);
            this.flowLayoutPanel1.Controls.Add(this.currentPriceCena);
            this.flowLayoutPanel1.Controls.Add(this.currentPricePoKursu);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(692, 55);
            this.flowLayoutPanel1.TabIndex = 13;
            // 
            // contextMenuStripPrice
            // 
            this.contextMenuStripPrice.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ценаВходнаяtoolStripMenuItem2,
            this.ценаРеализацииToolStripMenuItem,
            this.ценаПоКурсуToolStripMenuItem});
            this.contextMenuStripPrice.Name = "contextMenuStripPrice";
            this.contextMenuStripPrice.Size = new System.Drawing.Size(171, 70);
            // 
            // ценаВходнаяtoolStripMenuItem2
            // 
            this.ценаВходнаяtoolStripMenuItem2.BackColor = System.Drawing.SystemColors.Control;
            this.ценаВходнаяtoolStripMenuItem2.Checked = true;
            this.ценаВходнаяtoolStripMenuItem2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ценаВходнаяtoolStripMenuItem2.Name = "ценаВходнаяtoolStripMenuItem2";
            this.ценаВходнаяtoolStripMenuItem2.Size = new System.Drawing.Size(170, 22);
            this.ценаВходнаяtoolStripMenuItem2.Text = "Цена входная";
            this.ценаВходнаяtoolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // ценаРеализацииToolStripMenuItem
            // 
            this.ценаРеализацииToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.ценаРеализацииToolStripMenuItem.Checked = true;
            this.ценаРеализацииToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ценаРеализацииToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.ценаРеализацииToolStripMenuItem.Name = "ценаРеализацииToolStripMenuItem";
            this.ценаРеализацииToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.ценаРеализацииToolStripMenuItem.Text = "Цена реализации";
            this.ценаРеализацииToolStripMenuItem.Click += new System.EventHandler(this.ценаРеализацииToolStripMenuItem_Click);
            // 
            // ценаПоКурсуToolStripMenuItem
            // 
            this.ценаПоКурсуToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.ценаПоКурсуToolStripMenuItem.Checked = true;
            this.ценаПоКурсуToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ценаПоКурсуToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.ценаПоКурсуToolStripMenuItem.Name = "ценаПоКурсуToolStripMenuItem";
            this.ценаПоКурсуToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.ценаПоКурсуToolStripMenuItem.Text = "Цена по курсу";
            this.ценаПоКурсуToolStripMenuItem.Click += new System.EventHandler(this.ценаПоКурсуToolStripMenuItem_Click);
            // 
            // currentPriceVhod
            // 
            this.currentPriceVhod.BackColor = System.Drawing.Color.IndianRed;
            this.currentPriceVhod.BorderColor = System.Drawing.Color.White;
            this.currentPriceVhod.BorderThickness = 0;
            this.currentPriceVhod.ColorDigits = System.Drawing.Color.Black;
            this.currentPriceVhod.ColorText = System.Drawing.Color.Black;
            this.currentPriceVhod.FontDigits1 = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Bold);
            this.currentPriceVhod.FontDigits2 = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold);
            this.currentPriceVhod.FontText1 = new System.Drawing.Font("Segoe UI", 14F);
            this.currentPriceVhod.FontText2 = new System.Drawing.Font("Segoe UI", 10F);
            this.currentPriceVhod.Location = new System.Drawing.Point(3, 3);
            this.currentPriceVhod.Name = "currentPriceVhod";
            this.currentPriceVhod.Price = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.currentPriceVhod.Size = new System.Drawing.Size(217, 50);
            this.currentPriceVhod.TabIndex = 12;
            this.currentPriceVhod.Text1 = "Цена";
            this.currentPriceVhod.Text2 = "входная";
            // 
            // currentPriceCena
            // 
            this.currentPriceCena.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.currentPriceCena.BorderColor = System.Drawing.Color.White;
            this.currentPriceCena.BorderThickness = 0;
            this.currentPriceCena.ColorDigits = System.Drawing.Color.Gold;
            this.currentPriceCena.ColorText = System.Drawing.Color.Gold;
            this.currentPriceCena.FontDigits1 = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Bold);
            this.currentPriceCena.FontDigits2 = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold);
            this.currentPriceCena.FontText1 = new System.Drawing.Font("Segoe UI", 14F);
            this.currentPriceCena.FontText2 = new System.Drawing.Font("Segoe UI", 10F);
            this.currentPriceCena.Location = new System.Drawing.Point(226, 3);
            this.currentPriceCena.Name = "currentPriceCena";
            this.currentPriceCena.Price = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.currentPriceCena.Size = new System.Drawing.Size(217, 50);
            this.currentPriceCena.TabIndex = 11;
            this.currentPriceCena.Text1 = "Цена";
            this.currentPriceCena.Text2 = "реализации";
            // 
            // currentPricePoKursu
            // 
            this.currentPricePoKursu.BackColor = System.Drawing.SystemColors.HotTrack;
            this.currentPricePoKursu.BorderColor = System.Drawing.Color.White;
            this.currentPricePoKursu.BorderThickness = 0;
            this.currentPricePoKursu.ColorDigits = System.Drawing.Color.White;
            this.currentPricePoKursu.ColorText = System.Drawing.Color.White;
            this.currentPricePoKursu.FontDigits1 = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Bold);
            this.currentPricePoKursu.FontDigits2 = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold);
            this.currentPricePoKursu.FontText1 = new System.Drawing.Font("Segoe UI", 14F);
            this.currentPricePoKursu.FontText2 = new System.Drawing.Font("Segoe UI", 10F);
            this.currentPricePoKursu.Location = new System.Drawing.Point(449, 3);
            this.currentPricePoKursu.Name = "currentPricePoKursu";
            this.currentPricePoKursu.Price = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.currentPricePoKursu.Size = new System.Drawing.Size(234, 50);
            this.currentPricePoKursu.TabIndex = 10;
            this.currentPricePoKursu.Text1 = "Цена";
            this.currentPricePoKursu.Text2 = "по курсу";
            // 
            // panelButtonDG
            // 
            this.panelButtonDG.BackColor = System.Drawing.Color.Transparent;
            this.panelButtonDG.Controls.Add(this.btnInfo);
            this.panelButtonDG.Controls.Add(this.BtnAdd);
            this.panelButtonDG.Location = new System.Drawing.Point(39, 67);
            this.panelButtonDG.Name = "panelButtonDG";
            this.panelButtonDG.Size = new System.Drawing.Size(93, 31);
            this.panelButtonDG.TabIndex = 5;
            this.panelButtonDG.Visible = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 76);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panelButtonDG);
            this.splitContainer1.Panel1.Controls.Add(this.dgTovar);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.uscInfoTovar1);
            this.splitContainer1.Size = new System.Drawing.Size(1179, 505);
            this.splitContainer1.SplitterDistance = 877;
            this.splitContainer1.TabIndex = 6;
            // 
            // uscInfoTovar1
            // 
            this.uscInfoTovar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uscInfoTovar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uscInfoTovar1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uscInfoTovar1.Location = new System.Drawing.Point(0, 0);
            this.uscInfoTovar1.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.uscInfoTovar1.Name = "uscInfoTovar1";
            this.uscInfoTovar1.PanelsIsOpen = true;
            this.uscInfoTovar1.Size = new System.Drawing.Size(298, 505);
            this.uscInfoTovar1.TabIndex = 0;
            this.uscInfoTovar1.Close += new MyShop.Ostatki.uscInfoTovar.InfoTovarEvent(this.uscInfoTovar1_Close_1);
            // 
            // FrmTrade
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1179, 637);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MinimumSize = new System.Drawing.Size(967, 500);
            this.Name = "FrmTrade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "МАГАЗИН (реализация)";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.FrmTrade_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmTrade_FormClosing);
            this.Load += new System.EventHandler(this.FrmTrade_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmTrade_KeyDown);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelBasketInfo.ResumeLayout(false);
            this.panelBasket.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTovar)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStripSales.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.contextMenuStripPrice.ResumeLayout(false);
            this.panelButtonDG.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Button btnFilterClear;
        private FindTextCena findTextCena1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelBasketInfo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblBasketSumma;
        private System.Windows.Forms.Label lblBasketKol;
        private System.Windows.Forms.DataGridView dgTovar;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem добавитьВКорзинуToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem информацияОТовареToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem корзинаТоваровToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripSales;
        private System.Windows.Forms.ToolStripMenuItem обновитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem установитьснятьОШИБКУToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьПримечаниеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem печатьТоварногоЧекаToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn CODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameTovar;
        private System.Windows.Forms.DataGridViewTextBoxColumn kol;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cena;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblSummaSales;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUpdate;
        private MyButton btnExit;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panelButtonDG;
        private System.Windows.Forms.Button btnInfo;
        private CurrentPrice currentPricePoKursu;
        private CurrentPrice currentPriceCena;
        private CurrentPrice currentPriceVhod;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripPrice;
        private System.Windows.Forms.ToolStripMenuItem ценаВходнаяtoolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ценаРеализацииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ценаПоКурсуToolStripMenuItem;
        private System.Windows.Forms.Panel panelBasket;
        private System.Windows.Forms.Panel panelIcon;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private Ostatki.uscInfoTovar uscInfoTovar1;
    }
}