﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;

namespace MyShop.MAGAZIN
{
    //  ИСПОЛЬЗОВАНИЕ
    //
    //Printing.PrintTextBox box = new Printing.PrintTextBox(e.Graphics);
    //box.Text = "Hello!";
    //box.Font = new Font("Times New Roman", 10, FontStyle.Bold);
    //box.BackColor = Color.LightCoral;
    //box.Location = new Point(20, 50);
    //box.StringFormat.Alignment = StringAlignment.Center;
    //box.StringFormat.LineAlignment = StringAlignment.Center;
    //box.Border.Left = 1; box.Border.Right = 1;
    //box.Border.Bottom = 2; box.Border.Top = 2;
    //box.Paint();

    public partial class PrintSALES : PrintDocument
    {

        private int page;
        private DateTime startDate;
        private DateTime endDate;
        private bool day;
        private DataTable dataTable;
        private int RowX;
        private double Summa;
        private int chek;

        public PrintSALES(DateTime start, DateTime end, DataTable dt)
        {
            InitializeComponent();
            page = 1;
            startDate = start;
            endDate = end;
            dataTable = dt;
        }

        private void PrintSALES_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font f12b = new Font("Arial", 12, FontStyle.Bold);
            Font f12r = new Font("Arial", 12, FontStyle.Regular);
            Font f10r = new Font("Arial", 10, FontStyle.Regular);
            Font f10b = new Font("Arial", 10, FontStyle.Bold);



            int top, left;
            top = 50;
            left = 70;

            e.Graphics.DrawString(page.ToString(), f10r, Brushes.Gray, new Point(e.MarginBounds.Right - 40, top));
            top += 18;

            if (page == 1)
            {

                e.Graphics.DrawString("ОТЧЕТ РЕАЛИЗАЦИИ ТОВАРОВ", f12b, Brushes.Black, new Point(270, top));

                if (startDate.ToShortDateString()!=endDate.ToShortDateString())//период
                {
                    e.Graphics.DrawString("за " + startDate.ToShortDateString() + " - " + endDate.ToShortDateString(), f12r, Brushes.Black, new Point(300, top + 20));
                    day = false;
                }
                else //день
                {
                    e.Graphics.DrawString("за " + startDate.ToShortDateString(), f12r, Brushes.Black, new Point(340, top + 20));
                    day = true;
                }

                e.Graphics.DrawLine(new Pen(Brushes.Black), left, top + 50, left + 700, top + 50);//линия

                top += 70;
            }

            int height = 18;
            string _data = null;
            int x;
            int count = dataTable.Rows.Count;
            for (x = RowX; x < count; x++)
            {
                DataRow dr = dataTable.Rows[x];

                string s = dr["korz"].ToString();
                int c;
                if (string.IsNullOrEmpty(s))
                {
                    c = 0;
                }
                else
                {
                    c = int.Parse(s);
                }
                if (chek != c)
                {
                    //новый чек
                    e.Graphics.DrawLine(new Pen(Brushes.LightGray), left, top-2, left + 700, top-2);//линия
                }

                chek = c;

                if (top + height > e.MarginBounds.Bottom)
                {
                    page++;
                    RowX = x;
                    e.HasMorePages = true;
                    break;
                }
                else
                {
                    e.HasMorePages = false;
                }

                if (day == false)
                {
                    DateTime dateTime = (DateTime)dr["data"];
                    string data = dateTime.ToShortDateString();
                    if (data != _data)
                    {
                        // выводим строку с датой
                        _data = data;
                        RectangleF dataF = new RectangleF(left, top, 700, height);
                        e.Graphics.FillRectangle(Brushes.Gainsboro, dataF.X, dataF.Y-2, dataF.Width, dataF.Height+1);
                        e.Graphics.DrawString(data, f10b, Brushes.Black, dataF);
                        top += 20;
                    }

                }

                string prim = dr["prim"].ToString();
                Brush br;
                br = Brushes.Black;
                if (prim != "")
                {
                    //br = Brushes.Red;
                    //e.Graphics.DrawRectangle();
                    e.Graphics.FillRectangle(Brushes.LightYellow, left, top - 1, 700, (height * 2) + 2);
                    Font f10i = new Font("Arial", 10, FontStyle.Italic);
                    e.Graphics.DrawString("Примечание: " + dr["prim"].ToString(), f10i, br, left + 60, top);
                    e.Graphics.DrawRectangle(new Pen(br), new Rectangle(left, top - 1, 700, (height * 2) + 2));
                    top += 20;
                }


                RectangleF CodeF = new RectangleF(left, top, 100, height);
                e.Graphics.DrawString(dr["code"].ToString(), f10r, br, CodeF);


                RectangleF NameTovarF = new RectangleF(left + 90, top, 400, height);
                e.Graphics.DrawString(dr["DESCR"].ToString(), f10r, br, NameTovarF);


                RectangleF KolF = new RectangleF(left + 500, top, 50, height);
                e.Graphics.DrawString(dr["Kol"].ToString().Replace(",000",""), f10r, br, KolF);


                RectangleF CenaF = new RectangleF(left + 550, top, 60, height);
                e.Graphics.DrawString(string.Format("{0:N2}", dr["Cena"]), f10r, br, CenaF);


                double sumRow = Convert.ToDouble(dr["Kol"]) * Convert.ToDouble(dr["Cena"]);

                if (prim != "Ошибка")
                {
                    Summa += sumRow;
                }

                RectangleF SummF = new RectangleF(left + 620, top, 60, height);
                e.Graphics.DrawString(string.Format("{0:N2}", sumRow), f10b, br, SummF);


                top += 20;
            }

            if (x == count)
            {
                e.Graphics.DrawLine(new Pen(Brushes.Black), left, top + 10, left + 700, top + 10);//линия

                RectangleF ItogF = new RectangleF(left + 550, top + 20, 150, height);
                e.Graphics.DrawString("ИТОГО:    " + string.Format("{0:N2}", Summa), f10b, Brushes.Black, ItogF);
            }



        }

        private void PrintSALES_BeginPrint(object sender, PrintEventArgs e)
        {
            Summa = 0;
        }
    }
}
