﻿
namespace MyShop.MAGAZIN
{
    partial class frmCurrentSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNameTovar = new System.Windows.Forms.Label();
            this.txtSumma = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPrim = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblMaxKol = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMinCena = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnResetPrice = new System.Windows.Forms.Button();
            this.ucNumberBoxUpDownCena = new MyShop.ucNumberBoxUpDown();
            this.ucNumberBoxUpDownKol = new MyShop.ucNumberBoxUpDown();
            this.nbCena = new MyShop.NumberBox();
            this.nbKol = new MyShop.NumberBox();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNameTovar
            // 
            this.lblNameTovar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNameTovar.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNameTovar.Location = new System.Drawing.Point(12, 81);
            this.lblNameTovar.Name = "lblNameTovar";
            this.lblNameTovar.Size = new System.Drawing.Size(768, 50);
            this.lblNameTovar.TabIndex = 7;
            this.lblNameTovar.Text = "Наименование товара";
            this.lblNameTovar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSumma
            // 
            this.txtSumma.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtSumma.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSumma.Enabled = false;
            this.txtSumma.Font = new System.Drawing.Font("Segoe UI Semibold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtSumma.Location = new System.Drawing.Point(586, 178);
            this.txtSumma.Name = "txtSumma";
            this.txtSumma.ReadOnly = true;
            this.txtSumma.Size = new System.Drawing.Size(152, 46);
            this.txtSumma.TabIndex = 11;
            this.txtSumma.TabStop = false;
            this.txtSumma.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(530, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Сумма:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Цена:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Количество:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(31, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Реализация товара:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Green;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(792, 54);
            this.panel3.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.btnOK);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 288);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(792, 70);
            this.panel2.TabIndex = 4;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.Control;
            this.btnCancel.Location = new System.Drawing.Point(630, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(130, 43);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.SteelBlue;
            this.btnOK.ForeColor = System.Drawing.Color.White;
            this.btnOK.Location = new System.Drawing.Point(494, 15);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(130, 43);
            this.btnOK.TabIndex = 3;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Примечание:";
            // 
            // txtPrim
            // 
            this.txtPrim.Location = new System.Drawing.Point(120, 245);
            this.txtPrim.Name = "txtPrim";
            this.txtPrim.Size = new System.Drawing.Size(640, 25);
            this.txtPrim.TabIndex = 2;
            this.txtPrim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPrim_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(3, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "макс:";
            // 
            // lblMaxKol
            // 
            this.lblMaxKol.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lblMaxKol.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMaxKol.Location = new System.Drawing.Point(39, 3);
            this.lblMaxKol.Name = "lblMaxKol";
            this.lblMaxKol.Size = new System.Drawing.Size(63, 22);
            this.lblMaxKol.TabIndex = 13;
            this.lblMaxKol.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(3, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "мин.цена:";
            // 
            // lblMinCena
            // 
            this.lblMinCena.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMinCena.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMinCena.Location = new System.Drawing.Point(88, 3);
            this.lblMinCena.Name = "lblMinCena";
            this.lblMinCena.Size = new System.Drawing.Size(67, 22);
            this.lblMinCena.TabIndex = 13;
            this.lblMinCena.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblMaxKol);
            this.panel1.Location = new System.Drawing.Point(120, 151);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(103, 25);
            this.panel1.TabIndex = 14;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.lblMinCena);
            this.panel4.Location = new System.Drawing.Point(329, 151);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(158, 25);
            this.panel4.TabIndex = 15;
            // 
            // lblInfo
            // 
            this.lblInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblInfo.Location = new System.Drawing.Point(0, 54);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(792, 27);
            this.lblInfo.TabIndex = 16;
            this.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnResetPrice
            // 
            this.btnResetPrice.BackgroundImage = global::MyShop.Properties.Resources.icons8_отменить_24;
            this.btnResetPrice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnResetPrice.Location = new System.Drawing.Point(305, 201);
            this.btnResetPrice.Name = "btnResetPrice";
            this.btnResetPrice.Size = new System.Drawing.Size(24, 24);
            this.btnResetPrice.TabIndex = 17;
            this.btnResetPrice.UseVisualStyleBackColor = true;
            this.btnResetPrice.Click += new System.EventHandler(this.btnResetPrice_Click);
            // 
            // ucNumberBoxUpDownCena
            // 
            this.ucNumberBoxUpDownCena.Location = new System.Drawing.Point(488, 177);
            this.ucNumberBoxUpDownCena.Name = "ucNumberBoxUpDownCena";
            this.ucNumberBoxUpDownCena.numberBox = null;
            this.ucNumberBoxUpDownCena.Size = new System.Drawing.Size(17, 48);
            this.ucNumberBoxUpDownCena.TabIndex = 18;
            // 
            // ucNumberBoxUpDownKol
            // 
            this.ucNumberBoxUpDownKol.Location = new System.Drawing.Point(224, 177);
            this.ucNumberBoxUpDownKol.Name = "ucNumberBoxUpDownKol";
            this.ucNumberBoxUpDownKol.numberBox = null;
            this.ucNumberBoxUpDownKol.Size = new System.Drawing.Size(17, 48);
            this.ucNumberBoxUpDownKol.TabIndex = 18;
            // 
            // nbCena
            // 
            this.nbCena.BackColor = System.Drawing.SystemColors.Window;
            this.nbCena.Font = new System.Drawing.Font("Segoe UI", 21.75F);
            this.nbCena.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nbCena.Location = new System.Drawing.Point(329, 178);
            this.nbCena.MaxValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbCena.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbCena.Name = "nbCena";
            this.nbCena.Size = new System.Drawing.Size(158, 46);
            this.nbCena.TabIndex = 1;
            this.nbCena.Text = "0";
            this.nbCena.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nbCena.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbCena.TextChanged += new System.EventHandler(this.nbCena_TextChanged);
            this.nbCena.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NbCena_KeyPress);
            // 
            // nbKol
            // 
            this.nbKol.BackColor = System.Drawing.SystemColors.Window;
            this.nbKol.Font = new System.Drawing.Font("Segoe UI", 21.75F);
            this.nbKol.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nbKol.Location = new System.Drawing.Point(120, 178);
            this.nbKol.MaxValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbKol.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbKol.Name = "nbKol";
            this.nbKol.Size = new System.Drawing.Size(103, 46);
            this.nbKol.TabIndex = 0;
            this.nbKol.Text = "0";
            this.nbKol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nbKol.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbKol.TextChanged += new System.EventHandler(this.nbKol_TextChanged_1);
            this.nbKol.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NbKol_KeyPress);
            // 
            // frmCurrentSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(792, 358);
            this.Controls.Add(this.ucNumberBoxUpDownCena);
            this.Controls.Add(this.ucNumberBoxUpDownKol);
            this.Controls.Add(this.btnResetPrice);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtPrim);
            this.Controls.Add(this.nbCena);
            this.Controls.Add(this.nbKol);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txtSumma);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblNameTovar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmCurrentSale";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "My Store";
            this.Load += new System.EventHandler(this.FrmCurrentSale_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmCurrentSale_KeyDown);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNameTovar;
        private System.Windows.Forms.TextBox txtSumma;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private NumberBox nbKol;
        private NumberBox nbCena;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtPrim;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblMaxKol;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMinCena;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnResetPrice;
        private ucNumberBoxUpDown ucNumberBoxUpDownKol;
        private ucNumberBoxUpDown ucNumberBoxUpDownCena;
    }
}