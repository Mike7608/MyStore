﻿
namespace MyShop.MAGAZIN
{
    partial class CurrentPrice
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDig2 = new System.Windows.Forms.Label();
            this.lblDig1 = new System.Windows.Forms.Label();
            this.lblText2 = new System.Windows.Forms.Label();
            this.lblText1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDig2
            // 
            this.lblDig2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDig2.AutoSize = true;
            this.lblDig2.BackColor = System.Drawing.Color.Transparent;
            this.lblDig2.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold);
            this.lblDig2.ForeColor = System.Drawing.Color.White;
            this.lblDig2.Location = new System.Drawing.Point(170, 0);
            this.lblDig2.Name = "lblDig2";
            this.lblDig2.Size = new System.Drawing.Size(41, 32);
            this.lblDig2.TabIndex = 7;
            this.lblDig2.Text = "00";
            // 
            // lblDig1
            // 
            this.lblDig1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDig1.BackColor = System.Drawing.Color.Transparent;
            this.lblDig1.Font = new System.Drawing.Font("Segoe UI Semibold", 22F, System.Drawing.FontStyle.Bold);
            this.lblDig1.ForeColor = System.Drawing.Color.White;
            this.lblDig1.Location = new System.Drawing.Point(82, 0);
            this.lblDig1.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblDig1.Name = "lblDig1";
            this.lblDig1.Size = new System.Drawing.Size(98, 47);
            this.lblDig1.TabIndex = 6;
            this.lblDig1.Text = "0";
            this.lblDig1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblText2
            // 
            this.lblText2.BackColor = System.Drawing.Color.Transparent;
            this.lblText2.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblText2.ForeColor = System.Drawing.Color.White;
            this.lblText2.Location = new System.Drawing.Point(5, 25);
            this.lblText2.Name = "lblText2";
            this.lblText2.Size = new System.Drawing.Size(76, 22);
            this.lblText2.TabIndex = 5;
            this.lblText2.Text = "по курсу";
            // 
            // lblText1
            // 
            this.lblText1.BackColor = System.Drawing.Color.Transparent;
            this.lblText1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.lblText1.ForeColor = System.Drawing.Color.White;
            this.lblText1.Location = new System.Drawing.Point(3, 0);
            this.lblText1.Name = "lblText1";
            this.lblText1.Size = new System.Drawing.Size(79, 25);
            this.lblText1.TabIndex = 4;
            this.lblText1.Text = "Цена";
            this.lblText1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.lblText1);
            this.panel1.Controls.Add(this.lblText2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(84, 50);
            this.panel1.TabIndex = 8;
            // 
            // CurrentPrice
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblDig2);
            this.Controls.Add(this.lblDig1);
            this.Name = "CurrentPrice";
            this.Size = new System.Drawing.Size(217, 50);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.CurrentPrice_Paint);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDig2;
        private System.Windows.Forms.Label lblDig1;
        private System.Windows.Forms.Label lblText2;
        private System.Windows.Forms.Label lblText1;
        private System.Windows.Forms.Panel panel1;
    }
}
