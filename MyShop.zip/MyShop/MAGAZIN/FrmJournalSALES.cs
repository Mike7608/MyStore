﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.MAGAZIN
{
    public partial class FrmJournalSALES : Form
    {
        BindingSource bs = new BindingSource();

        public FrmJournalSALES()
        {
            InitializeComponent();

            MyStyleDataGrid st = new MyStyleDataGrid();
            st.Default(dg);
            dg.AutoGenerateColumns = false;
            dg.MultiSelect = true;
            controlPeriod1.DateStart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            controlPeriod1.DateEnd = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            bs.ListChanged += Bs_ListChanged;
            Realizacia.SavingData += SummaProdaj;
            Realizacia.LoadData += SummaProdaj;

            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;

            dg.DefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Regular);

            splitContainer1.Panel2Collapsed = true;

        }

        private void SummaProdaj()
        {
            lblSumma.Text = string.Format("{0:f}", Realizacia.Summa());
        }

        private void Bs_ListChanged(object sender, ListChangedEventArgs e)
        {
            if (bs.Count > 0)
            {
                BtnPrint.Enabled = true;
                BtnPrintRec.Enabled = true;
                btnSetPrim.Enabled = true;
                myButtonInfoTovar.Enabled = true;
                contextMenuStrip1.Enabled = true;
                btnSave.Enabled = true;
            }
            else
            {
                BtnPrint.Enabled = false;
                BtnPrintRec.Enabled = false;
                btnSetPrim.Enabled = false;
                myButtonInfoTovar.Enabled = false;
                contextMenuStrip1.Enabled = false;
                btnSave.Enabled = false;
            }

        }

        private void FrmJournalSALES_Load(object sender, EventArgs e)
        {
            dg.Paint += Dg_Paint;

            Realizacia.Load();
            bs.DataSource = Realizacia.DataSource;
            dg.DataSource = bs;

        }

        private void Dg_Paint(object sender, PaintEventArgs e)
        {
            MK.Procedures proc = new MK.Procedures();
            proc.PaintNullDataString(dg, e);
        }

        private void controlPeriod1_ChangPeriod()
        {
            Cursor = Cursors.WaitCursor;
            bs.DataSource = Realizacia.DataSource;

            Realizacia.Load(controlPeriod1.DateStart, controlPeriod1.DateEnd);

            string kol = Realizacia.SummaKol().ToString().Replace(",000","");
            lblKol.Text = kol;
            SummaProdaj();
            Cursor = Cursors.Default;
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {

            PrintSALES sales = new PrintSALES(controlPeriod1.DateStart, controlPeriod1.DateEnd, Realizacia.DataSource);
            FrmPrintPreview prn = new FrmPrintPreview(sales)
            {
                MdiParent = Global.mainForm
            };
            prn.Show();
        }

        private void BtnPrintRec_Click(object sender, EventArgs e)
        {
            MK.Procedures pr = new MK.Procedures();
            DataTable dt1 = pr.SelectedRows(dg);
            PrintPreviewSalesReceipt receipt = new PrintPreviewSalesReceipt(dt1, controlPeriod1.DateStart);
            FrmPrintPreview prn = new FrmPrintPreview(receipt)
            {
                MdiParent = Global.mainForm
            };
            prn.Show();
        }

        private void FrmJournalSALES_Resize(object sender, EventArgs e)
        {
            dg.Refresh();
        }

        private void btnSetPrim_Click(object sender, EventArgs e)
        {
            ShowEditDescription();
        }

        private void ShowEditDescription()//----------------------------------------
        {
            frmEditDescrProdaj frm = new frmEditDescrProdaj();

            frm.LoadData(CurrentRowSALES);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                SummaProdaj();
            }
            
        }

        public DataRow CurrentRowSALES
        {
            get
            {
                int position = this.BindingContext[bs].Position;
                if (position > -1)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Realizacia.Load(controlPeriod1.DateStart, controlPeriod1.DateEnd);
            frmInfoSales frm = new frmInfoSales();
            frm.ShowAlert("Данные успешно обновлены", "Журнал продаж", frmInfoSales.EnmType.Info);
   

        }



        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void myButtonInfoTovar_Click(object sender, EventArgs e)
        {
            ShowInfoTovar();
        }


        private string CurrentIDtov()
        {
            string id = null;

            DataRowView dr = (DataRowView)bs.Current;
            if (dr != null)
            {
                id = dr["idtov"].ToString();
            }
            return id;
        }

        private void ShowInfoTovar()
        {
            if (splitContainer1.Panel2Collapsed)
            {
                splitContainer1.Panel2Collapsed = false;
                dg_SelectionChanged(null, null);
            }
            else
            {
                splitContainer1.Panel2Collapsed = true;
            }
        }

        private void dg_KeyDown(object sender, KeyEventArgs e)
        {
            if (bs.Count > 0)
            {
                switch (e.KeyData)
                {
                    case Keys.I:
                        ShowInfoTovar();
                        break;
                }
            }
        }

        private void информацияОТовареToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowInfoTovar();
        }

        private void примечаниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowEditDescription();
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnUpdate_Click(null, null);
        }

        private void товарныйЧекToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnPrintRec_Click(null, null);
        }

        private void отчётToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnPrint_Click(null, null);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //выгрузить продажи в файл
            SaveToFile();
        }

        private void SaveToFile()
        {
            Properties.Settings set = new Properties.Settings();
            DateTime dt = controlPeriod1.DateStart;

            if (controlPeriod1.DateStart.ToShortDateString() == controlPeriod1.DateEnd.ToShortDateString())
            {
                DataTable datatable = new DataTable();
                datatable = (DataTable)bs.DataSource;

                string NameFile = dt.ToString("yyyyMMdd") + ".sls";

                string path = set.PathSaveDataFor1C + "\\" + NameFile;

                if (datatable.Rows.Count > 0)
                {
                    // полная перезапись файла 
                    using (StreamWriter writer = new StreamWriter(path, false))
                    {
                        foreach (DataRow dr in datatable.Rows)
                        {
                            if (dr["prim"].ToString().IndexOf(Realizacia.Oshibka) < 0)
                            {
                                DateTime dtr = (DateTime)dr["data"];
                                string kol = Convert.ToDecimal(dr["kol"]).ToString("#.000#", CultureInfo.InvariantCulture);
                                string sum= Convert.ToDecimal(dr["Summa"]).ToString("#.00#", CultureInfo.InvariantCulture);
                                string text = dtr.ToShortDateString()+ ";" + dr["code"]+ ";" + kol + ";" + sum + ";";
                                writer.WriteLine(text);
                            }
                        }
                    }
                    MessageBox.Show("Создан файл выгрузки " + path, "Журнал продаж", MessageBoxButtons.OK, MessageBoxIcon.Information);
                 }
            }
            else
            {
                MessageBox.Show("Выгрузка данных возмажна только за 1 день", "Выгрузка журнала продаж", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private void FrmJournalSALES_FormClosing(object sender, FormClosingEventArgs e)
        {
            Realizacia.SavingData -= SummaProdaj;
            Realizacia.LoadData -= SummaProdaj;
        }

        private void dg_SelectionChanged(object sender, EventArgs e)
        {
            if (splitContainer1.Panel2Collapsed == false)
            {
                if (!string.IsNullOrEmpty(CurrentIDtov()))
                {
                    uscInfoTovar1.LoadData(CurrentIDtov());
                }
                else
                {
                    uscInfoTovar1.Clear();
                }
            }
        }

        private void uscInfoTovar1_Close()
        {
            splitContainer1.Panel2Collapsed = true;
        }
    }
}
