﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.MAGAZIN
{
    public partial class frmEditDescrProdaj : Form
    {
        string _prim;
        DataRow _dr;


        public frmEditDescrProdaj()
        {
            InitializeComponent();
        }

        public void LoadData(DataRow dr)
        {
            if (dr == null)
            {
                btnOK.Enabled = false;
            }
            else
            {
                _dr = dr;
                lblData.Text = dr["data"].ToString();
                lblCode.Text = dr["code"].ToString();
                txtName.Text = dr["DESCR"].ToString();
                txtKol.Text = string.Format("{0:f}", dr["kol"]);
                txtCena.Text = string.Format("{0:f}", dr["cena"]);
                txtSumma.Text = string.Format("{0:f}", dr["summa"]);
                _prim = dr["prim"].ToString();
                txtPrim.Text =_prim;

                switch(_prim)
                {
                    case "":
                        comboPrim.SelectedItem = "(нет примечания)";
                        break;
                    case "Ошибка":
                        comboPrim.SelectedItem = Realizacia.Oshibka;
                        break;
                    default:
                        comboPrim.SelectedItem = "Другое";
                        break;
                }
            }

        }

        private void ComboPrim_SelectedIndexChanged(object sender, EventArgs e)
        {

            switch (comboPrim.Text)
            {
                case "Другое":
                    txtPrim.ReadOnly = false;
                    break;
                case "Ошибка":
                    txtPrim.Text = Realizacia.Oshibka;
                    break;
                default:
                    txtPrim.ReadOnly = true;
                    txtPrim.Text = "";
                    break;
            }
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            _dr["prim"] = txtPrim.Text;
            Realizacia.UpdPrim(_dr);

        }


    }
}
