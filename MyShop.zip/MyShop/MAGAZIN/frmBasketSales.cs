﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace MyShop.MAGAZIN
{
    //   для вывода сообщения в другом потоке
    //1. В главной форме создаешь некое событие и делегат
    //2. Создаешь 2-ую форму, в ней в отдельном потоке подписываешься на данное событие.(не забудь передать ссылку на 1-ую форму, чтобы иметь доступ к событию).
    //3. Когда надо вызываешь событие из 1-ой формы, а по вызову события - выводишь то, что надо на 2-ой.

    public partial class frmBasketSales : Form
    {
        BindingSource bsBasket = new BindingSource();
        Setting.Email email;
        private decimal Sdacha;

        public DataRow currentRow
        {
            get
            {
                int position = this.BindingContext[bsBasket].Position;
                if (position > -1)
                {
                    return ((DataRowView)bsBasket.Current).Row;
                }
                else
                {
                    return null;
                }
            }
        }
        private int CurrentID
        {
            get
            {
                int ret = -1;
                if (bsBasket.Count > 0)
                {
                    object obj = bsBasket.Current;
                    DataRowView dr = (DataRowView)obj;
                    ret = (int)dr["id"];
                }
                return ret;
            }
        }
        public frmBasketSales()
        {
            InitializeComponent();

            email = new Setting.Email();
            MyStyleDataGrid st = new MyStyleDataGrid();
            st.Default(dgBasket);
            dgBasket.BackgroundColor = Color.AliceBlue;
            dgBasket.AlternatingRowsDefaultCellStyle.BackColor = Color.Azure;
            dgBasket.RowsDefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Regular);
            dgBasket.Columns["Summa"].DefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            dgBasket.AutoGenerateColumns = false;
            bsBasket.DataSource = Basket.DataSource;
            dgBasket.DataSource = bsBasket;
            DisplaySumm();
            lblCode.DataBindings.Add("Text", bsBasket, "code");
            lblName.DataBindings.Add("Text", bsBasket, "NameTovar");
            lblPrim.DataBindings.Add("Text", bsBasket, "prim");
            bsBasket.ListChanged += BsBasket_ListChanged;
            Basket.Edit += DisplaySumm;
            //panelButtonDG.BringToFront();
        }

        private void BsBasket_ListChanged(object sender, ListChangedEventArgs e)
        {
            if (bsBasket.Count > 0)
            {
                btnClearBasket.Visible = true;
                dgBasket.Enabled = true;
                btnRealizacia.Enabled = true;
            }
            else
            {

                btnClearBasket.Visible = false;
                dgBasket.Enabled = false;
                btnRealizacia.Enabled = false;
            }
        }


        private void DeleteRow()
        {

            if (bsBasket.Count > 0)
            {
                DialogResult result;
                result = MessageBox.Show("Удалить текущую позицию товара?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    Basket.DeleteRow(CurrentID);
                    DisplaySumm();
                    frmInfoSales frm = new frmInfoSales();
                    frm.ShowAlert("Выбранная позиция удалена из корзины", "Внимание", frmInfoSales.EnmType.Error);
                    dgBasket.Focus();
                }

            }
        }

        private void DisplaySumm()
        {
            lblSumma.Text = string.Format("{0:f}", Basket.GetCenaSumm);
            lblItogoKol.Text = Basket.GetKolSumm.ToString();
            lblItogoPos.Text = bsBasket.Count.ToString();
            nbNal.Value=Basket.GetCenaSumm;
            nbNal.MaxValue = Basket.GetCenaSumm * 100;
            nbBeznal.MaxValue= Basket.GetCenaSumm;
        }

        private void frmBasketSales_Load(object sender, EventArgs e)
        {
            BsBasket_ListChanged(null, null);
            dgBasket.Focus();
        }


        private void TovarSale()
        {

            DataRow dr = currentRow;
            if (dr != null)
            {
                frmCurrentSale frm = new frmCurrentSale();
                frm.ID = (int)dr["id"];
                frm.IDtovar = dr["idtov"].ToString();
                frm.CODE = dr["code"].ToString();
                frm.NameTovar = dr["NameTovar"].ToString();
                frm.KolTov = Convert.ToDecimal(dr["kol"]);
                frm.CenaTovara = Convert.ToDecimal(dr["cena"]);
                frm.Prim = dr["prim"].ToString();
                frm.MinCena = (decimal)dr["MinCena"];
                frm.MaxKol = (decimal)dr["MaxKol"];
                frm.CenaDef = (decimal)dr["CenaDef"];
                frm.Skidka = (decimal)dr["Skidka"];
                frm.IsAdding = false;
                frm.ShowDialog();
            }

            dgBasket.Focus();
        }

        private void dgBasket_DoubleClick(object sender, EventArgs e)
        {
            TovarSale();
        }


        private void dgBasket_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                TovarSale();
                e.Handled = true;
            }
            if(e.KeyData==Keys.Delete)
            {
                DeleteRow();
                e.Handled = true;
            }
            if (e.KeyData == Keys.F2)
            {
                TovarSale();
                e.Handled = true;
            }
            if (e.KeyData==(Keys.Control | Keys.Delete))
            {
                btnClearBasket_Click(null, null);
                e.Handled = true;
            }
            if (e.KeyData == Keys.F9)
            {
                RealizTovarov();
            }
        }

        private void frmBasketSales_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRealizacia_Click(object sender, EventArgs e)
        {
            RealizTovarov();
        }

        private void RealizTovarov()
        {
            if (Basket.DataSource != null)
            {
                frmInfoSales frm = new frmInfoSales();
                Cursor = Cursors.WaitCursor;
                Realizacia.Save(Basket.DataSource);
                //realizacia.Load();
                frm.ShowAlert("Реализация товаров проведена успешно", "Информация о реализации", frmInfoSales.EnmType.Success);

                //здесь отправляем список реализованных товаров на мыло
                SendBasketToEmail();

                Basket.Clear();
                Cursor = Cursors.Default;
            }
            this.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintPreviewSalesReceipt receipt = new PrintPreviewSalesReceipt(Basket.DataSource, DateTime.Now);
            FrmPrintPreview prn = new FrmPrintPreview(receipt)
            {
                MdiParent = Global.mainForm
            };
            prn.Show();
        }

        private void SendBasketToEmail()
        {
            decimal itog = Realizacia.SummaOfDay(DateTime.Now);

            string strTov = Environment.MachineName + "\\" + Environment.UserName + "\n\r"; // Наименование компьютера и пользователя

            decimal summa = 0;

            strTov += "----------------------------\n\r";
            foreach (DataRow dr in Basket.DataSource.Rows)
            {
                strTov += dr["data"].ToString() + "\t" + dr["code"] + "\t" + dr["NameTovar"] + "\t" + dr["kol"].ToString() + "\t" + string.Format("{0:f}", dr["Cena"]) + "\t" + string.Format("{0:f}", dr["Summa"]) + "\t" + dr["prim"] + "\n\r";
                summa += Convert.ToDecimal(dr["Summa"]);
            }

            strTov += "----------------------------\n\r";
            strTov += "ИТОГО на сумму: " + string.Format("{0:f}", summa) + "\n\r";
            strTov += "ВСЕГО ЗА ДЕНЬ: " + string.Format("{0:f}", itog);


            email.SendEmailsReport("Реализация товаров " + DateTime.Now.ToString(), strTov);
        }


        private void dgBasket_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {

            if (e.ColumnIndex == 5 && e.RowIndex >= 0 && dgBasket[e.ColumnIndex, e.RowIndex].Selected)
            {
                int w=e.CellBounds.Width;
                panelButtonDG.Width = w;
                panelButtonDG.Height = e.CellBounds.Height-1;
                panel1.Width = w / 2;
                panel2.Width = w / 2;
                panelButtonDG.Visible = true;
                panelButtonDG.Location = new Point(e.CellBounds.X + (e.CellBounds.Width - panelButtonDG.Width), e.CellBounds.Y + dgBasket.Location.Y);
            }
            else
            {
                panelButtonDG.Visible = false;
            }
        }

        private void BtnDel_Click(object sender, EventArgs e)
        {
            DeleteRow();
        }

        private void btnEd_Click(object sender, EventArgs e)
        {
            TovarSale();
        }

        private void btnClearBasket_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Все позиции будут удалены! Продолжить?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                Basket.Clear();
                DisplaySumm();
                frmInfoSales frm = new frmInfoSales();
                frm.ShowAlert("Корзина покупок пуста", "Внимание", frmInfoSales.EnmType.Warning);
            }

            button1.Focus();
        }

        private void btnEd_MouseMove(object sender, MouseEventArgs e)
        {
            btnEd.Focus();
        }

        private void nbNal_TextChanged(object sender, EventArgs e)
        {

        }

        private void nbBeznal_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRevers_Click(object sender, EventArgs e)
        {
            decimal val1, val2;
            
            val1 = nbNal.Value;
            val2 = nbBeznal.Value;
            if (val1 > Basket.GetCenaSumm)
            {
                nbBeznal.Value = Basket.GetCenaSumm-val2;
                lblInfoSdacha.Text = null;
            }
            else
            {
                nbBeznal.Value = val1;
            }

            nbNal.Value = val2; 
        }



        private void nbNal_Validating(object sender, CancelEventArgs e)
        {
            nbNalValid();
        }

        private void nbBeznal_Validating(object sender, CancelEventArgs e)
        {
            nbBeznalValid();
        }

        private void nbBeznal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                nbBeznalValid();
            }
        }

        private void nbNal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                nbNalValid();
            }
        }

        private void nbNalValid()
        {
                if (nbNal.Value <= Basket.GetCenaSumm)
                {
                    nbBeznal.Value = Basket.GetCenaSumm - nbNal.Value;
                    lblInfoSdacha.Text = null;
                }

                if (nbNal.Value > Basket.GetCenaSumm)
                {
                    Sdacha = Basket.GetCenaSumm - nbBeznal.Value - nbNal.Value;
                    lblInfoSdacha.Text = string.Format("Сдача клиенту = {0:f}", Math.Abs(Sdacha).ToString());
                }
                else
                {
                    lblInfoSdacha.Text = null;
                }
        }

        private void nbBeznalValid()
        {
            if (nbBeznal.Value < Basket.GetCenaSumm)
            {
                nbNal.Value = Basket.GetCenaSumm - nbBeznal.Value;
            }
            else
            {
                decimal val=Basket.GetCenaSumm - nbNal.Value;
                if (val >= 0)
                {
                    nbBeznal.Value = val;
                }
                else
                {
                    nbBeznal.Value = 0;
                }
            }
        }
    }
}
