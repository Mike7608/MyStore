﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace MyShop.MAGAZIN
{
    public delegate void SalesHandler();

    static class Realizacia
    {
         static SQLmodule sql = new SQLmodule();
         static DataTable dtSales = new DataTable();
         static public event SalesHandler SavingData;
         static public event SalesHandler LoadData;
         static public readonly string Oshibka = "Ошибка";
       
        static private int NextValueGroup()
        {
            //SELECT MAX ([korz]) as MAXid  FROM [FindPrice].[dbo].[SALES]
            int val = sql.NewID("SALES", "korz");
            return val;
        }

        //public Realizacia()
        //{

        //}

        /// <summary>
        /// Процедура сохраняет корзину покупок в таблице SALES
        /// </summary>
        /// <param name="dt">Корзина покупок</param>
        static public void Save(DataTable dt)
        {
            int valGroup = NextValueGroup();
            string strSqlInsert = null;
            foreach(DataRow dr in dt.Rows)
            {
                strSqlInsert += InsString(dr, valGroup);
            }
            sql.InsertRow(strSqlInsert);

            SavingData?.Invoke();
        }

        static private string InsString(DataRow dr, int gr)
        {
            string str = null;
            if (dr != null)
            {
                str = $"INSERT INTO [SALES] (idtov, code, kol, cena, data, prim, korz) VALUES ('{dr["idtov"]}', '{dr["code"]}', {dr["kol"].ToString().Replace(',','.')}, {dr["cena"].ToString().Replace(',', '.')}, '{dr["data"]}', '{dr["prim"]}', {gr}); ";
            }
            return str;

        }

        static public void Load(DateTime start, DateTime end)
        {
            dtSales.Clear();
            string dateStart, dateEnd;
            dateStart = start.ToShortDateString();
            dateEnd = end.AddDays(1).ToShortDateString();
            string strSQL = "SELECT SALES.id, SALES.code, SALES.kol, SALES.cena, SALES.data, SALES.prim, SALES.korz, SALES.idtov, _SC156.DESCR, SALES.kol*SALES.cena as Summa " +
                            "FROM SALES INNER JOIN _SC156 ON SALES.idtov = _SC156.ID " +
                            "GROUP BY SALES.id, SALES.code, SALES.kol, SALES.cena, SALES.data, SALES.prim, SALES.korz, SALES.idtov, _SC156.DESCR " +
                            $"HAVING(SALES.data >= '{dateStart}') AND(SALES.data < '{dateEnd}')";
            sql.SQLselect(strSQL, dtSales);

            //var keys = new DataColumn[1];
            //keys[0] = dtSales.Columns["id"];
            //dtSales.PrimaryKey = keys;

            sql.SetPrimaryKey(dtSales, dtSales.Columns["id"]);

            LoadData?.Invoke();
        }

        static public decimal SummaOfDay(DateTime date)
        {
            decimal sum = 0;
            string dateStart, dateEnd;
            dateStart = date.ToShortDateString();
            dateEnd = date.AddDays(1).ToShortDateString();
            object val=sql.SelectOneValue($"SELECT SUM(SALES.kol*SALES.cena) FROM SALES WHERE SALES.data >= '{dateStart}' AND SALES.data < '{dateEnd}' AND SALES.PRIM<>'{Oshibka}'");
            if (!string.IsNullOrEmpty(val.ToString()))
            {
                sum = Convert.ToDecimal(val);
            }

            return sum;
        }

        static public void Load()
        {
            DateTime dateTimeEnd = DateTime.Now;
            dateTimeEnd.AddDays(1);
            Load(DateTime.Now, dateTimeEnd);
        }

        static public DataTable DataSource
        {
            get
            {
                return dtSales;
            }
        }

        static public string NameTable
        {
            get
            {
                return dtSales.TableName;
            }
        }

        //static public void SetError(DataTable err)
        //{
        //    string strS = null;
        //    foreach (DataRow dr in err.Rows)
        //    {
        //        strS += UpdString(dr);
        //    }
        //    sql.UpdateRow(strS);
        //    SavingData?.Invoke();
        //}

        static private string UpdString(DataRow dr)
        {
            string str;
            str = $"UPDATE [SALES] SET [prim]='{dr["prim"]}' WHERE [id]={dr["id"]}; ";
            return str;
        }

        static public void UpdPrim(DataRow dr)
        {
            if (dr != null)
            {
                string str = UpdString(dr);
                sql.UpdateRow(str);
            }
            SavingData?.Invoke();
        }

        /// <summary>
        /// Сумма реализаиции за установленный период из Realizacia.DataSet
        /// </summary>
        /// <returns></returns>
        static public decimal Summa()
        {
            decimal sum = 0;
            if (DataSource != null)
            {
                foreach (DataRow dr in DataSource.Rows)
                {
                    string str = dr["prim"].ToString();
                    int x = str.IndexOf(Oshibka);
                    if (x < 0)
                    {
                        sum += Convert.ToDecimal(dr["summa"]);
                    }

                }
            }
            return sum;
        }

        /// <summary>
        /// Процедура возвращает количество единиц (сумма по колонке Количество)
        /// </summary>
        /// <returns></returns>
        static public decimal SummaKol()
        {
            decimal val = 0;
            if (dtSales.Rows.Count > 0)
            {
                foreach (DataRow dr in dtSales.Rows)
                {
                    val += (decimal)dr["kol"];
                }
            }
            return val;
        }
    }
}
