﻿using MK;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace MyShop.MAGAZIN
{
    public partial class frmCurrentSale : Form
    {
        string _idtovar;
        string _code;

        private bool KolError;
        public decimal CenaDef { get; set; }

        public decimal MaxKol { get; set; }

        public int ID { get; set; }

        public string IDtovar 
        {
            get
            {
                return _idtovar;
            }
            set
            {
                _idtovar = value;
            }
        }

        public string CODE
        {
            get
            {
                return _code;
            }
            set
            {
                _code = value;
            }
        }

        public string NameTovar
        {
            get
            {
                return lblNameTovar.Text;
            }
            set
            {
                lblNameTovar.Text = value;
            }
        }

        public decimal KolTov
        {
            get
            {
                return nbKol.Value;
            }
            set
            {
                    if (value > 1 & IsAdding==true)
                    {
                        MaxKol = value;
                        nbKol.Value = 1;
                    }
                    else
                    {
                        MaxKol = value;
                        nbKol.Value = value;
                    }
            }
        }

        public decimal CenaTovara
        {
            get
            {
                return nbCena.Value;
            }
            set
            {
                nbCena.Value = value;
            }
        }

        public string Prim
        {
            get
            {
                return txtPrim.Text;
            }
            set
            {
                txtPrim.Text = value;
            }
        }

        public decimal MinCena { get; set; }

        public bool IsAdding { get; set; }

        public decimal Skidka { get; set; }

        public frmCurrentSale()
        {
            InitializeComponent();

            //nbKol.Focus();
            Skidka = 0;

            ucNumberBoxUpDownKol.numberBox = nbKol;
            ucNumberBoxUpDownCena.numberBox = nbCena;
            
        }


        private void FrmCurrentSale_Load(object sender, EventArgs e)
        {
            if (Skidka == 0)
            {
                CenaDef = CenaTovara;
            }


            CalcSumm();

            lblMaxKol.Text = MaxKol.ToString();


            if (MinCena > 0)
            {
                lblMinCena.Text =string.Format("{0:f}", MinCena);

            }
            else
            {
                lblMinCena.Text = "(нет)";
            }

            nbKol.MaxValue = MaxKol;
            nbKol.MinValue = 1;

            nbCena.MaxValue = CenaTovara * 100;


            nbKol.Focus();

        }


        private void CalcSumm()
        {
            txtSumma.Text =string.Format("{0:f}",nbKol.Value * nbCena.Value);

            
            if (CenaTovara != CenaDef)
            {
                Skidka = Procent(CenaTovara * KolTov, CenaDef * KolTov);

                lblInfo.Text = $"Учетная цена (за 1 ед.): {CenaDef} руб.; ";

                //если скидка
                if (CenaTovara < CenaDef)
                {
                    lblInfo.BackColor = Color.Orange;
                    decimal tmp = (CenaDef - CenaTovara) * KolTov;
                    lblInfo.Text += $"Сумма скидки: {tmp} руб. ({string.Format("{0:f}", Math.Abs(Skidka))}%);";
                }
                else //если надбавка
                {
                    lblInfo.BackColor = Color.Lime;
                    decimal tmp = (CenaTovara - CenaDef) * KolTov;
                    lblInfo.Text += $"Сумма надбавки: {tmp} руб. ({string.Format("{0:f}", Skidka)}%);";
                }

            }
            else
            {
                lblInfo.BackColor = Color.WhiteSmoke;
                lblInfo.Text = null;
            }

        }


        private decimal Procent(decimal sumProd, decimal sumTov)
        {
            decimal s;
            try
            {
                s = ((sumProd / sumTov) * 100) - 100;
            }
            catch
            {
               s = 0;
            }

            return s;
        }


        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NbKol_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                nbCena.Focus();
            }
        }

        private void NbCena_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                txtPrim.Focus();
            }
        }

        private void TxtPrim_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                e.Handled = true;
                btnOK.Focus();
            }
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            if (IsAdding == true)
            {
                frmInfoSales frm = new frmInfoSales();
                frm.ShowAlert(NameTovar, "Добавлено в корзину:", frmInfoSales.EnmType.Info);

                Basket.AddRow(IDtovar, CODE,  NameTovar, KolTov, CenaTovara, txtPrim.Text, DateTime.Now, MaxKol, MinCena, Skidka, CenaDef);
                this.Close();
            }
            else
            {
                Basket.EditRow(ID, KolTov, CenaTovara, txtPrim.Text, DateTime.Now, Skidka, CenaDef);
                this.Close();
            }
        }

        private void FrmCurrentSale_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void btnResetPrice_Click(object sender, EventArgs e)
        {
            nbCena.Value = CenaDef;
            nbCena.Focus();
        }

        private void nbKol_TextChanged_1(object sender, EventArgs e)
        {
            CalcSumm();

            if (nbKol.Value > MaxKol | nbKol.Value < 1)
            {
                //MessageBox.Show($"Текущие остатки - ({MaxKol}). Введенное количество не может превышать остатки", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                frmInfoSales frm = new frmInfoSales();
                frm.ShowAlert("Значение не может быть нулевым и не может превышать текущие остатки.", "Ошибка", frmInfoSales.EnmType.Error);
                btnOK.Enabled = false;
                KolError = true;
                nbKol.Focus();
            }
            else
            {
                KolError = false;
                btnOK.Enabled = true;
            }
        }

        private void nbCena_TextChanged(object sender, EventArgs e)
        {
            CalcSumm();

            if (nbCena.Value < 0 | KolError==true)
            {
                frmInfoSales frm = new frmInfoSales();
                frm.ShowAlert("Цена реализации не может быть отрицательной.", "Ошибка", frmInfoSales.EnmType.Error);
                btnOK.Enabled = false;
                nbCena.Focus();
            }
            else
            {
                btnOK.Enabled = true;
            }
        }







        //private void NbCena_Leave(object sender, EventArgs e)
        //{
        //decimal val = Convert.ToDecimal(nbCena.Text.Replace(".",","));
        //if (val < MinCena)
        //{
        //    //MessageBox.Show("Цена реализации товара не может быть ниже цены поступления.", "Внимание!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    frmInfoSales frm = new frmInfoSales();
        //    frm.ShowAlert("Цена реализации товара не может быть ниже цены поступления.", "Ошибка", frmInfoSales.EnmType.Error);
        //    btnOK.Enabled = false;
        //    nbCena.Focus();
        //}
        //else
        //{
        //    btnOK.Enabled = true;
        //}
        //}

    }
}
