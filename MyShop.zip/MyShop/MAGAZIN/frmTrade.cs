﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.MAGAZIN
{
    public partial class FrmTrade : Form
    {
        private readonly BindingSource bsTovar = new BindingSource();
        bool IsShowSALES = false;
        private readonly int HeightFooter;
        private bool FocusCena = true;
        private bool FocusedFind;
        decimal CenaPoKursu;
        Settings set = new Settings();
        Color panelBasketBorderColor= Color.Gray;
        public delegate void panelBasketHandler();
        //public event panelBasketHandler Add;

        public DataRow CurrentRowTovar
        {
            get
            {
                int position = this.BindingContext[bsTovar].Position;
                if (position > -1)
                {
                    return ((DataRowView)bsTovar.Current).Row;
                }
                else
                {
                    return null;
                }
            }
        }



        public FrmTrade()
        {
            InitializeComponent();

            //Console.WriteLine(System.Environment.MachineName);
            //Console.WriteLine(System.Environment.UserName);

            Realizacia.SavingData += SALES_Summa;
            Realizacia.LoadData += SALES_Summa;

            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;

            //назначаем стиль таблицы
            MyStyleDataGrid dgStyle = new MyStyleDataGrid();
            dgStyle.Default(dgTovar);
            dgTovar.AutoGenerateColumns = false;
            dgTovar.DefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Regular);
            dgTovar.AllowUserToAddRows = false;
            //Segoe UI Semibold; 15,75pt; style=Bold
            dgTovar.Columns["Cena"].DefaultCellStyle.Font = new Font("Segoe UI Semibold", 16, FontStyle.Regular);
            HeightFooter = Height-ClientRectangle.Height;

            //*************
            label2.MouseEnter += panelBasket_MouseEnter;
            panelIcon.MouseEnter += panelBasket_MouseEnter;
            lblBasketKol.MouseEnter += panelBasket_MouseEnter;
            lblBasketSumma.MouseEnter += panelBasket_MouseEnter;
            label2.MouseClick += panelBasket_Click;
            panelIcon.MouseClick += panelBasket_Click;
            lblBasketKol.MouseClick += panelBasket_Click;
            lblBasketSumma.MouseClick += panelBasket_Click;
            label2.MouseLeave += panelBasket_MouseLeave;
            panelIcon.MouseLeave += panelBasket_MouseLeave;
            lblBasketKol.MouseLeave += panelBasket_MouseLeave;
            lblBasketSumma.MouseLeave += panelBasket_MouseLeave;

            uscInfoTovar1.Close += UscInfoTovar1_Close;
        }

        private void UscInfoTovar1_Close()
        {
            splitContainer1.Panel2Collapsed = true;
        }

        private void FrmTrade_Load(object sender, EventArgs e)
        {
            Basket.Initialization();
            Basket.Add += Basket_changRows;
            Basket.Delete += Basket_changRows;
            Basket.ClearTable += Basket_changRows;
            Basket.Edit += Basket_changRows;
            SALES_Summa();

            DisplayBasketSumm();


            //Показываем или скрываем типы цен
            currentPriceVhod.Visible = set.ShowMagazinPriceIn;
            ценаВходнаяtoolStripMenuItem2.Checked = currentPriceVhod.Visible;
            currentPriceCena.Visible = set.ShowMagazinPriceReal;
            ценаРеализацииToolStripMenuItem.Checked = currentPriceCena.Visible;
            currentPricePoKursu.Visible = set.ShoqMagazinPriceKurs;
            ценаПоКурсуToolStripMenuItem.Checked = currentPricePoKursu.Visible;

            SetFindFocus();

            splitContainer1.Panel2Collapsed = true;

        }

        private void SALES_Summa()
        {
            decimal sum = Realizacia.SummaOfDay(DateTime.Now);
            lblSummaSales.Text = string.Format("{0:f}", sum);
        }

        private void SetFindFocus()
        {
            FocusedFind = true;

            if (FocusCena)
            {
                findTextCena1.FindCenaFocus();

            }
            else
            {
                findTextCena1.FintTextFocus();
            }
        }

        private void Basket_changRows()
        {
            DisplayBasketSumm();
        }

        private void FindTextCena1_FindKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FindTovar();
                e.Handled = true;
                dgTovar.Focus();
            }
        }

        private void FindTovar()
        {
            dgTovar.Paint-= DgTovar_Paint; //сбрасываем сообщение фильтра о пустом результате
            DataTable dt = Global.mainDataSet.Tables[Global.NameTableOstatki];
            string[] kolText = {"CODE", "NameTovar" };
            bsTovar.DataSource= findTextCena1.FilteredTable(dt, kolText, "Cena", findTextCena1.TextFind, findTextCena1.TextCena);
            dgTovar.DataSource = bsTovar;
            if (bsTovar.Count == 0)
            {
                dgTovar.Paint += DgTovar_Paint;//выводим сообщение фильтра о пустом результате
                dgTovar.Refresh();
            }

        }

        private void DgTovar_Paint(object sender, PaintEventArgs e)
        {
            float fontSize = (dgTovar.Width / 100) * 3;
            Font font = new Font("Arial", fontSize, FontStyle.Bold);
            string info = "по данному запросу нет результатов";
            SizeF sizeF = e.Graphics.MeasureString(info, font);
            e.Graphics.DrawString(info, font, Brushes.LightPink, (dgTovar.Width-sizeF.Width)/2 , (dgTovar.Height - sizeF.Height) / 2);
        }

        private void BtnFilterClear_Click(object sender, EventArgs e)
        {
            FilterClear();
        }

        private void FilterClear()
        {

            findTextCena1.TextClear();
            bsTovar.DataSource = null;
            bsTovar.DataMember = null;
            ClearAllLabel();

            SetFindFocus();

            dgTovar.Paint -= DgTovar_Paint;
        }
        //private void PanelInfoTovar_Paint(object sender, PaintEventArgs e)
        //{
            //Pen p1 = new Pen(Brushes.Orange, 2);
            //Rectangle rect = new Rectangle(1,1, panelInfoTovar.Width - 2, panelInfoTovar.Height - 2);

            ////e.Graphics.FillRectangle(Brushes.LightYellow, e.ClipRectangle);
            //e.Graphics.DrawRectangle(p1, rect);
        //}


        private void DgTovar_KeyDown(object sender, KeyEventArgs e)
        {
            if(bsTovar.Count>0)
            {
                //if (e.KeyData == Keys.Enter)
                //{
                //    TovarSale();
                //    e.Handled = true;
                //}

                switch (e.KeyData)
                {
                    case Keys.Enter:
                        TovarSale();
                        e.Handled = true;
                        break;
                    case Keys.I:
                        MK.Procedures pr = new MK.Procedures();
                        pr.InfoOfTovar(bsTovar);
                        break;
                }
            }
        }

        private void TovarSale()
        {

            DataRow dr = CurrentRowTovar;
            if (dr != null)
            {
                using (frmCurrentSale frm = new frmCurrentSale())
                {

                    frm.IsAdding = true;
                    frm.IDtovar = dr["idtov"].ToString();
                    frm.CODE = dr["code"].ToString();
                    frm.NameTovar = dr["NameTovar"].ToString();
                    frm.KolTov = Convert.ToDecimal(dr["kol"]);

                    if (currentPricePoKursu.Visible == true)
                    {
                        frm.CenaTovara = CenaPoKursu;
                    }
                    else
                    {
                        frm.CenaTovara = Convert.ToDecimal(dr["cena"]);
                    }

                    frm.MinCena = Convert.ToDecimal(dr["Cena0"]);

                    frm.ShowDialog();
                }
            }

        }



        private void ShowBasket()
        {
            frmBasketSales frmBas = new frmBasketSales();
            frmBas.ShowDialog();
        }

        private void DgTovar_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            TovarSale();
        }


        private void DisplayBasketSumm()
        {
            lblBasketSumma.Text = string.Format("{0:f}", Basket.GetCenaSumm);
            lblBasketKol.Text = string.Format("{0}", Basket.GetKolSumm);
        }



        private void FrmTrade_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                case Keys.F9:
                    ShowBasket();
                    break;
                case Keys.Insert:
                    FocusFind();
                    break;
                case Keys.Control | Keys.Delete:
                    FilterClear();
                    SetFindFocus();
                    break;
                case Keys.Control | Keys.F:
                    FocusFind();
                    break;
            }

        }

        private void FocusFind()
        {
                    if (FocusedFind)
                    {
                        FocusCena ^= true;
                    }
                    SetFindFocus();
        }



        private void LblSummaSales_Click(object sender, EventArgs e)
        {
            Realizacia.Load();
            Global.mainForm.ЖурналПродажToolStripMenuItem_Click(null, null);
        }


        private void DgTovar_SelectionChanged(object sender, EventArgs e)
        {
            if (CurrentRowTovar != null)
            {
                decimal NewKurs =Convert.ToDecimal( Global.KursPerescheta);
                
                if ( NewKurs == 0)
                {
                    NewKurs=Convert.ToDecimal(Global.KursValuts[0].Rate);
                }

                decimal cen = Convert.ToDecimal(CurrentRowTovar["Cena"]);
                currentPriceCena.Price = Math.Round(cen, 1, MidpointRounding.AwayFromZero);

                decimal cenz = Convert.ToDecimal(CurrentRowTovar["Cena0"]);
                currentPriceVhod.Price = cenz;


                decimal oldKurs = Convert.ToDecimal(CurrentRowTovar["Kurs"]);
                    if (oldKurs == 0) { oldKurs = NewKurs; }//если курс отсутствует тогда берем текущий курс


                    CenaPoKursu = Math.Round(cen / oldKurs * NewKurs, 1, MidpointRounding.AwayFromZero);

                    if (CenaPoKursu < cen) { CenaPoKursu = cen; }//если цена по курсу меньше цены реализации тогда цена покурсу будет равна цене реализации

                currentPricePoKursu.Price = CenaPoKursu;
                uscInfoTovar1.LoadData(CurrentRowTovar["idtov"].ToString());
            }
            else
            {
                uscInfoTovar1.Clear();
            }
        }


        private void ClearAllLabel()
        {
            currentPriceCena.Price = 0;
            currentPriceVhod.Price = 0;
            currentPricePoKursu.Price = 0;
        }



        private void ДобавитьВКорзинуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TovarSale();
        }

        private void ИнформацияОТовареToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnInfo_Click(sender,e);
        }


        private void LblNameTovar_MouseLeave(object sender, EventArgs e)
        {
            Cursor = Cursors.Default;
        }

        private void LblCena_Click(object sender, EventArgs e)
        {
            if (currentPriceCena.Price > 0 & IsShowSALES==false)
            {
                TovarSale();
            }
        }

        private void LblCena_MouseEnter(object sender, EventArgs e)
        {
            if (currentPriceCena.Price > 0 & IsShowSALES == false)
            {
                Cursor = Cursors.Hand;
            }
        }

        private void LblCena_MouseLeave(object sender, EventArgs e)
        {
            Cursor = Cursors.Default;
        }

    

        private void FrmTrade_FormClosing(object sender, FormClosingEventArgs e)
        {
            Realizacia.SavingData -= SALES_Summa;
            Realizacia.LoadData -= SALES_Summa;

            //Setting.Email email = new Setting.Email();
            //email.SendEmailsReport("Реализация товаров " + DateTime.Now.ToString(), "TEST TEST");

            if (Basket.DataSource.Rows.Count > 0)
            {
                DialogResult result = MessageBox.Show("В корзине покупок имеются записи. Хотите провести реализацию?", "Корзина покупок", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result== DialogResult.Yes)
                {
                    ShowBasket();
                }
            }

        }

        private void findTextCena1_Leave(object sender, EventArgs e)
        {
            FocusedFind = false;
        }

        private void корзинаТоваровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowBasket();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (dgTovar.RowCount < 1)
            {
                добавитьВКорзинуToolStripMenuItem.Enabled = false;
                информацияОТовареToolStripMenuItem.Enabled = false;
            }
            else
            {
                добавитьВКорзинуToolStripMenuItem.Enabled = true;
                информацияОТовареToolStripMenuItem.Enabled = true;
            }
        }


        private void findTextCena1_FindClick(object sender, EventArgs e)
        {
            FindTovar();
        }

        private void dgTovar_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            panelButtonDG.Width = btnInfo.Width + BtnAdd.Width;//подгоняем длину панели с кнопками

            if (e.ColumnIndex == 1 && e.RowIndex >= 0 && dgTovar[e.ColumnIndex, e.RowIndex].Selected)
            {
                panelButtonDG.Visible = true;
                panelButtonDG.Location = new Point(e.CellBounds.X +(e.CellBounds.Width- panelButtonDG.Width-1) , e.CellBounds.Y+dgTovar.Location.Y+2);
            }
            else
            {
                panelButtonDG.Visible = false;
            }

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            TovarSale();
        }


        private void FrmTrade_Activated(object sender, EventArgs e)
        {
            SALES_Summa();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SALES_Summa();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblBasketKol_TextChanged(object sender, EventArgs e)
        {
            Font f = new Font("Segoe UI", 11, FontStyle.Regular);
            streachFontSize(lblBasketKol, f, 1);          
        }

        private void streachFontSize(Label lbl, Font f, int d)
        {
            int sCount = lbl.Text.Length;
            Font f1 = new Font(f.Name, f.Size - (sCount / d));
            lbl.Font = f1;
        }

        private void BtnAdd_MouseMove(object sender, MouseEventArgs e)
        {
            BtnAdd.Focus();
        }

        private void dgTovar_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            if (dgTovar.Rows[e.RowIndex].Selected)
            {
                using (Pen pen = new Pen(Color.Red))
                {
                    int penWidth = 2;

                    pen.Width = penWidth;

                    int x = e.RowBounds.Left + (penWidth / 2);
                    int y = e.RowBounds.Top + (penWidth / 2);
                    int width = e.RowBounds.Width - penWidth;
                    int height = e.RowBounds.Height - penWidth;

                    e.Graphics.DrawRectangle(pen, x, y, width, height);
                }
            }
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            //MK.Procedures pr = new MK.Procedures();
            //pr.InfoOfTovar(bsTovar);
            if (splitContainer1.Panel2Collapsed)
            {
                splitContainer1.Panel2Collapsed = false;

            }
            else
            {
                splitContainer1.Panel2Collapsed = true;
            }
                dgTovar.Focus();
        }

        private void btnInfo_MouseMove(object sender, MouseEventArgs e)
        {
            btnInfo.Focus();
        }


        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (set.ShowMagazinPriceIn == true)
            {
                set.ShowMagazinPriceIn = false;
                currentPriceVhod.Visible = false;
                ценаВходнаяtoolStripMenuItem2.Checked = false;
            }
            else
            {
                set.ShowMagazinPriceIn = true;
                currentPriceVhod.Visible = true;
                ценаВходнаяtoolStripMenuItem2.Checked = true;
            }
            set.Save();
        }

        private void ценаРеализацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (set.ShowMagazinPriceReal == true)
            {
                set.ShowMagazinPriceReal = false;
                currentPriceCena.Visible = false;
                ценаРеализацииToolStripMenuItem.Checked = false;
            }
            else
            {
                set.ShowMagazinPriceReal = true;
                currentPriceCena.Visible = true;
                ценаРеализацииToolStripMenuItem.Checked = true;
            }
            set.Save();
        }

        private void ценаПоКурсуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (set.ShoqMagazinPriceKurs == true)
            {
                set.ShoqMagazinPriceKurs = false;
                currentPricePoKursu.Visible = false;
                ценаПоКурсуToolStripMenuItem.Checked = false;
            }
            else
            {
                set.ShoqMagazinPriceKurs = true;
                currentPricePoKursu.Visible = true;
                ценаПоКурсуToolStripMenuItem.Checked = true;
            }
            set.Save();
        }

        private void dgTovar_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            decimal k = Convert.ToDecimal(dgTovar.Rows[e.RowIndex].Cells["kol"].Value);

            if ( k <= 0)
            {
                dgTovar.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightGray;
                dgTovar.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.White;
            }
        }

        private void panelBasket_Click(object sender, EventArgs e)
        {
            ShowBasket();
        }

        private void panelBasket_MouseEnter(object sender, EventArgs e)
        {
            panelBasket.BackColor = Color.Gray;
            panelBasketBorderColor=Color.White;
            label2.ForeColor = Color.Yellow;
        }

        private void panelBasket_MouseLeave(object sender, EventArgs e)
        {
            panelBasket.BackColor = SystemColors.ControlDarkDark;
            panelBasketBorderColor = Color.Gray;
            label2.ForeColor = Color.Gold;
        }

        private void panelBasket_Paint(object sender, PaintEventArgs e)
        {
            int pabelBasketBorderThickness = 1;
            Pen pen = new Pen(panelBasketBorderColor, pabelBasketBorderThickness);
            Rectangle rectangle = new Rectangle(0 + (pabelBasketBorderThickness / 2), 0 + (pabelBasketBorderThickness / 2), panelBasket.Width - pabelBasketBorderThickness-2, panelBasket.Height - pabelBasketBorderThickness-2);
            e.Graphics.DrawRectangle(pen, rectangle);

        }


        private void lblBasketSumma_TextChanged(object sender, EventArgs e)
        {
            Font f = new Font("Segoe UI Semibold", 18, FontStyle.Bold);
            streachFontSize(lblBasketSumma, f, 2);
        }

        private void lblBasketKol_Paint(object sender, PaintEventArgs e)
        {
            Brush brC= Brushes.Maroon;
            Brush brT = Brushes.White;

            if (panelBasket.BackColor == Color.Gray)
            {
                brC = Brushes.OrangeRed;
                //brT = Brushes.Black;
            }

            Rectangle r = new Rectangle(e.ClipRectangle.X, e.ClipRectangle.Y, e.ClipRectangle.Width-1, e.ClipRectangle.Height-1);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            e.Graphics.FillEllipse(brC, r);
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            e.Graphics.DrawString(lblBasketKol.Text, lblBasketKol.Font, brT, new Point(13, 13), sf);
        }

        private void uscInfoTovar1_Close_1()
        {
            dgTovar.Focus();
        }







        //private void button1_Click(object sender, EventArgs e)
        //{
        //    System.IO.FileStream fileStream = new System.IO.FileStream("D:\\XMLdataTable.xml", System.IO.FileMode.CreateNew);
        //    DataTable dt;
        //    dt = (DataTable)bsTovar.DataSource;
        //    dt.WriteXml(fileStream);
        //}
    }
}

