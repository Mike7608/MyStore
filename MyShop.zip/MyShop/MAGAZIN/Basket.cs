﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace MyShop.MAGAZIN
{
    static class Basket
    {
        #region  ===ПЕРЕМЕННЫЕ===
        static DataTable dt;
        static string _NameTable = "Basket";

        #endregion

        #region  ===СОБЫТИЯ===
        public delegate void BasketHandler();
        static public event BasketHandler Add;
        static public event BasketHandler Delete;
        static public event BasketHandler ClearTable;
        static public event BasketHandler Edit;
        #endregion

        #region  ===СВОЙСТВА===

        /// <summary>
        /// Процедура возвращает сумму по колонке [Summa]
        /// </summary>
        static public decimal GetCenaSumm
        {
            get
            {
                decimal s=0;
                foreach(DataRow dr in dt.Rows)
                {
                    s += (decimal)dr["summa"];
                }
                return s;
            }
        }

        /// <summary>
        /// Процедура возвращает сумму по полонке [kol]
        /// </summary>
        static public decimal GetKolSumm
        {
            get
            {
                decimal s = 0;
                foreach(DataRow dr in dt.Rows)
                {
                    s += (decimal)dr["kol"];
                }
                return s;
            }
        }


        static public string NameTable 
        {
            get
            {
                return _NameTable;
            }
        }

        static public DataTable DataSource
        {
            get
            {
                return dt;
            }
        }

        #endregion

        static public void Initialization()
        {
            if (Global.mainDataSet.Tables.Contains(NameTable)==false)
            {
                CreateTable();
            }
            else
            {
                dt = Global.mainDataSet.Tables[NameTable];
            }
            var keys = new DataColumn[1];
            keys[0] = dt.Columns["id"];
            dt.PrimaryKey = keys;
        }
         
        //создаем в Global.mainDataSet таблицу для корзины
       static private void CreateTable()
        {
            dt = new DataTable();
            dt.TableName = NameTable;
            DataColumn id = new DataColumn();
            id.AutoIncrement = true;
            id.AutoIncrementSeed = 1;
            id.AutoIncrementStep = 1;
            id.Caption = "id";
            id.ColumnName = "id";
            id.DataType = typeof(int);
            dt.Columns.Add(id);
            dt.Columns.Add("idtov", typeof(string));
            dt.Columns.Add("code", typeof(string));
            dt.Columns.Add("NameTovar", typeof(string));
            dt.Columns.Add("kol", typeof(decimal));
            dt.Columns.Add("MaxKol", typeof(decimal));
            dt.Columns.Add("Cena", typeof(decimal));
            dt.Columns.Add("MinCena", typeof(decimal));
            dt.Columns.Add("Summa", typeof(decimal));
            dt.Columns.Add("Skidka", typeof(decimal));
            dt.Columns.Add("CenaDef", typeof(decimal));
            dt.Columns.Add("data", typeof(DateTime));
            dt.Columns.Add("prim", typeof(string));
            Global.mainDataSet.Tables.Add(dt);


        }

        /// <summary>
        /// Процедура добавляет строку с заданными параметрами в таблицу
        /// </summary>
        /// <param name="idtov"></param>
        /// <param name="code"></param>
        /// <param name="name"></param>
        /// <param name="kol"></param>
        /// <param name="cena"></param>
        /// <param name="prim"></param>
        /// <param name="data"></param>
        static public void AddRow(string idtov, string code, string name, decimal kol, decimal cena, string prim, DateTime data, decimal MaxKol, decimal MinCena, decimal Skidka, decimal CenaDef)
        {
            
            DataRow dr = dt.NewRow();
            dr["idtov"] = idtov;
            dr["code"] = code;
            dr["NameTovar"] = name;
            dr["kol"] = kol;
            dr["Cena"] = cena;
            dr["Prim"] = prim;
            dr["data"] = data;
            dr["summa"] = kol * cena;
            dr["MaxKol"] = MaxKol;
            dr["MinCena"] = MinCena;
            dr["Skidka"] = Skidka;
            dr["CenaDef"] = CenaDef;
            dt.Rows.Add(dr);
            if (Add != null)
            {
                Add();
            }

        }

        /// <summary>
        /// Процедура редактирования строки с заданными параметрами
        /// </summary>
        /// <param name="id">ключевое значение поля для поиска строки</param>
        /// <param name="idtov">Новое значение</param>
        /// <param name="code">Новое значение</param>
        /// <param name="name">Новое значение</param>
        /// <param name="kol">Новое значение</param>
        /// <param name="cena">Новое значение</param>
        /// <param name="prim">Новое значение</param>
        /// <param name="data">Новое значение</param>
        static public void EditRow(int id, decimal kol, decimal cena, string prim, DateTime data, decimal Skidka, decimal CenaDef)
        {
            DataRow dr = Find(id);
            dr.BeginEdit();
            dr["kol"] = kol;
            dr["Cena"] = cena;
            dr["Prim"] = prim;
            dr["data"] = data;
            dr["summa"] = kol * cena;
            dr["Skidka"] = Skidka;
            dr["CenaDef"] = CenaDef;
            dr.EndEdit();
            if (Edit != null)
            {
                Edit();
            }
        }

        /// <summary>
        /// Процедура удаляет строку с заданным индексом
        /// </summary>
        /// <param name="id"></param>
        static public void DeleteRow(int id)
        {
            DataRow dr = dt.Rows.Find(id);
            dr.Delete();
            if (Delete != null)
            {
                Delete();
            }
        }

        /// <summary>
        /// Процедура находит запись с заданным ключом
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        static public DataRow Find(int id)
        {
            DataRow dr = dt.Rows.Find(id);
            return dr;
        }

        /// <summary>
        /// Процедура очищает таблицу
        /// </summary>
        static public void Clear()
        {
            dt.Clear();
            if (ClearTable != null)
            {
                ClearTable();
            }
        }
    }
}
