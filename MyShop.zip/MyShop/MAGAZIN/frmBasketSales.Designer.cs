﻿
namespace MyShop.MAGAZIN
{
    partial class frmBasketSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelUp = new System.Windows.Forms.Panel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblPrim = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelSumm = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRevers = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblItogoKol = new System.Windows.Forms.Label();
            this.lblItogoPos = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSumma = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClearBasket = new System.Windows.Forms.Button();
            this.dgBasket = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameTovarB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KolB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Summa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.lblInfoSdacha = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRealizacia = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnEd = new System.Windows.Forms.Button();
            this.BtnDel = new System.Windows.Forms.Button();
            this.panelButtonDG = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.nbBeznal = new MyShop.NumberBox();
            this.nbNal = new MyShop.NumberBox();
            this.panelUp.SuspendLayout();
            this.panelSumm.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBasket)).BeginInit();
            this.panelBottom.SuspendLayout();
            this.panelButtonDG.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelUp
            // 
            this.panelUp.BackColor = System.Drawing.Color.SteelBlue;
            this.panelUp.Controls.Add(this.lblName);
            this.panelUp.Controls.Add(this.lblPrim);
            this.panelUp.Controls.Add(this.label6);
            this.panelUp.Controls.Add(this.lblCode);
            this.panelUp.Controls.Add(this.label2);
            this.panelUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUp.Location = new System.Drawing.Point(0, 0);
            this.panelUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelUp.Name = "panelUp";
            this.panelUp.Size = new System.Drawing.Size(938, 54);
            this.panelUp.TabIndex = 0;
            // 
            // lblName
            // 
            this.lblName.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(16, 29);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(773, 20);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "(отсутствует)";
            // 
            // lblPrim
            // 
            this.lblPrim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(143)))), ((int)(((byte)(185)))));
            this.lblPrim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPrim.ForeColor = System.Drawing.Color.White;
            this.lblPrim.Location = new System.Drawing.Point(374, 8);
            this.lblPrim.Name = "lblPrim";
            this.lblPrim.Size = new System.Drawing.Size(557, 21);
            this.lblPrim.TabIndex = 2;
            this.lblPrim.Text = "(отсутствует)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(282, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Примечание:";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.ForeColor = System.Drawing.Color.White;
            this.lblCode.Location = new System.Drawing.Point(140, 9);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(82, 17);
            this.lblCode.TabIndex = 0;
            this.lblCode.Text = "(отсутствует)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(16, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Код товара по 1С:";
            // 
            // panelSumm
            // 
            this.panelSumm.BackColor = System.Drawing.Color.SteelBlue;
            this.panelSumm.Controls.Add(this.panel4);
            this.panelSumm.Controls.Add(this.lblItogoKol);
            this.panelSumm.Controls.Add(this.lblItogoPos);
            this.panelSumm.Controls.Add(this.label5);
            this.panelSumm.Controls.Add(this.label4);
            this.panelSumm.Controls.Add(this.lblSumma);
            this.panelSumm.Controls.Add(this.label1);
            this.panelSumm.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelSumm.Location = new System.Drawing.Point(0, 258);
            this.panelSumm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelSumm.Name = "panelSumm";
            this.panelSumm.Size = new System.Drawing.Size(938, 131);
            this.panelSumm.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.CadetBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 62);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(938, 69);
            this.panel4.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightBlue;
            this.panel3.Controls.Add(this.btnRevers);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.nbBeznal);
            this.panel3.Controls.Add(this.nbNal);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(440, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(496, 67);
            this.panel3.TabIndex = 7;
            // 
            // btnRevers
            // 
            this.btnRevers.FlatAppearance.BorderSize = 0;
            this.btnRevers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRevers.Image = global::MyShop.Properties.Resources.Revers;
            this.btnRevers.Location = new System.Drawing.Point(215, 27);
            this.btnRevers.Name = "btnRevers";
            this.btnRevers.Size = new System.Drawing.Size(35, 34);
            this.btnRevers.TabIndex = 6;
            this.btnRevers.UseVisualStyleBackColor = true;
            this.btnRevers.Click += new System.EventHandler(this.btnRevers_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(271, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 17);
            this.label10.TabIndex = 5;
            this.label10.Text = "Безналичные:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(22, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "Наличные:";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Teal;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(496, 21);
            this.label8.TabIndex = 0;
            this.label8.Text = "Принимаемые средства от клиента:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblItogoKol
            // 
            this.lblItogoKol.AutoSize = true;
            this.lblItogoKol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblItogoKol.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblItogoKol.ForeColor = System.Drawing.Color.White;
            this.lblItogoKol.Location = new System.Drawing.Point(281, 27);
            this.lblItogoKol.Name = "lblItogoKol";
            this.lblItogoKol.Size = new System.Drawing.Size(19, 21);
            this.lblItogoKol.TabIndex = 6;
            this.lblItogoKol.Text = "0";
            // 
            // lblItogoPos
            // 
            this.lblItogoPos.AutoSize = true;
            this.lblItogoPos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblItogoPos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblItogoPos.ForeColor = System.Drawing.Color.White;
            this.lblItogoPos.Location = new System.Drawing.Point(112, 26);
            this.lblItogoPos.Name = "lblItogoPos";
            this.lblItogoPos.Size = new System.Drawing.Size(19, 21);
            this.lblItogoPos.TabIndex = 6;
            this.lblItogoPos.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(155, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Общее количество:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(9, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Всего позиций:";
            // 
            // lblSumma
            // 
            this.lblSumma.Font = new System.Drawing.Font("Segoe UI Semibold", 28F, System.Drawing.FontStyle.Bold);
            this.lblSumma.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblSumma.Location = new System.Drawing.Point(562, 4);
            this.lblSumma.Name = "lblSumma";
            this.lblSumma.Size = new System.Drawing.Size(359, 55);
            this.lblSumma.TabIndex = 6;
            this.lblSumma.Text = "0";
            this.lblSumma.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(376, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "ИТОГО НА СУММУ:";
            // 
            // btnClearBasket
            // 
            this.btnClearBasket.BackColor = System.Drawing.Color.IndianRed;
            this.btnClearBasket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearBasket.ForeColor = System.Drawing.Color.White;
            this.btnClearBasket.Location = new System.Drawing.Point(19, 18);
            this.btnClearBasket.Name = "btnClearBasket";
            this.btnClearBasket.Size = new System.Drawing.Size(163, 44);
            this.btnClearBasket.TabIndex = 7;
            this.btnClearBasket.Text = "Очистить корзину";
            this.btnClearBasket.UseVisualStyleBackColor = false;
            this.btnClearBasket.Click += new System.EventHandler(this.btnClearBasket_Click);
            // 
            // dgBasket
            // 
            this.dgBasket.AllowUserToAddRows = false;
            this.dgBasket.AllowUserToDeleteRows = false;
            this.dgBasket.BackgroundColor = System.Drawing.Color.AliceBlue;
            this.dgBasket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBasket.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.NameTovarB,
            this.KolB,
            this.CenaB,
            this.Summa,
            this.colEdit});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.AliceBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBasket.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgBasket.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgBasket.Location = new System.Drawing.Point(0, 54);
            this.dgBasket.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgBasket.Name = "dgBasket";
            this.dgBasket.RowHeadersWidth = 30;
            this.dgBasket.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgBasket.Size = new System.Drawing.Size(938, 204);
            this.dgBasket.StandardTab = true;
            this.dgBasket.TabIndex = 1;
            this.dgBasket.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgBasket_CellPainting);
            this.dgBasket.DoubleClick += new System.EventHandler(this.dgBasket_DoubleClick);
            this.dgBasket.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgBasket_KeyDown);
            // 
            // Id
            // 
            this.Id.HeaderText = "id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            this.Id.Width = 5;
            // 
            // NameTovarB
            // 
            this.NameTovarB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NameTovarB.DataPropertyName = "NameTovar";
            this.NameTovarB.HeaderText = "Наименование товара";
            this.NameTovarB.Name = "NameTovarB";
            // 
            // KolB
            // 
            this.KolB.DataPropertyName = "kol";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.KolB.DefaultCellStyle = dataGridViewCellStyle1;
            this.KolB.HeaderText = "Количество";
            this.KolB.Name = "KolB";
            this.KolB.Width = 60;
            // 
            // CenaB
            // 
            this.CenaB.DataPropertyName = "Cena";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N2";
            this.CenaB.DefaultCellStyle = dataGridViewCellStyle2;
            this.CenaB.HeaderText = "Цена";
            this.CenaB.Name = "CenaB";
            // 
            // Summa
            // 
            this.Summa.DataPropertyName = "Summa";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.Format = "N2";
            this.Summa.DefaultCellStyle = dataGridViewCellStyle3;
            this.Summa.HeaderText = "Сумма";
            this.Summa.Name = "Summa";
            // 
            // colEdit
            // 
            this.colEdit.HeaderText = "";
            this.colEdit.Name = "colEdit";
            this.colEdit.ReadOnly = true;
            this.colEdit.Width = 80;
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelBottom.Controls.Add(this.lblInfoSdacha);
            this.panelBottom.Controls.Add(this.btnClearBasket);
            this.panelBottom.Controls.Add(this.button1);
            this.panelBottom.Controls.Add(this.btnRealizacia);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 389);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(938, 79);
            this.panelBottom.TabIndex = 7;
            // 
            // lblInfoSdacha
            // 
            this.lblInfoSdacha.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblInfoSdacha.Location = new System.Drawing.Point(231, 16);
            this.lblInfoSdacha.Name = "lblInfoSdacha";
            this.lblInfoSdacha.Size = new System.Drawing.Size(370, 46);
            this.lblInfoSdacha.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(773, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 44);
            this.button1.TabIndex = 9;
            this.button1.Text = "&Закрыть";
            this.toolTip1.SetToolTip(this.button1, "Выход без реализации [Esc]");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRealizacia
            // 
            this.btnRealizacia.BackColor = System.Drawing.SystemColors.Control;
            this.btnRealizacia.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnRealizacia.FlatAppearance.BorderSize = 2;
            this.btnRealizacia.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnRealizacia.Location = new System.Drawing.Point(619, 18);
            this.btnRealizacia.Name = "btnRealizacia";
            this.btnRealizacia.Size = new System.Drawing.Size(148, 44);
            this.btnRealizacia.TabIndex = 8;
            this.btnRealizacia.Text = "&Реализация";
            this.toolTip1.SetToolTip(this.btnRealizacia, "Провести реализацию товаров и очистить корзину [F9]");
            this.btnRealizacia.UseVisualStyleBackColor = false;
            this.btnRealizacia.Click += new System.EventHandler(this.btnRealizacia_Click);
            // 
            // btnEd
            // 
            this.btnEd.BackColor = System.Drawing.Color.SeaGreen;
            this.btnEd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEd.FlatAppearance.BorderColor = System.Drawing.Color.OliveDrab;
            this.btnEd.FlatAppearance.BorderSize = 0;
            this.btnEd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEd.Image = global::MyShop.Properties.Resources.icons8_редактировать_241;
            this.btnEd.Location = new System.Drawing.Point(0, 0);
            this.btnEd.Name = "btnEd";
            this.btnEd.Size = new System.Drawing.Size(124, 42);
            this.btnEd.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btnEd, "Изменить текущую позицию");
            this.btnEd.UseVisualStyleBackColor = false;
            this.btnEd.Click += new System.EventHandler(this.btnEd_Click);
            this.btnEd.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnEd_MouseMove);
            // 
            // BtnDel
            // 
            this.BtnDel.BackColor = System.Drawing.Color.Tomato;
            this.BtnDel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BtnDel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnDel.FlatAppearance.BorderColor = System.Drawing.Color.OliveDrab;
            this.BtnDel.FlatAppearance.BorderSize = 0;
            this.BtnDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDel.Image = global::MyShop.Properties.Resources.icons8_мусор_241;
            this.BtnDel.Location = new System.Drawing.Point(0, 0);
            this.BtnDel.Name = "BtnDel";
            this.BtnDel.Size = new System.Drawing.Size(113, 42);
            this.BtnDel.TabIndex = 3;
            this.toolTip1.SetToolTip(this.BtnDel, "Удалить текущую позицию");
            this.BtnDel.UseVisualStyleBackColor = false;
            this.BtnDel.Click += new System.EventHandler(this.BtnDel_Click);
            // 
            // panelButtonDG
            // 
            this.panelButtonDG.BackColor = System.Drawing.Color.Transparent;
            this.panelButtonDG.Controls.Add(this.panel2);
            this.panelButtonDG.Controls.Add(this.panel1);
            this.panelButtonDG.Location = new System.Drawing.Point(116, 129);
            this.panelButtonDG.Name = "panelButtonDG";
            this.panelButtonDG.Size = new System.Drawing.Size(237, 42);
            this.panelButtonDG.TabIndex = 10;
            this.panelButtonDG.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.btnEd);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(124, 42);
            this.panel2.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.BtnDel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(124, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(113, 42);
            this.panel1.TabIndex = 5;
            // 
            // nbBeznal
            // 
            this.nbBeznal.BackColor = System.Drawing.SystemColors.Window;
            this.nbBeznal.EnableErrorColorLighting = false;
            this.nbBeznal.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nbBeznal.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nbBeznal.Location = new System.Drawing.Point(367, 27);
            this.nbBeznal.MaxValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbBeznal.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbBeznal.Name = "nbBeznal";
            this.nbBeznal.Size = new System.Drawing.Size(92, 33);
            this.nbBeznal.TabIndex = 4;
            this.nbBeznal.Text = "0";
            this.nbBeznal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nbBeznal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbBeznal.TextChanged += new System.EventHandler(this.nbBeznal_TextChanged);
            this.nbBeznal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.nbBeznal_KeyPress);
            this.nbBeznal.Validating += new System.ComponentModel.CancelEventHandler(this.nbBeznal_Validating);
            // 
            // nbNal
            // 
            this.nbNal.BackColor = System.Drawing.SystemColors.Window;
            this.nbNal.EnableErrorColorLighting = false;
            this.nbNal.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nbNal.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nbNal.Location = new System.Drawing.Point(99, 28);
            this.nbNal.MaxValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbNal.MinValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbNal.Name = "nbNal";
            this.nbNal.Size = new System.Drawing.Size(92, 33);
            this.nbNal.TabIndex = 4;
            this.nbNal.Text = "0";
            this.nbNal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nbNal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nbNal.TextChanged += new System.EventHandler(this.nbNal_TextChanged);
            this.nbNal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.nbNal_KeyPress);
            this.nbNal.Validating += new System.ComponentModel.CancelEventHandler(this.nbNal_Validating);
            // 
            // frmBasketSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(938, 468);
            this.Controls.Add(this.panelButtonDG);
            this.Controls.Add(this.dgBasket);
            this.Controls.Add(this.panelSumm);
            this.Controls.Add(this.panelUp);
            this.Controls.Add(this.panelBottom);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBasketSales";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Корзина покупок";
            this.Load += new System.EventHandler(this.frmBasketSales_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBasketSales_KeyDown);
            this.panelUp.ResumeLayout(false);
            this.panelUp.PerformLayout();
            this.panelSumm.ResumeLayout(false);
            this.panelSumm.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBasket)).EndInit();
            this.panelBottom.ResumeLayout(false);
            this.panelButtonDG.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelUp;
        private System.Windows.Forms.Panel panelSumm;
        private System.Windows.Forms.DataGridView dgBasket;
        private System.Windows.Forms.Label lblSumma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblItogoKol;
        private System.Windows.Forms.Label lblItogoPos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnRealizacia;
        private System.Windows.Forms.Label lblPrim;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameTovarB;
        private System.Windows.Forms.DataGridViewTextBoxColumn KolB;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaB;
        private System.Windows.Forms.DataGridViewTextBoxColumn Summa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEdit;
        private System.Windows.Forms.Panel panelButtonDG;
        private System.Windows.Forms.Button btnEd;
        private System.Windows.Forms.Button BtnDel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnClearBasket;
        private System.Windows.Forms.Label lblName;
        private NumberBox nbNal;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private NumberBox nbBeznal;
        private System.Windows.Forms.Button btnRevers;
        private System.Windows.Forms.Label lblInfoSdacha;
    }
}