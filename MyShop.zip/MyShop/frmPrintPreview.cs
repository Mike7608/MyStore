﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace MyShop
{
    public partial class FrmPrintPreview : PrintPreviewDialog
    {
        private readonly PrintDocument _pD;
        public FrmPrintPreview(PrintDocument printDocument)
        {
            InitializeComponent();

            _pD = printDocument;
            this.Width = 1080;
            this.Height = 625;
            this.FormClosing += FrmPrintPreview_FormClosing;
            this.Activated += FrmPrintPreview_Activated;
            this.Deactivate += FrmPrintPreview_Deactivate;
            this.PrintPreviewControl.Zoom = 1;
            
           

            ToolStripButton b = new ToolStripButton
            {
                DisplayStyle = ToolStripItemDisplayStyle.Text,
                Text = "&Печать"
            };
            b.Click += PrintPreview_PrintClick;
            ((ToolStrip)(this.Controls[1])).Items.RemoveAt(0);
            ((ToolStrip)(this.Controls[1])).Items.Insert(0, b);
            this.Document = _pD;
        }


        private void FrmPrintPreview_Deactivate(object sender, EventArgs e)
        {
            Global.mainForm.mnuPrint.Enabled = false;
            Global.printDocument = null;
        }

        private void FrmPrintPreview_Activated(object sender, EventArgs e)
        {
            Global.mainForm.mnuPrint.Enabled = true;
            Global.printDocument = _pD;

        }

        private void FrmPrintPreview_FormClosing(object sender, FormClosingEventArgs e)
        {
            Global.printDocument = null;
        }
        
        private void PrintPreview_PrintClick(object sender, EventArgs e)
        {
            try
            {
                PrintDialog pd1 = new PrintDialog
                {
                    Document = _pD
                    
                };
                if (_pD.DefaultPageSettings.PrinterSettings.ToPage > 1)
                {
                    pd1.AllowSomePages = true;

                }
                //using (var dlg = new PrintDialog())
                //{
                //    // configure dialog
                //    dlg.AllowSomePages = true;
                //    //dlg.AllowSelection = true;
                //    //dlg.UseEXDialog = true;
                //    dlg.Document = _pD;

                //    // show allowed page range
                //    var ps = dlg.PrinterSettings;
                //    ps.MinimumPage = ps.FromPage = 1;
                //    ps.MaximumPage = ps.ToPage= 3;
                //    //ps.Copies = Convert.ToInt16(numericUpDown1.Value);

                //    //ps.PrinterName = cbox.SelectedItem.ToString();
                //    if (dlg.ShowDialog() == DialogResult.OK)
                //    {
                //        _pD.Print();
                //    }

                //}

                if (pd1.ShowDialog() == DialogResult.OK)
                {
                    //_pD.PrinterSettings.ToPage = dlg.PrinterSettings.ToPage;
                    //_pD.PrinterSettings.FromPage = dlg.PrinterSettings.FromPage;
                    _pD.Print();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ToString());
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            // Закрыть окно при нажатии ESC
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            
            //Вызываем печать документа
            if (keyData == (Keys.Control | Keys.P))
            {
                PrintPreview_PrintClick(null, null);
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
