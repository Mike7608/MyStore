﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace MyShop
{
    public partial class NumberBox : TextBox
    {
        private bool Error;
        private decimal _minValue;
        private decimal _maxValue;
        public bool EnableErrorColorLighting { get; set; }

        public decimal Value
        {
            get
            {
                    decimal val;
                try
                {

                    NumberFormatInfo provider = new NumberFormatInfo();

                    if (this.Text.Contains(".") == true)
                    {
                        provider.NumberDecimalSeparator = ".";
                    }
                    else
                    {
                        provider.NumberDecimalSeparator = ",";
                    }
                    provider.NumberGroupSeparator = " ";

                    if (!string.IsNullOrEmpty(this.Text))
                    {
                        if(this.Text=="." | this.Text == ",")
                        {
                            string txt = "0";
                            txt += this.Text;
                            this.Text = txt;
                        }
                        val = Convert.ToDecimal(this.Text, provider);
                    }
                    else
                    {
                        val = 0;
                    }


                }
                catch
                {
                    val = 0;
                }

                    return val;

            }
            set
            {

                if (value >= MinValue & value <= MaxValue)
                {
                    Error = false;
                }
                else
                {
                    Error = true;
                }

                this.Text = value.ToString();

            }
        }


        public decimal MinValue 
        {
            get { return _minValue; }
            set { _minValue = value; }
        }

        public decimal MaxValue
        {
            get { return _maxValue; }
            set { _maxValue = value; }
        }

        public NumberBox()
        {
            InitializeComponent();

            this.KeyPress += NumberBox_KeyPress;
            this.KeyDown += NumberBox_KeyDown;
            EnableErrorColorLighting = false;
        }


        private void NumberBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyData == Keys.Up)
            {
                Value += 1;
            }
            if (e.KeyData == Keys.Down)
            {
                Value -= 1;
            }

        }

        private void NumberBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            int indexDrop = this.Text.IndexOf('.');
            int indexComa = this.Text.IndexOf(',');
            if (indexComa < 0 && indexDrop < 0)
            {
                if ((e.KeyChar <= 47 || e.KeyChar >= 58) && number != 8 && number != 46 && number != 190 && number != 44) //цифры, клавиша BackSpace, запятая(44), точка (46)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if ((e.KeyChar <= 47 || e.KeyChar >= 58) && number != 8 && number != 190) //цифры, клавиша BackSpace(8) & DELETE(190)
                {
                    e.Handled = true;
                }
            }
        }


        private void NumberBox_TextChanged(object sender, EventArgs e)
        {
            if(EnableErrorColorLighting)
            {
                if (Error)
                {
                    this.BackColor = Color.LavenderBlush;
                    this.ForeColor = Color.Crimson;
                }
                else
                {
                    this.BackColor = SystemColors.Window;
                    this.ForeColor = SystemColors.WindowText;
                
                }

            }
        }

    }
}
