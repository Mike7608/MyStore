﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyShop
{
    class Quarter
    {

        public Quarter()
        {

        }
        
        public DateTime Current(int Month)
        {
            int m = startQ(Month);
            return new DateTime(DateTime.Now.Year, m, 1);
        }

        public DateTime Current(DateTime dateTime)
        {
            int m = startQ(dateTime.Month);
            return new DateTime(dateTime.Year, m, 1);
        }
        private int startQ(int month)
        {
            try
            {
            int x = 1;
            if(month>0 & month<13)
            {
                switch (month)
                {
                    case 1:
                    case 2:
                    case 3:
                        x = 1;
                        break;
                    case 4:
                    case 5:
                    case 6:
                        x = 4;
                        break;
                    case 7:
                    case 8:
                    case 9:
                        x = 7;
                        break;
                    case 10:
                    case 11:
                    case 12:
                        x = 10;
                        break;
                }
            }
            return x;
            }
            catch
            {
                throw new Exception("Неверное значение месяца");
            }
        }

    }
}
