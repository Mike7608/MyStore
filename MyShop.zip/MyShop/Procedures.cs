﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Data;
using System.Net.Mail;
using System.Net;
using System.Drawing;
using MyShop;

namespace MK
{
    class Procedures
    {

        /// <summary>
        /// Процедура возвращает строку цифр найденных во входной строке
        /// </summary>
        /// <param name="str">Например: (33) 33-33-333 -> 333333333</param>
        /// <returns></returns>
        public string OnlyDigits(string str)
        {
            string tmp = null;
            foreach (char n in str)
            {
                if (n >= '0' & n <= '9')
                {
                    tmp += n;
                }
            }
            return tmp;
        }




        /// <summary>
        /// Процедура возвращает таблицу из выбранных строк в DataGridView
        /// </summary>
        /// <param name="dg"></param>
        /// <returns></returns>
        public DataTable SelectedRows(DataGridView dg)
        {
            DataTable dtSel=null;
            if (dg.Rows.Count > 0)
            {
                DataGridViewSelectedRowCollection dc = dg.SelectedRows;
                dtSel = ((DataRowView)dg.Rows[0].DataBoundItem).DataView.Table.Clone();

                for(int i=dc.Count; i>0;i--)
                {
                    DataGridViewRow dr = dc[i-1];
                    DataRow DR;
                    DR = (DataRow)((DataRowView)dr.DataBoundItem).Row;
                    dtSel.ImportRow(DR);
                }

                //foreach (DataGridViewRow dr in dc)
                //{
                //    DataRow DR;
                //    DR = (DataRow)((DataRowView)dr.DataBoundItem).Row;
                //    dtSel.ImportRow(DR);
                //}
            }
            return dtSel;
        }
        /// <summary>
        /// Процедура выводит строку об отсутствии данных на фоне DataGridView
        /// </summary>
        /// <param name="dg"></param>
        /// <param name="e"></param>
        public void PaintNullDataString(DataGridView dg, PaintEventArgs e)
        {
            if (dg.RowCount == 0)
            {
                float fontSize = (dg.Width / 100) * 3;
                Font font = new Font("Arial", fontSize, FontStyle.Bold);
                string info = "данные отсутствуют";
                SizeF sizeF = e.Graphics.MeasureString(info, font);
                e.Graphics.DrawString(info, font, Brushes.LightGray, (dg.Width - sizeF.Width) / 2, (dg.Height - sizeF.Height) / 2);
            }

        }

        public void InfoOfTovar(BindingSource bindingSource)
        {
            DataRowView dr;

            dr = (DataRowView)bindingSource.Current;


            if (dr != null)
            {
                string id = dr["idtov"].ToString();
                using (FrmDataOfTovar frmInfo = new FrmDataOfTovar(id))
                {
                    //frmInfo.Owner = this;
                    frmInfo.ShowDialog();
                }
            }

        }

        /// <summary>
        /// Класс предбразующий цену в целые числа (рубли и копейки)
        /// </summary>
        //public class CenaToRubKop
        //{
        //    /// <summary>
        //    /// Рубли
        //    /// </summary>
        //    public readonly string Rubli;
        //    /// <summary>
        //    /// Копейки
        //    /// </summary>
        //    public readonly string Kopeyki;
        //    /// <summary>
        //    /// Процедура преоюразующая цену в целые числа
        //    /// </summary>
        //    /// <param name="cena">Цена</param>
        //    public CenaToRubKop(decimal cena)
        //    {
        //        decimal RUB;
        //        int kop;
        //        decimal tmpR = Math.Truncate(cena);
        //        RUB = (int)tmpR;
        //        decimal tmp = cena - RUB;
        //        kop = (int)(tmp * 100);
        //        Rubli = RUB.ToString();
        //        if (kop < 10)
        //        {
        //            Kopeyki = "0" + kop.ToString();
        //        }
        //        else
        //        {
        //            Kopeyki = kop.ToString();
        //        }
        //    }
        //}

    }
}
