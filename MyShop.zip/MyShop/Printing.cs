﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Printing
{

    //  ИСПОЛЬЗОВАНИЕ
    //
    //Printing.PrintTextBox box = new Printing.PrintTextBox(e.Graphics);
    //box.Text = "Hello!";
    //box.Font = new Font("Times New Roman", 10, FontStyle.Bold);
    //box.BackColor = Color.LightCoral;
    //box.Location = new Point(20, 50);
    //box.StringFormat.Alignment = StringAlignment.Center;
    //box.StringFormat.LineAlignment = StringAlignment.Center;
    //box.Border.Left = 1; box.Border.Right = 1;
    //box.Border.Bottom = 2; box.Border.Top = 2;
    //box.Paint();

    public class PrintTextBox
    {
        public Border Border = new Border();
        Graphics gr;

        public Color TextColor { get; set; }

        public Color BackColor { get; set; }

        public Color BorderColor { get; set; }

        public string Text { get; set; }

        public Font Font { get; set; }

        public Point Location { get; set; }

        public Size Size { get; set; }

        public StringFormat StringFormat { get; set; }


        public PrintTextBox(Graphics g)
        {
            gr = g;
            TextColor = Color.Black;
            BackColor = Color.Transparent;
            BorderColor = Color.Black;
            Text = "TextBox";
            Font = new Font("Arial", 12, FontStyle.Regular);
            Location = new Point(0, 0);
            Size = new Size(150, 25);
            StringFormat = new StringFormat();
        }

        public void Paint()
        {
            RectangleF rF = new RectangleF(Location, Size);
            gr.FillRectangle(new SolidBrush(BackColor), rF);
            gr.DrawString(Text, Font, new SolidBrush(TextColor), rF, StringFormat);

            //top
            if (Border.Top > 0)
            {
                Pen pT = new Pen(BorderColor, Border.Top);
                gr.DrawLine(pT, Location.X, Location.Y+(Border.Top / 2), Location.X + Size.Width, Location.Y + (Border.Top / 2));
            }

            //right
            if (Border.Right > 0)
            {
                Pen pR = new Pen(BorderColor, Border.Right);
                gr.DrawLine(pR, Location.X+Size.Width - (Border.Right / 2), Location.Y, Location.X + Size.Width - (Border.Right / 2), Location.Y + Size.Height);
            }

            //Left
            if (Border.Left > 0)
            {
                Pen pL = new Pen(BorderColor, Border.Left);
                gr.DrawLine(pL, Location.X + (Border.Left / 2), Location.Y, Location.X + (Border.Left / 2), Location.Y + Size.Height);
            }

            //Bottom
            if (Border.Bottom > 0)
            {
                Pen pB = new Pen(BorderColor, Border.Bottom);
                gr.DrawLine(pB, Location.X, Location.Y+Size.Height - (Border.Bottom / 2), Location.X + Size.Width, Location.Y+Size.Height - (Border.Bottom / 2));
            }

        }


    }

    public class Border
    {
        public Color BorderColor { get; set; }

        public int Left { get; set; }
        public int Right { get; set; }
        public int Top { get; set; }
        public int Bottom { get; set; }

        public void SetAll(int Thikness)
        {
                Left = Thikness;
                Right = Thikness;
                Top = Thikness;
                Bottom = Thikness;
        }

        public Border()
        {
            BorderColor = Color.Black;
            SetAll(0);
        }

    }

}
