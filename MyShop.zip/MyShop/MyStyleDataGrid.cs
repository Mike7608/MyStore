﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace MyShop
{
    class MyStyleDataGrid
    {
        public void Default(DataGridView dg)
        {
            DataGridViewCellStyle styleAl = new DataGridViewCellStyle();
            styleAl.SelectionBackColor= Color.DarkSeaGreen;
            styleAl.SelectionForeColor = Color.DarkSlateGray;
            styleAl.BackColor = Color.FromArgb(240, 240, 240);
            dg.AlternatingRowsDefaultCellStyle = styleAl;

            dg.BackgroundColor = Color.White;
            dg.ColumnHeadersHeight = 25;
            dg.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            DataGridViewCellStyle RowStyleDef = new DataGridViewCellStyle();
            RowStyleDef.Alignment = DataGridViewContentAlignment.MiddleLeft;
            RowStyleDef.BackColor = Color.White;
            RowStyleDef.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
            RowStyleDef.ForeColor = Color.Black;
            RowStyleDef.Padding = new Padding(5);
            RowStyleDef.SelectionBackColor = Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            RowStyleDef.SelectionForeColor = Color.Black;
            RowStyleDef.WrapMode = DataGridViewTriState.True;
            dg.RowHeadersDefaultCellStyle = RowStyleDef;
            dg.RowHeadersWidth = 30;
            dg.RowTemplate.DefaultCellStyle.SelectionBackColor = Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dg.RowTemplate.DefaultCellStyle.SelectionForeColor = Color.Black;
            dg.RowTemplate.Height = 35;
            dg.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dg.ReadOnly = true;
            dg.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dg.MultiSelect = false;
            //dg.AutoGenerateColumns = false;
            
        }


    }
}
