﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace MyShop
{
    class PhoneFormat
    {
        /// <summary>
        /// Функция конвертирует числовой номер телефона (5555555) в строку (555-55-55)
        /// </summary>
        /// <param name="PhoneNumber">числовой параметр</param>
        /// <param name="Format">формат строки. Например: (##) ###-##-##. Если задать null будет задан формат по умолчанию (##) ###-##-##</param>
        /// <returns></returns>
        public string PhoneConverter(long PhoneNumber, string Format)
        {
            string number = Convert.ToString(PhoneNumber);

            if (string.IsNullOrEmpty(Format))
            {
                Format = "(##) ###-##-##";
            }

            System.Text.RegularExpressions.Regex regexObj = new System.Text.RegularExpressions.Regex(@"[^\d]");
            number = regexObj.Replace(number, "");
            if (number.Length > 0)
            {
                number = System.Convert.ToInt64(number).ToString(Format);
            }
            return number;
        }

    }
}
