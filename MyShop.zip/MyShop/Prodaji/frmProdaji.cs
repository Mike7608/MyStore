﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.Prodaji
{
    public partial class frmProdaji : Form
    {
        Prodaji pr = new Prodaji();
        BindingSource bs = new BindingSource();

        public frmProdaji()
        {
            InitializeComponent();

            MyStyleDataGrid styleDataGrid = new MyStyleDataGrid();
            styleDataGrid.Default(dg);
            dg.AutoGenerateColumns = false;
            dg.DataSource = bs;
            controlPeriod1.DateStart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
            controlPeriod1.DateEnd = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
            bs.ListChanged += Bs_ListChanged;
            dg.Paint += Dg_Paint;

            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dg.DefaultCellStyle.Font = new Font("Segoe UI", 14, FontStyle.Regular);
        }

        private void Dg_Paint(object sender, PaintEventArgs e)
        {
            MK.Procedures procedures = new MK.Procedures();
            procedures.PaintNullDataString(dg, e);
        }

        private void Bs_ListChanged(object sender, ListChangedEventArgs e)
        {
            if (bs.Count > 0)
            {
                btnPrint.Enabled = true;
                myButtonInfoTovar.Enabled = true;
                //panelFind.Enabled = true;
            }
            else
            {
                btnPrint.Enabled = false;
                myButtonInfoTovar.Enabled = false;
                //panelFind.Enabled = false;
            }
        }

        private void ApplyFiltr()
        {
            if(findTextCena1.TextLenght>0 | findTextCena1.CenaLenght > 0)
            {
                string[] val1 = {"descr"};
                bs.DataSource = findTextCena1.FilteredTable(pr.Prod, val1, "Cena", findTextCena1.TextFind, findTextCena1.TextCena);
                dg.DataSource = bs;

            }
            
            Summa();
        }


        private void Summa()
        {
            int x;
            decimal sum = 0;
            int count = bs.Count;
            for (x = 0; x < count; x++)
            {
                var c = dg["Summ", x].Value;
                sum += Convert.ToDecimal(c);
            }

            lblSumm.Text = string.Format("{0:f}", sum);
            lblTotalRow.Text = count.ToString();
        }

        private void ControlPeriod1_ChangPeriod_1()
        {
            Cursor = Cursors.WaitCursor;
            bs.DataSource = pr.Prod;

            pr.LoadData(controlPeriod1.DateStart, controlPeriod1.DateEnd);

            Summa();
            Cursor = Cursors.Default;
        }


        private void BtnPrint_Click(object sender, EventArgs e)
        {
            PrintProdaji ot = new PrintProdaji((DataTable)bs.DataSource);
            FrmPrintPreview prn = new FrmPrintPreview(ot)
            {
                MdiParent = Global.mainForm
            };
            prn.Show();

        }

        private void frmProdaji_Resize(object sender, EventArgs e)
        {
            dg.Refresh();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void findTextCena1_FindClick_1(object sender, EventArgs e)
        {
            ApplyFiltr();
        }

        private void findTextCena1_FindKeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                ApplyFiltr();
                e.Handled = true;
            }
        }

        private void btnFilterClear_Click_1(object sender, EventArgs e)
        {
            bs.DataSource = pr.Prod;
            findTextCena1.TextClear();
            Summa();
        }


        private void dg_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ShowInfoTovar();
        }

        private void myButtonInfoTovar_Click(object sender, EventArgs e)
        {
            ShowInfoTovar();
        }

        private void ShowInfoTovar()
        {
            MK.Procedures pr = new MK.Procedures();
            pr.InfoOfTovar(bs);
        }
    }
}
