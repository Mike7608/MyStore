﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyShop.Prodaji
{
    class Prodaji
    {
        DataSet ds = new DataSet();
        SQLmodule sql = new SQLmodule();
        public DataTable Prod;
        public Prodaji()
        {
            Prod = new DataTable();
            Prod.TableName = "Prod";
            Prod.Columns.Add("iddoc");
            Prod.Columns.Add("lineno");
            Prod.Columns.Add("data", typeof(DateTime));
            Prod.Columns.Add("descr", typeof(string));
            Prod.Columns.Add("kol", typeof(double));
            Prod.Columns.Add("Cena", typeof(double));
            Prod.Columns.Add("Summa", typeof(double));
            Prod.Columns.Add("idtov");
            ds.Tables.Add(Prod);
        }

        public void LoadData(DateTime start, DateTime end)
        {
            string SQL=null;

            Prod.Clear();
            
            SQL = string.Format("SELECT [_1SJOURN].[date] as data, [_SC156].[CODE], [_SC156].[descr], [_DT16187].[lineno], [_DT16187].[sp16178] as kol, [_DT16187].[sp16183] as Summa, [_dt16187].[sp16177] as idtov, [_dt16187].[iddoc], [_1SJOURN].[iddocdef] as typedoc  " +
                " FROM _1SJOURN INNER JOIN _DH16187 ON [_1SJOURN].[iddoc]=[_DH16187].[iddoc], " +
                " _DT16187 inner join _SC156 ON [_SC156].[id]=[_dt16187].[sp16177] " +
                " WHERE [_1SJOURN].[iddocdef]='CHN' AND [_1SJOURN].[closed]=5 AND [_DT16187].[iddoc]=[_DH16187].[iddoc]  AND [_1SJOURN].[date] BETWEEN  '{0}' AND '{1}' ORDER BY date ASC", start, end);
            sql.SQLselect(SQL, ds, "Prod");

            SQL = string.Format("SELECT [_1SJOURN].[date] as data, [_SC156].[CODE], [_SC156].[descr], [_DT294].[lineno], [_DT294].[sp284] as kol, [_DT294].[sp290] as Summa, [_dt294].[sp283] as idtov, [_dt294].[iddoc], [_1SJOURN].[iddocdef] as typedoc " +
                " FROM _1SJOURN INNER JOIN _DH294 ON [_1SJOURN].[iddoc]=[_DH294].[iddoc], " +
                " _DT294 inner join _SC156 ON [_SC156].[id]=[_dt294].[sp283] " +
                " WHERE [_1SJOURN].[iddocdef]='86' AND [_1SJOURN].[closed]=5 AND [_DT294].[iddoc]=[_DH294].[iddoc]  AND [_1SJOURN].[date] BETWEEN  '{0}' AND '{1}' ORDER BY date ASC", start, end);
            sql.SQLselect(SQL, ds, "Prod");

            RaschetCen();

        }

        private void RaschetCen()
        {
            try
            {
                int totalRow = Prod.Rows.Count;

                int x;
                for (x = 0; x < totalRow; x++)
                {
                    DataRow dr;
                    dr = Prod.Rows[x];
                    double kol, cena, summa;
                    kol = Convert.ToDouble(dr["kol"]);
                    summa = Convert.ToDouble(dr["Summa"]);
                    if (kol == 0)
                    {
                        cena = summa;
                        dr["Cena"] = cena;
                    }
                    else
                    {
                        cena = summa / kol;
                        dr["Cena"] = cena;
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
