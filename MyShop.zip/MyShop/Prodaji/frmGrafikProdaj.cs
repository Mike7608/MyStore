﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace MyShop
{
    public partial class frmGrafikProdaj : Form
    {
        double[,] SummOfMonth = new double[2,12];
        //private Thread t;

        public frmGrafikProdaj()
        {
            InitializeComponent();
            //t = new Thread(LoadData);
            //t.Start();

        }

        private void frmGrafikProdaj_Load(object sender, EventArgs e)
        {
            chart1.Titles.Add("График продаж по месяцам (в тыс.руб.)");
            LoadData();
        }


        private void LoadData()  
        {
            Settings MySet = new Settings();
            Cursor = Cursors.WaitCursor;

            using (SqlConnection conn = new SqlConnection(MySet.SQLconnectionString))
            {
                string[] mon = { "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь" };
                conn.Open();
                int m ;
                DateTime data = DateTime.Now;
                int yy = data.Year-1;
                int x = 0;
                for(x=0;x<2;x++)
                {
                    chart1.Series.Add((yy + x).ToString());
                    for (m = 0; m < 12; m++)
                    {
                        string data1, data2;
                        data1 =  01 +"/"+ (m + 1) + "/" + (yy+x);
                        data2 =DateTime.DaysInMonth((yy+x),m+1) + "/" + (m+1) + "/" + (yy+x);
                        string SQL1 = string.Format("SELECT SUM([_DH16187].[sp16183]) FROM [_DH16187] inner join _1SJOURN ON [_DH16187].[iddoc]=[_1SJOURN].[iddoc]  WHERE [_1SJOURN].[date] BETWEEN '{0}' and '{1}';", data1,data2);//
                        string SQL2 = string.Format("SELECT SUM([_DH294].[sp290]) FROM [_DH294] inner join _1SJOURN ON [_DH294].[iddoc]=[_1SJOURN].[iddoc]  WHERE [_1SJOURN].[date] BETWEEN '{0}' and '{1}';", data1, data2);

                        double s1=0, s2=0;
                        SqlCommand cmd1 = new SqlCommand(SQL1, conn);
                        object tmp = cmd1.ExecuteScalar();
                        if(tmp!=DBNull.Value)
                        {
                            s1 =Convert.ToDouble(tmp);
                        }

                        SqlCommand cmd2 = new SqlCommand(SQL2, conn);
                        tmp = cmd2.ExecuteScalar();
                        if (tmp != DBNull.Value)
                        {
                            s2 = Convert.ToDouble(tmp);
                        }

                        double s3 = (s1 + s2) / 1000;
                        chart1.Series[(yy + x).ToString()].Points.AddXY(m + 1, s3);
                        chart1.Series[(yy + x).ToString()].Points[m].AxisLabel = mon[m];

                        SummOfMonth[x,m] = s3;
                        
                    }

                }

                conn.Close();
            }

            Cursor = Cursors.Default;
        }

        private void frmGrafikProdaj_Shown(object sender, EventArgs e)
        {
            //this.Refresh();
            //LoadData();
            checkBox1.Enabled = true;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            ViewSumm();
        }

        private void linkLabelUpdate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            chart1.Series.Clear();
            LoadData();
            ViewSumm();
        }

        private void ViewSumm()
        {
                int x, y;
                for(x=0;x<2;x++)
                {
                    for(y=0;y<12;y++)
                    {
                        if(this.checkBox1.Checked)
                        {
                            chart1.Series[x].Points[y].Label = string.Format("{0:N2}", SummOfMonth[x, y]);
                        }
                        else
                        {
                            chart1.Series[x].Points[y].Label = null; 
                        }

                    }
                }
        }
    }
}


