﻿
namespace MyShop.Prodaji
{
    partial class frmProdaji
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProdaji));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panelFind = new System.Windows.Forms.Panel();
            this.btnFilterClear = new System.Windows.Forms.Button();
            this.findTextCena1 = new MyShop.FindTextCena();
            this.btnExit = new MyShop.MyButton();
            this.btnPrint = new MyShop.MyButton();
            this.lblSumm = new System.Windows.Forms.Label();
            this.lblTotalRow = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.myButtonInfoTovar = new MyShop.MyButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.controlPeriod1 = new Periods.ControlPeriod();
            this.panelMain = new System.Windows.Forms.Panel();
            this.dg = new System.Windows.Forms.DataGridView();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Summ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelTop.SuspendLayout();
            this.panelFind.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelTop.Controls.Add(this.label3);
            this.panelTop.Controls.Add(this.panelFind);
            this.panelTop.Controls.Add(this.btnExit);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(986, 74);
            this.panelTop.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(75, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(402, 47);
            this.label3.TabIndex = 10;
            this.label3.Text = "Журнал реализации 1С";
            // 
            // panelFind
            // 
            this.panelFind.Controls.Add(this.btnFilterClear);
            this.panelFind.Controls.Add(this.findTextCena1);
            this.panelFind.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelFind.Location = new System.Drawing.Point(549, 0);
            this.panelFind.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelFind.Name = "panelFind";
            this.panelFind.Size = new System.Drawing.Size(437, 74);
            this.panelFind.TabIndex = 9;
            // 
            // btnFilterClear
            // 
            this.btnFilterClear.BackColor = System.Drawing.Color.Transparent;
            this.btnFilterClear.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnFilterClear.FlatAppearance.BorderSize = 2;
            this.btnFilterClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilterClear.Image = ((System.Drawing.Image)(resources.GetObject("btnFilterClear.Image")));
            this.btnFilterClear.Location = new System.Drawing.Point(382, 19);
            this.btnFilterClear.Name = "btnFilterClear";
            this.btnFilterClear.Size = new System.Drawing.Size(35, 35);
            this.btnFilterClear.TabIndex = 1;
            this.toolTip1.SetToolTip(this.btnFilterClear, "Сбросить фильтр");
            this.btnFilterClear.UseVisualStyleBackColor = false;
            this.btnFilterClear.Click += new System.EventHandler(this.btnFilterClear_Click_1);
            // 
            // findTextCena1
            // 
            this.findTextCena1.BackColor = System.Drawing.Color.White;
            this.findTextCena1.BorderColor = System.Drawing.Color.LightGray;
            this.findTextCena1.BorederTickness = 2;
            this.findTextCena1.CenaLenght = 0;
            this.findTextCena1.FindTextBackColor = System.Drawing.Color.White;
            this.findTextCena1.FindTextForeColor = System.Drawing.Color.Black;
            this.findTextCena1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findTextCena1.ForeColor = System.Drawing.Color.Black;
            this.findTextCena1.HelpTextCena = "Цена";
            this.findTextCena1.HelpTextFind = "Наименование товара";
            this.findTextCena1.Location = new System.Drawing.Point(2, 19);
            this.findTextCena1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.findTextCena1.Name = "findTextCena1";
            this.findTextCena1.Size = new System.Drawing.Size(379, 35);
            this.findTextCena1.TabIndex = 0;
            this.findTextCena1.TextCena = null;
            this.findTextCena1.TextFind = null;
            this.findTextCena1.TextLenght = 0;
            this.toolTip1.SetToolTip(this.findTextCena1, "Фильтрация данных");
            this.findTextCena1.FindClick += new MyShop.FindTextCena.ButtonFindHandler(this.findTextCena1_FindClick_1);
            this.findTextCena1.FindKeyPress += new MyShop.FindTextCena.FindTextBoxKeyPress(this.findTextCena1_FindKeyPress_1);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DimGray;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Image = global::MyShop.Properties.Resources.arrow_left_w_24;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExit.Location = new System.Drawing.Point(3, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(52, 64);
            this.btnExit.TabIndex = 8;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.DimGray;
            this.btnPrint.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Image = global::MyShop.Properties.Resources.print_search_24_w;
            this.btnPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrint.Location = new System.Drawing.Point(385, 5);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(58, 64);
            this.btnPrint.TabIndex = 2;
            this.btnPrint.Text = "Печать";
            this.btnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolTip1.SetToolTip(this.btnPrint, "Просмотр и печать");
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.BtnPrint_Click);
            // 
            // lblSumm
            // 
            this.lblSumm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSumm.AutoSize = true;
            this.lblSumm.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSumm.ForeColor = System.Drawing.Color.White;
            this.lblSumm.Location = new System.Drawing.Point(909, 42);
            this.lblSumm.Name = "lblSumm";
            this.lblSumm.Size = new System.Drawing.Size(17, 20);
            this.lblSumm.TabIndex = 1;
            this.lblSumm.Text = "0";
            // 
            // lblTotalRow
            // 
            this.lblTotalRow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTotalRow.AutoSize = true;
            this.lblTotalRow.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTotalRow.ForeColor = System.Drawing.Color.White;
            this.lblTotalRow.Location = new System.Drawing.Point(909, 12);
            this.lblTotalRow.Name = "lblTotalRow";
            this.lblTotalRow.Size = new System.Drawing.Size(17, 20);
            this.lblTotalRow.TabIndex = 1;
            this.lblTotalRow.Text = "0";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(779, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Сумма реализации:";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(808, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Всего записей:";
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelBottom.Controls.Add(this.myButtonInfoTovar);
            this.panelBottom.Controls.Add(this.panel1);
            this.panelBottom.Controls.Add(this.controlPeriod1);
            this.panelBottom.Controls.Add(this.btnPrint);
            this.panelBottom.Controls.Add(this.lblTotalRow);
            this.panelBottom.Controls.Add(this.lblSumm);
            this.panelBottom.Controls.Add(this.label1);
            this.panelBottom.Controls.Add(this.label2);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 520);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(986, 74);
            this.panelBottom.TabIndex = 1;
            // 
            // myButtonInfoTovar
            // 
            this.myButtonInfoTovar.BackColor = System.Drawing.Color.DimGray;
            this.myButtonInfoTovar.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.myButtonInfoTovar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.myButtonInfoTovar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.myButtonInfoTovar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myButtonInfoTovar.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myButtonInfoTovar.ForeColor = System.Drawing.Color.White;
            this.myButtonInfoTovar.Image = global::MyShop.Properties.Resources.icons8_Info_24;
            this.myButtonInfoTovar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.myButtonInfoTovar.Location = new System.Drawing.Point(449, 5);
            this.myButtonInfoTovar.Name = "myButtonInfoTovar";
            this.myButtonInfoTovar.Size = new System.Drawing.Size(58, 64);
            this.myButtonInfoTovar.TabIndex = 4;
            this.myButtonInfoTovar.Text = "Информация";
            this.myButtonInfoTovar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.myButtonInfoTovar.UseVisualStyleBackColor = false;
            this.myButtonInfoTovar.Click += new System.EventHandler(this.myButtonInfoTovar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Location = new System.Drawing.Point(374, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2, 59);
            this.panel1.TabIndex = 3;
            // 
            // controlPeriod1
            // 
            this.controlPeriod1.ButtonBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.controlPeriod1.ButtonBorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.controlPeriod1.ButtonForeColor = System.Drawing.Color.White;
            this.controlPeriod1.CheckedBackColor = System.Drawing.SystemColors.Highlight;
            this.controlPeriod1.ControlBackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.controlPeriod1.DateEnd = new System.DateTime(2020, 12, 5, 23, 59, 59, 0);
            this.controlPeriod1.DateStart = new System.DateTime(2020, 12, 5, 0, 0, 0, 0);
            this.controlPeriod1.DefaultPeriodOnly = false;
            this.controlPeriod1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.controlPeriod1.Location = new System.Drawing.Point(7, 5);
            this.controlPeriod1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.controlPeriod1.Name = "controlPeriod1";
            this.controlPeriod1.PeriodDefault = Periods.ControlPeriod.DefaultPeriod.Day;
            this.controlPeriod1.Size = new System.Drawing.Size(360, 66);
            this.controlPeriod1.TabIndex = 1;
            this.controlPeriod1.TextBackColor = System.Drawing.Color.Gray;
            this.controlPeriod1.TextFont = new System.Drawing.Font("Segoe UI", 10F);
            this.controlPeriod1.TextForeColor = System.Drawing.Color.White;
            this.toolTip1.SetToolTip(this.controlPeriod1, "Период выборки данных");
            this.controlPeriod1.ChangPeriod += new Periods.ControlPeriod.PeriodHandler(this.ControlPeriod1_ChangPeriod_1);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.dg);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 74);
            this.panelMain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(986, 446);
            this.panelMain.TabIndex = 2;
            // 
            // dg
            // 
            this.dg.AllowUserToAddRows = false;
            this.dg.AllowUserToDeleteRows = false;
            this.dg.BackgroundColor = System.Drawing.Color.White;
            this.dg.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.data,
            this.CODE,
            this.descr,
            this.kol,
            this.cena,
            this.Summ});
            this.dg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg.Location = new System.Drawing.Point(0, 0);
            this.dg.Name = "dg";
            this.dg.ReadOnly = true;
            this.dg.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg.Size = new System.Drawing.Size(986, 446);
            this.dg.TabIndex = 0;
            this.dg.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_CellDoubleClick);
            // 
            // data
            // 
            this.data.DataPropertyName = "data";
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.data.DefaultCellStyle = dataGridViewCellStyle1;
            this.data.HeaderText = "Дата";
            this.data.Name = "data";
            this.data.ReadOnly = true;
            this.data.Width = 130;
            // 
            // CODE
            // 
            this.CODE.DataPropertyName = "CODE";
            this.CODE.HeaderText = "Код  1С";
            this.CODE.Name = "CODE";
            this.CODE.ReadOnly = true;
            this.CODE.Width = 120;
            // 
            // descr
            // 
            this.descr.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.descr.DataPropertyName = "descr";
            this.descr.HeaderText = "Наименование товара";
            this.descr.Name = "descr";
            this.descr.ReadOnly = true;
            // 
            // kol
            // 
            this.kol.DataPropertyName = "kol";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.kol.DefaultCellStyle = dataGridViewCellStyle2;
            this.kol.HeaderText = "Количество";
            this.kol.Name = "kol";
            this.kol.ReadOnly = true;
            // 
            // cena
            // 
            this.cena.DataPropertyName = "Cena";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.cena.DefaultCellStyle = dataGridViewCellStyle3;
            this.cena.HeaderText = "Цена реализации";
            this.cena.Name = "cena";
            this.cena.ReadOnly = true;
            // 
            // Summ
            // 
            this.Summ.DataPropertyName = "Summa";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.Format = "N2";
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Summ.DefaultCellStyle = dataGridViewCellStyle4;
            this.Summ.HeaderText = "Сумма";
            this.Summ.Name = "Summ";
            this.Summ.ReadOnly = true;
            // 
            // frmProdaji
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 594);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmProdaji";
            this.Text = "Продажи (реализованные товары)";
            this.Resize += new System.EventHandler(this.frmProdaji_Resize);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelFind.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.panelBottom.PerformLayout();
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelMain;
        private Periods.ControlPeriod controlPeriod1;
        private System.Windows.Forms.DataGridView dg;
        private System.Windows.Forms.Label lblTotalRow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSumm;
        private System.Windows.Forms.Label label2;
        private MyButton btnPrint;
        private System.Windows.Forms.ToolTip toolTip1;
        private MyButton btnExit;
        private System.Windows.Forms.Panel panelFind;
        private System.Windows.Forms.Button btnFilterClear;
        private FindTextCena findTextCena1;
        private System.Windows.Forms.Panel panel1;
        private MyButton myButtonInfoTovar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn data;
        private System.Windows.Forms.DataGridViewTextBoxColumn CODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn descr;
        private System.Windows.Forms.DataGridViewTextBoxColumn kol;
        private System.Windows.Forms.DataGridViewTextBoxColumn cena;
        private System.Windows.Forms.DataGridViewTextBoxColumn Summ;
    }
}