﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace MyShop
{
    public partial class PrintProdaji : System.Drawing.Printing.PrintDocument
    {
        DataTable _dt;

        public int page = 1;
        int CurrentRow;
        decimal _kol;
        decimal _summa;

        public PrintProdaji(DataTable dt)
        {
            InitializeComponent();

            _dt = dt;

            this.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintGroupOstatki_PrintPage);
        }


        public PrintProdaji(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        private void PrintGroupOstatki_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int posX = 40, posY = 40;

            Font fontTitleBold = new Font("Arial", 10, FontStyle.Bold);
            Font fontText = new Font("Arial", 9, FontStyle.Regular);
            //Font fontTextI = new Font("Arial", 9, FontStyle.Italic);

            //выводим номер страницы
            e.Graphics.DrawString("стр. " + page.ToString(), fontText, Brushes.Gray, e.MarginBounds.Right, e.MarginBounds.Bottom);

            if (page == 1)
            {
                _kol = 0;
                _summa = 0;
                CurrentRow = 0;
                e.Graphics.DrawString("РЕАЛИЗАЦИЯ ТОВАРОВ", fontTitleBold, Brushes.Black, posX+250, posY);
                //posY += 25;
                posY += 40;
                e.Graphics.DrawString("Дата", fontText, Brushes.Black, posX, posY);
                e.Graphics.DrawString("Наименование товара", fontText, Brushes.Black, posX + 100, posY);
                e.Graphics.DrawString("Кол-во", fontText, Brushes.Black, posX + 520, posY);
                e.Graphics.DrawString("Цена", fontText, Brushes.Black, posX + 620, posY);
                e.Graphics.DrawString("Сумма", fontText, Brushes.Black, posX + 690, posY);
                e.Graphics.DrawLine(Pens.Black, posX, posY+20, 785, posY+20);

                posY += 25;
            }

            int x;
            for (x = CurrentRow; x < _dt.Rows.Count; x++)
            {
                DataRow dr = _dt.Rows[x];
                e.Graphics.DrawString(string.Format("{0:dd.MM.yyyy}",dr["data"]), fontText, Brushes.Black, posX, posY);
                RectangleF recName = new RectangleF(new Point(posX + 90, posY), new Size(440, 17));
                //e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240, 240, 240)), recName);
                e.Graphics.DrawString(dr["descr"].ToString(), fontText, Brushes.Black, recName);
                decimal kol = Convert.ToDecimal(dr["kol"]);
                _kol += kol;
                e.Graphics.DrawString(kol.ToString(), fontText, Brushes.Black, posX + 540, posY);
                RectangleF recCena = new RectangleF(new PointF(posX + 580, posY), new Size(80, 17));
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Far;
                e.Graphics.DrawString((string.Format("{0:f}", dr["Cena"])), fontText, Brushes.Black, recCena, sf);
                RectangleF recSumma = new RectangleF(new PointF(posX + 660, posY), new Size(80, 17));
                decimal summa =Convert.ToDecimal(dr["Summa"]);
                _summa += summa;
                e.Graphics.DrawString((string.Format("{0:f}", summa )), fontTitleBold, Brushes.Black, recSumma, sf);
                e.Graphics.DrawLine(Pens.LightGray, posX, posY + 20, 785, posY + 20);
                posY += 25;
                if (posY + 25 > e.MarginBounds.Bottom)
                {
                    //page++;
                    CurrentRow = x + 1;
                    //e.HasMorePages = true;
                    break;
                }
                else
                {
                    e.HasMorePages = false;
                }

            }
            //ИТОГО
            if (posY + 25 > e.MarginBounds.Bottom)
            {
                page++;
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                e.Graphics.DrawString("ИТОГО:", fontTitleBold, Brushes.Black, posX + 480, posY);
                RectangleF recSumma = new RectangleF(new PointF(posX + 660, posY), new Size(80, 17));
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Far;
                e.Graphics.DrawString((string.Format("{0:f}", _summa)), fontTitleBold, Brushes.Black, recSumma, sf);
            }

        }
    }
}
