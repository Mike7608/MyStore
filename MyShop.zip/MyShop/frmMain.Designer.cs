﻿namespace MyShop
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuImport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.обновитькурсыВалютToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPageSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMagazin = new System.Windows.Forms.ToolStripMenuItem();
            this.ПродажаТоваровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ЖурналПродажToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.товарыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.остаткиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.текущиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поГруппамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.продажиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ГрафикПродаж1СToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuJurnalPostuplenij = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCenniki = new System.Windows.Forms.ToolStripMenuItem();
            this.ОформлениеЦенниковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGarant = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьНовоеЗаявлениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuJournalServices = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.опрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripDataNow = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripWorkPeriod = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelKurs = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolbtnImport = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnJurnalPostupl = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuMagazin,
            this.товарыToolStripMenuItem,
            this.mnuCenniki,
            this.mnuGarant,
            this.mnuWindow,
            this.опрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.mnuWindow;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.menuStrip1.Size = new System.Drawing.Size(1184, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuImport,
            this.toolStripMenuItem2,
            this.обновитькурсыВалютToolStripMenuItem,
            this.toolStripMenuItem5,
            this.mnuPrint,
            this.mnuPageSettings,
            this.toolStripMenuItem3,
            this.настройкиToolStripMenuItem,
            this.toolStripMenuItem6,
            this.выходToolStripMenuItem});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(48, 20);
            this.mnuFile.Text = "&Файл";
            this.mnuFile.Click += new System.EventHandler(this.MnuFile_Click);
            // 
            // mnuImport
            // 
            this.mnuImport.Enabled = false;
            this.mnuImport.Image = global::MyShop.Properties.Resources.icons8_скачать_24;
            this.mnuImport.Name = "mnuImport";
            this.mnuImport.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.mnuImport.Size = new System.Drawing.Size(202, 22);
            this.mnuImport.Text = "&Импорт данных";
            this.mnuImport.Click += new System.EventHandler(this.MnuImport_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(199, 6);
            // 
            // обновитькурсыВалютToolStripMenuItem
            // 
            this.обновитькурсыВалютToolStripMenuItem.Name = "обновитькурсыВалютToolStripMenuItem";
            this.обновитькурсыВалютToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.обновитькурсыВалютToolStripMenuItem.Text = "Обновить &курсы валют";
            this.обновитькурсыВалютToolStripMenuItem.Click += new System.EventHandler(this.ОбновитькурсыВалютToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(199, 6);
            // 
            // mnuPrint
            // 
            this.mnuPrint.Enabled = false;
            this.mnuPrint.Name = "mnuPrint";
            this.mnuPrint.ShortcutKeyDisplayString = "";
            this.mnuPrint.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.mnuPrint.Size = new System.Drawing.Size(202, 22);
            this.mnuPrint.Text = "&Печать";
            // 
            // mnuPageSettings
            // 
            this.mnuPageSettings.Name = "mnuPageSettings";
            this.mnuPageSettings.Size = new System.Drawing.Size(202, 22);
            this.mnuPageSettings.Text = "Параметры &страницы";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(199, 6);
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.Image = global::MyShop.Properties.Resources.icons8_обслуживание_24;
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.настройкиToolStripMenuItem.Text = "&Настройки";
            this.настройкиToolStripMenuItem.Click += new System.EventHandler(this.НастройкиToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(199, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.выходToolStripMenuItem.Text = "&Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.ВыходToolStripMenuItem_Click);
            // 
            // mnuMagazin
            // 
            this.mnuMagazin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ПродажаТоваровToolStripMenuItem,
            this.ЖурналПродажToolStripMenuItem});
            this.mnuMagazin.Name = "mnuMagazin";
            this.mnuMagazin.Size = new System.Drawing.Size(66, 20);
            this.mnuMagazin.Text = "&Магазин";
            // 
            // ПродажаТоваровToolStripMenuItem
            // 
            this.ПродажаТоваровToolStripMenuItem.Image = global::MyShop.Properties.Resources.cashier_24;
            this.ПродажаТоваровToolStripMenuItem.Name = "ПродажаТоваровToolStripMenuItem";
            this.ПродажаТоваровToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.ПродажаТоваровToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.ПродажаТоваровToolStripMenuItem.Text = "&Продажа товаров";
            this.ПродажаТоваровToolStripMenuItem.Click += new System.EventHandler(this.ПродажаТоваровToolStripMenuItem_Click);
            // 
            // ЖурналПродажToolStripMenuItem
            // 
            this.ЖурналПродажToolStripMenuItem.Image = global::MyShop.Properties.Resources.index_preferences_24;
            this.ЖурналПродажToolStripMenuItem.Name = "ЖурналПродажToolStripMenuItem";
            this.ЖурналПродажToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.J)));
            this.ЖурналПродажToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.ЖурналПродажToolStripMenuItem.Text = "&Журнал продаж";
            this.ЖурналПродажToolStripMenuItem.Click += new System.EventHandler(this.ЖурналПродажToolStripMenuItem_Click);
            // 
            // товарыToolStripMenuItem
            // 
            this.товарыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.остаткиToolStripMenuItem,
            this.toolStripMenuItem4,
            this.продажиToolStripMenuItem,
            this.ГрафикПродаж1СToolStripMenuItem,
            this.toolStripMenuItem7,
            this.mnuJurnalPostuplenij});
            this.товарыToolStripMenuItem.Name = "товарыToolStripMenuItem";
            this.товарыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.товарыToolStripMenuItem.Text = "&Товары";
            // 
            // остаткиToolStripMenuItem
            // 
            this.остаткиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.текущиеToolStripMenuItem,
            this.поГруппамToolStripMenuItem});
            this.остаткиToolStripMenuItem.Name = "остаткиToolStripMenuItem";
            this.остаткиToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.остаткиToolStripMenuItem.Text = "&Остатки 1С";
            // 
            // текущиеToolStripMenuItem
            // 
            this.текущиеToolStripMenuItem.Image = global::MyShop.Properties.Resources._1C_ostatki;
            this.текущиеToolStripMenuItem.Name = "текущиеToolStripMenuItem";
            this.текущиеToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.текущиеToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.текущиеToolStripMenuItem.Text = "&Текущие (список)";
            this.текущиеToolStripMenuItem.Click += new System.EventHandler(this.ТекущиеToolStripMenuItem_Click);
            // 
            // поГруппамToolStripMenuItem
            // 
            this.поГруппамToolStripMenuItem.Image = global::MyShop.Properties.Resources._1C_ostatki_gr;
            this.поГруппамToolStripMenuItem.Name = "поГруппамToolStripMenuItem";
            this.поГруппамToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.O)));
            this.поГруппамToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.поГруппамToolStripMenuItem.Text = "Текущие (по &группам)";
            this.поГруппамToolStripMenuItem.Click += new System.EventHandler(this.ПоГруппамToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(190, 6);
            // 
            // продажиToolStripMenuItem
            // 
            this.продажиToolStripMenuItem.Image = global::MyShop.Properties.Resources.column_preferences_24;
            this.продажиToolStripMenuItem.Name = "продажиToolStripMenuItem";
            this.продажиToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.продажиToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.продажиToolStripMenuItem.Text = "Продажи 1С";
            this.продажиToolStripMenuItem.Click += new System.EventHandler(this.ПродажиToolStripMenuItem_Click);
            // 
            // ГрафикПродаж1СToolStripMenuItem
            // 
            this.ГрафикПродаж1СToolStripMenuItem.Image = global::MyShop.Properties.Resources.column_chart_24;
            this.ГрафикПродаж1СToolStripMenuItem.Name = "ГрафикПродаж1СToolStripMenuItem";
            this.ГрафикПродаж1СToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ГрафикПродаж1СToolStripMenuItem.Text = "График продаж 1С";
            this.ГрафикПродаж1СToolStripMenuItem.Click += new System.EventHandler(this.ГрафикПродаж1СToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(190, 6);
            // 
            // mnuJurnalPostuplenij
            // 
            this.mnuJurnalPostuplenij.Name = "mnuJurnalPostuplenij";
            this.mnuJurnalPostuplenij.Size = new System.Drawing.Size(193, 22);
            this.mnuJurnalPostuplenij.Text = "Журнал поступлений";
            this.mnuJurnalPostuplenij.Click += new System.EventHandler(this.mnuJurnalPostuplenij_Click_1);
            // 
            // mnuCenniki
            // 
            this.mnuCenniki.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ОформлениеЦенниковToolStripMenuItem});
            this.mnuCenniki.Name = "mnuCenniki";
            this.mnuCenniki.Size = new System.Drawing.Size(68, 20);
            this.mnuCenniki.Text = "&Ценники";
            // 
            // ОформлениеЦенниковToolStripMenuItem
            // 
            this.ОформлениеЦенниковToolStripMenuItem.Image = global::MyShop.Properties.Resources.creditcards_24;
            this.ОформлениеЦенниковToolStripMenuItem.Name = "ОформлениеЦенниковToolStripMenuItem";
            this.ОформлениеЦенниковToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.ОформлениеЦенниковToolStripMenuItem.Text = "Список ценников";
            this.ОформлениеЦенниковToolStripMenuItem.Click += new System.EventHandler(this.ОформлениеЦенниковToolStripMenuItem_Click);
            // 
            // mnuGarant
            // 
            this.mnuGarant.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьНовоеЗаявлениеToolStripMenuItem,
            this.mnuJournalServices});
            this.mnuGarant.Name = "mnuGarant";
            this.mnuGarant.Size = new System.Drawing.Size(69, 20);
            this.mnuGarant.Text = "&Гарантия";
            // 
            // создатьНовоеЗаявлениеToolStripMenuItem
            // 
            this.создатьНовоеЗаявлениеToolStripMenuItem.Name = "создатьНовоеЗаявлениеToolStripMenuItem";
            this.создатьНовоеЗаявлениеToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.создатьНовоеЗаявлениеToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.создатьНовоеЗаявлениеToolStripMenuItem.Text = "Создать новое заявление";
            this.создатьНовоеЗаявлениеToolStripMenuItem.Click += new System.EventHandler(this.СоздатьНовоеЗаявлениеToolStripMenuItem_Click);
            // 
            // mnuJournalServices
            // 
            this.mnuJournalServices.Image = global::MyShop.Properties.Resources.note_pinned_24;
            this.mnuJournalServices.Name = "mnuJournalServices";
            this.mnuJournalServices.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.mnuJournalServices.Size = new System.Drawing.Size(291, 22);
            this.mnuJournalServices.Text = "Журнал &сервисных обращений";
            this.mnuJournalServices.Click += new System.EventHandler(this.MnuJournalServices_Click);
            // 
            // mnuWindow
            // 
            this.mnuWindow.Name = "mnuWindow";
            this.mnuWindow.Size = new System.Drawing.Size(47, 20);
            this.mnuWindow.Text = "&Окна";
            // 
            // опрограммеToolStripMenuItem
            // 
            this.опрограммеToolStripMenuItem.Name = "опрограммеToolStripMenuItem";
            this.опрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.опрограммеToolStripMenuItem.Text = "О &программе";
            this.опрограммеToolStripMenuItem.Click += new System.EventHandler(this.ОпрограммеToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDataNow,
            this.toolStripWorkPeriod,
            this.toolStripStatusLabelKurs});
            this.statusStrip1.Location = new System.Drawing.Point(0, 637);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1184, 24);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripDataNow
            // 
            this.toolStripDataNow.AutoSize = false;
            this.toolStripDataNow.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripDataNow.Name = "toolStripDataNow";
            this.toolStripDataNow.Size = new System.Drawing.Size(200, 19);
            this.toolStripDataNow.Text = "Текущая дата:";
            this.toolStripDataNow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripWorkPeriod
            // 
            this.toolStripWorkPeriod.AutoSize = false;
            this.toolStripWorkPeriod.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripWorkPeriod.Name = "toolStripWorkPeriod";
            this.toolStripWorkPeriod.Size = new System.Drawing.Size(300, 19);
            this.toolStripWorkPeriod.Text = "Рабочий период:";
            this.toolStripWorkPeriod.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelKurs
            // 
            this.toolStripStatusLabelKurs.AutoSize = false;
            this.toolStripStatusLabelKurs.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatusLabelKurs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabelKurs.ForeColor = System.Drawing.SystemColors.ControlText;
            this.toolStripStatusLabelKurs.Name = "toolStripStatusLabelKurs";
            this.toolStripStatusLabelKurs.Size = new System.Drawing.Size(550, 19);
            this.toolStripStatusLabelKurs.Text = "Курсы валют: нет данных";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolbtnImport,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripSeparator5,
            this.toolStripButton3,
            this.toolStripSeparator2,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripSeparator3,
            this.btnJurnalPostupl,
            this.toolStripSeparator6,
            this.toolStripButton8,
            this.toolStripSeparator4,
            this.toolStripButton9});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1184, 31);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolbtnImport
            // 
            this.toolbtnImport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolbtnImport.Enabled = false;
            this.toolbtnImport.Image = global::MyShop.Properties.Resources.icons8_скачать_24;
            this.toolbtnImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolbtnImport.Name = "toolbtnImport";
            this.toolbtnImport.Size = new System.Drawing.Size(28, 28);
            this.toolbtnImport.Text = "Импорт данных - F10";
            this.toolbtnImport.Click += new System.EventHandler(this.toolbtnImport_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::MyShop.Properties.Resources.cashier_24;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton2.Text = "Продажа товаров (реализация) - F5";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::MyShop.Properties.Resources.index_preferences_24;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton3.Text = "Журнал продаж (реализованные товары) - Ctrl+J";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::MyShop.Properties.Resources._1C_ostatki;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton4.Text = "Остатки текущие - Ctrl+O";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::MyShop.Properties.Resources._1C_ostatki_gr;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton5.Text = "Остатки текущие по группам - Ctrl+Shift+O";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::MyShop.Properties.Resources.column_preferences_24;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton6.Text = "Журнал продаж 1С - Ctrl+S";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::MyShop.Properties.Resources.column_chart_24;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton7.Text = "График продаж 1С";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // btnJurnalPostupl
            // 
            this.btnJurnalPostupl.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnJurnalPostupl.Image = global::MyShop.Properties.Resources.shopping_list;
            this.btnJurnalPostupl.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnJurnalPostupl.Name = "btnJurnalPostupl";
            this.btnJurnalPostupl.Size = new System.Drawing.Size(28, 28);
            this.btnJurnalPostupl.Text = "Журнал поступлений";
            this.btnJurnalPostupl.Click += new System.EventHandler(this.btnJurnalPostupl_Click_1);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::MyShop.Properties.Resources.creditcards_24;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton8.Text = "Список ценников";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = global::MyShop.Properties.Resources.note_pinned_24;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton9.Text = "Журнал сервисных обращений - Ctrl+G";
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 661);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MY STORE";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.Resize += new System.EventHandler(this.FrmMain_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuGarant;
        private System.Windows.Forms.ToolStripMenuItem mnuJournalServices;
        private System.Windows.Forms.ToolStripMenuItem mnuWindow;
        private System.Windows.Forms.ToolStripMenuItem mnuImport;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        public System.Windows.Forms.ToolStripMenuItem mnuPrint;
        private System.Windows.Forms.ToolStripMenuItem mnuPageSettings;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        public System.Windows.Forms.ToolStripMenuItem товарыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem остаткиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem текущиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поГруппамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem опрограммеToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem создатьНовоеЗаявлениеToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem mnuMagazin;
        public System.Windows.Forms.ToolStripMenuItem mnuCenniki;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem продажиToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem обновитькурсыВалютToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem ПродажаТоваровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ЖурналПродажToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ГрафикПродаж1СToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ОформлениеЦенниковToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripDataNow;
        private System.Windows.Forms.ToolStripStatusLabel toolStripWorkPeriod;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolbtnImport;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem mnuJurnalPostuplenij;
        private System.Windows.Forms.ToolStripButton btnJurnalPostupl;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelKurs;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
    }
}

