﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace MyShop
{
    public partial class frmDataOfTovar : Form
    {
        InfoTovarForm1S info = new InfoTovarForm1S();

        string _idtov;
        string _SCODE;
        double _Cena;

        public frmDataOfTovar(string idtov, string code)
        {
            InitializeComponent();

            _idtov = idtov;
            Cursor = Cursors.WaitCursor;
            info.Find(idtov);//находим нужный товар
            dgCeny.DataSource = info.dsDATA;
            dgCeny.DataMember = "Ceny";

            _SCODE = info.SCODE;
            _Cena = CenaRealizTovara(idtov, code);
            lblCena.Text = string.Format("{0:N2}", _Cena );
            lblCODE.Text = info.code;
            lblKol.Text = KolOstatTovara(idtov, code).ToString() + " "+ info.EdIzm;
            txtNameTovar.Text = info.NameTovar;
            this.Text += ": " + info.NameTovar;
            txtSCODE.Text = info.SCODE;

            string descr = info.Description;
            string strana = "Страна ввоза: ";
            if(string.IsNullOrEmpty(descr))
            {
                txtDescr.Text = strana + info.CountryMade;
            }
            else
            {
                if(descr.Contains(strana))
                {
                    txtDescr.Text = descr;
                }
                else
                {
                    txtDescr.Text = descr + "\r\n" + strana + info.CountryMade;
                }
            }
            Cursor = Cursors.Default;
        }


        private double CenaRealizTovara(string idtov, string code)
        {
            double cenaR = 0;
            DataRow[] dr = NEW.BaseDBF.dsDBF.Tables["Ostatki"].Select("idtov='" + idtov + "' and code='" + code + "'");
            if(dr.Length>0)
            {
                cenaR = Convert.ToDouble(dr[0]["Cena"]);
            }
            return cenaR;
        }


        private double KolOstatTovara(string idtov, string code)
        {
            double KolT = 0;
            DataRow[] dr = NEW.BaseDBF.dsDBF.Tables["Ostatki"].Select("idtov='" + idtov + "' and code='" + code + "'");
            if (dr.Length > 0)
            {
                KolT = Convert.ToDouble(dr[0]["Kol"]);
            }
            return KolT;
        }

        private void frmDataOfTovar_Load(object sender, EventArgs e)
        {
            txtFullName.Text = info.FullNameTovar;
            LoadData();

            btnSaveSCODE.Enabled = false;
        }

        private void LoadData()
        {
            Cursor = Cursors.WaitCursor;

            if (info.dsDATA.Tables.Contains("TN"))
            {
                dg1.DataSource = info.dsDATA;
                dg1.DataMember = "TN";
                int x = dg1.Rows.Count - 1;
                dg1.FirstDisplayedScrollingRowIndex = x;
                dg1.Rows[x].Selected = true;
            }
            else
            {
                btnViewDoc.Enabled = false;
                dg1.Enabled = false;
            }


            Cursor = Cursors.Default;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(btnSaveSCODE.Enabled==true)
            {
                if(MessageBox.Show("Сохранить изменения в Штрих-коде?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
                {
                    SaveSCODE();
                    btnSaveSCODE.Enabled = false;
                }
            }
            this.Close();
        }

        private void dg1_DoubleClick(object sender, EventArgs e)
        {
            OpenTN();
        }

        private void OpenTN()
        {
            if(dg1.Rows.Count>0)
            {
                string id;//id TN
                int index;

                index = dg1.CurrentRow.Index;
                id = dg1["iddoc", index].Value.ToString();

                frmTNpost fTn = new frmTNpost(id);
                fTn.idtov = _idtov;//передаем код товара
                fTn.ShowDialog();
            }

        }

        private void btnViewDoc_Click(object sender, EventArgs e)
        {
            OpenTN();
        }

        private void txtSCODE_TextChanged(object sender, EventArgs e)
        {
            if(txtSCODE.Text.Length==0)
            {
                btnSaveSCODE.Enabled = false;
            }
            else
            {
            btnSaveSCODE.Enabled = true;

            }
        }

        private void btnSaveSCODE_Click(object sender, EventArgs e)
        {

            SaveSCODE();

        }

        private void SaveSCODE()
        {
            DBfindprice.SCODE sc = new DBfindprice.SCODE();
            DBfindprice.CODES c = new DBfindprice.CODES();
            c.IDTOV = _idtov;
            c.CODE = info.code;

            info.SCODE = txtSCODE.Text;

            if(string.IsNullOrEmpty(_SCODE)) //добавляем запись
            {
                c.SCODE = txtSCODE.Text;
                sc.InsertSCODE(c);
                btnSaveSCODE.Enabled = false;
            }
            else//обновляем запись
            {
                c.SCODE = txtSCODE.Text;
                sc.UpdateSCODE(c);
                btnSaveSCODE.Enabled = false;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnAddBasket_Click(object sender, EventArgs e)
        {
            AddToBasket();

        }

        private void AddToBasket()
        {
            Thread t;
            t = new Thread(start);
            t.Start();

            Basket b = new Basket();
            b.Add(_idtov, lblCODE.Text);
        }

        private void start()
        {
            DBfindprice.frmInfoSales f1 = new DBfindprice.frmInfoSales(txtNameTovar.Text, 1, _Cena);
            f1.ShowDialog();
        }

        private void frmDataOfTovar_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Escape)
            {
                this.Close();
            }
            if(e.KeyCode==Keys.Insert)
            {
                AddToBasket();
            }
        }
    }
}
