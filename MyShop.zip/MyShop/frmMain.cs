﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyShop.MAGAZIN;

namespace MyShop
{
    public partial class frmMain : Form
    {
        #region === ПЕРЕМЕННЫЕ ===

        private GARANT.frmGarant frmGarant=null;
        Ostatki.frmOstatkiCurrent frmRemainsCurrent = null;
        GARANT.frmGarantEdit frmNewGarant = null;
        Ostatki.frmOstatkiCurrentGroup frmOstatkiCurrentGroup = null;
        Prodaji.frmProdaji frmProdaji = null;
        MAGAZIN.FrmTrade frmTrade = null;
        MAGAZIN.FrmJournalSALES frmJournalSALES = null;
        frmGrafikProdaj frmGrafikProdaj = null;
        Ostatki.frmJurnalPostuplenij frmJurnalPostuplenij = null;
        Cennik.FrmCennikiMain frmCenniki = null;

        private readonly Settings set = new Settings();
        private readonly Thread t;

        #endregion


        public frmMain()
        {
            t= new Thread(new ThreadStart(StartForm));
            t.Start();

            InitializeComponent();

            Global.mainForm = this;
            Global.SqlConnectionString = set.SQLconnectionString;

            toolStripDataNow.Text = "Текущая дата: " + DateTime.Today.ToShortDateString();

            WorkPeriodDisplay();

            StartLoadRemains();

            if (Global.SqlConnectionString.Contains(Environment.MachineName))
            {
                toolbtnImport.Enabled = true;
                mnuImport.Enabled = true;
            }

        }

        private void WorkPeriodDisplay()
        {
            DateTime[] p = set.WorkPeriod;

            //if(DateTime.Now > p[1])
            //{
            //    MessageBox.Show("Установленный период не соответствует текущей дате!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
            //else
            //{
                string strPeriod = p[0].ToShortDateString() + " - " + p[1].ToShortDateString();
                toolStripWorkPeriod.Text = "Рабочий период: " + strPeriod;
            //}

        }

        private void StartLoadRemains()
        {
            try
            {
                Remains r = new Remains();
                r.Added += R_Added;
                r.NoAdded += R_NoAdded;
                // загружаем остатки
                r.LoadData();
            }
            catch (Exception ex)
            {
                t.Abort();
                MessageBox.Show(ex.Message,"Load Remains", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        //Выключаем меню для работы с базой импортированной из 1С если нет нужных таблиц данных в базе
        private void R_NoAdded()
        {
            товарыToolStripMenuItem.Enabled = false;
            mnuCenniki.Enabled = false;
            mnuMagazin.Enabled = false;
        }


        //Включаем меню для работы с базой импортированной из 1С
        private void R_Added()
        {
            товарыToolStripMenuItem.Enabled = true;
            mnuCenniki.Enabled = true;
            mnuMagazin.Enabled = true;
        }

         public void StartForm()
         {
           
            Application.Run(new frmSplashSCREEN());


         }

        private void FrmMain_Paint(object sender, PaintEventArgs e)
        {

            //string tmp = set.TypsDisplayCurrency;
            //string[] valuta = tmp.Split(',');

            //int posX = 20;
            //int posY = (this.Height - 160) - 20 - toolStrip1.Height;
            //RectangleF rec = new RectangleF(posX, posY, 500, 70);

            //Rectangle border = new Rectangle(posX, posY, 500, 70);

            //    StringFormat sf = new StringFormat
            //    {
            //        Alignment = StringAlignment.Center
            //    };

            //Pen BorderPen = new Pen(Color.LightGreen, 1);
            //e.Graphics.FillRectangle(Brushes.White, rec);
            //e.Graphics.DrawRectangle(BorderPen, border);

            //rec.Y += 5;
            //e.Graphics.DrawString("Курсы валют НБРБ", new Font("Arial", 10, FontStyle.Bold), Brushes.Black, rec, sf);


            //Font NameValut = new Font("Arial", 9, FontStyle.Regular);
            //Font TextValut = new Font("Arial", 11, FontStyle.Bold);
            //posY += 45;
            //RectangleF valRec = new RectangleF(posX, posY, 160, 20);
            //valuty.Find(valuta[0]);//column 1
            //e.Graphics.DrawString(valuty.Money.Scale.ToString() + " " + valuty.Money.Abbreviation.ToString() + " = " + valuty.Money.OfficialRate, TextValut, Brushes.Black, valRec, sf);
            //valRec = new RectangleF(posX, posY - 20, 160, 20);
            //e.Graphics.DrawString(valuty.Money.Name, NameValut, Brushes.Gray, valRec, sf);
            //posX += 170;
            //valRec = new RectangleF(posX, posY, 160, 20);
            //valuty.Find(valuta[1]);//column 2
            //e.Graphics.DrawString(valuty.Money.Scale.ToString() + " " + valuty.Money.Abbreviation.ToString() + " = " + valuty.Money.OfficialRate, TextValut, Brushes.Black, valRec, sf);
            //valRec = new RectangleF(posX, posY - 20, 160, 20);
            //e.Graphics.DrawString(valuty.Money.Name, NameValut, Brushes.Gray, valRec, sf);
            //posX += 170;
            //valRec = new RectangleF(posX, posY, 160, 20);
            //valuty.Find(valuta[2]);//column 3
            //e.Graphics.DrawString(valuty.Money.Scale.ToString() + " " + valuty.Money.Abbreviation.ToString() + " = " + valuty.Money.OfficialRate, TextValut, Brushes.Black, valRec, sf);
            //valRec = new RectangleF(posX, posY - 20, 160, 20);
            //e.Graphics.DrawString(valuty.Money.Name, NameValut, Brushes.Gray, valRec, sf);
        }

        private string ShowKurses()
        {
            Currency curHTTP = new Currency();
            Currency curSQL = new Currency();
            curHTTP.GetRate(set.HttpCurrency);//получаем курсы валют с HTTP сервера
            curSQL.GetRate(DateTime.Now.Subtract(TimeSpan.FromDays(1)));//получаем курсы валют из базы данных

            string tmp = set.TypsDisplayCurrency;
            string[] valuta = tmp.Split(',');

            string MainS = "Курсы валют НБРБ: ";

            int x = 0;

            foreach (string s in valuta)
            {
                Money mHttp= curHTTP.Find(valuta[x]);
                Money mSQL = curSQL.Find(valuta[x]);

                double r=0;
                if (mSQL.OfficialRate != 0)
                {
                    r = mHttp.OfficialRate - mSQL.OfficialRate;
                }

                string strR= Math.Round(r, 4).ToString();
                if (r > 0)
                {
                    strR= "+" + strR;
                }

                MainS += mHttp.Scale.ToString() + " " + mHttp.Abbreviation.ToString() + " = " + mHttp.OfficialRate + "(" + strR +");  " ;

                Global.KursValut k = new Global.KursValut();
                k.Name = mHttp.Abbreviation;
                k.Rate = Convert.ToSingle(mHttp.OfficialRate);
                k.Scale = Convert.ToInt32(mHttp.Scale);

                Global.KursValuts[x] = k;
                x++;
            }

            Global.KursPerescheta = set.KursPerescheta;

            if (Global.KursPerescheta < Global.KursValuts[0].Rate)
            {
                Global.KursPerescheta = Global.KursValuts[0].Rate;
                set.KursPerescheta = Global.KursValuts[0].Rate;
            }

            SaveNewKurs();

            return MainS;
        }


        private void SaveNewKurs()
        {
            string data = DateTime.Now.ToShortDateString();
            SQLmodule sQ = new SQLmodule();
            DataTable dtVal=new DataTable();
            sQ.SQLselect($"Select * from Currency where date='{data}'", dtVal);
            if (dtVal.Rows.Count == 0)
            {
                //добавляем новые курсы

                foreach(Global.KursValut k in Global.KursValuts)
                {
                    sQ.InsertRow($"INSERT INTO [Currency] ([date], [name], [scale], [rate]) values ('{data}', '{k.Name}', {k.Scale}, {k.Rate.ToString().Replace(',','.')});");
                }

            }
        }

        private void ВыходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void НастройкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Setting.frmSetting setW = new Setting.frmSetting();
            setW.ShowDialog();
        }

        private void MnuJournalServices_Click(object sender, EventArgs e)
        {

            if(frmGarant==null || frmGarant.IsDisposed)
            {
                frmGarant = new GARANT.frmGarant
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmGarant.Show();
            }
            else
            {
                frmGarant.Activate();
            }

        }

        private void MnuImport_Click(object sender, EventArgs e)
        {
            t.Abort();
            int c = Application.OpenForms.Count;

            if(c==1)
            {
                Setting.frmImportData frmImp = new Setting.frmImportData();
                frmImp.ShowDialog();
                WorkPeriodDisplay();
            }
            else
            {
                MessageBox.Show("Имеются открытые рабочие формы. Импортирование данных невозможно. Закройте формы (окна) и повторите попытку.", "Импорт", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void FrmMain_Resize(object sender, EventArgs e)
        {
            this.Refresh();
        }


        private void ТекущиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmRemainsCurrent == null || frmRemainsCurrent.IsDisposed)
            {
                frmRemainsCurrent = new Ostatki.frmOstatkiCurrent
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmRemainsCurrent.Show();
            }
            else
            {
                frmRemainsCurrent.Activate();
            }
        }

        private void ОпрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout f = new frmAbout();
            f.ShowDialog();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Tick += Timer1_Tick;
            timer1.Enabled = true;

            if (set.DisplayCurrency == true)
            {
                DisplayCurses();
                обновитькурсыВалютToolStripMenuItem.Enabled = true;
            }
            else
            {
                обновитькурсыВалютToolStripMenuItem.Enabled = false;
            }

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            this.Activate();
            timer1.Enabled = false;
            
            t.Abort();

            CheckPeriod();

            //CheckedTable();//проверка базы 1С бухгалтерия
        }

        private void CheckPeriod()
        {
            DateTime[] p = set.WorkPeriod;
            if (DateTime.Now > p[1])
            {
                MessageBox.Show("Рабочий период не соответствует текущей дате!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //toolStripWorkPeriod.BackColor = Color.Maroon;
                //toolStripWorkPeriod.ForeColor = Color.White;
                //toolStripDataNow.BackColor = Color.Yellow;
            }
            //else
            //{
            //    toolStripWorkPeriod.BackColor = SystemColors.Control;
            //    toolStripWorkPeriod.ForeColor = Color.Black;
            //    toolStripDataNow.BackColor = SystemColors.Control;
            //}
        }

        private void СоздатьНовоеЗаявлениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmNewGarant == null || frmNewGarant.IsDisposed)
            {
                frmNewGarant = new GARANT.frmGarantEdit
                {
                    Text = "Гарантия (новая запись)",
                    MdiParent = Global.mainForm,
                    WindowState = FormWindowState.Maximized
                };
                frmNewGarant.Show();
            }
            else
            {
                frmNewGarant.Activate();
            }
        }

        private void ПоГруппамToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmOstatkiCurrentGroup == null || frmOstatkiCurrentGroup.IsDisposed)
            {
                frmOstatkiCurrentGroup = new Ostatki.frmOstatkiCurrentGroup
                {
                    MdiParent = Global.mainForm,
                    WindowState = FormWindowState.Maximized
                };
                frmOstatkiCurrentGroup.Show();
            }
            else
            {
                frmOstatkiCurrentGroup.Activate();
            }

        }

        private void MnuFile_Click(object sender, EventArgs e)
        {
            // Проверяем переменную на наличие отчета
            // Если отчет есть, тогда включаем доступ к печати
            if(Global.printDocument!=null)
            {
                //mnuPrint.Enabled = true;
                mnuPrint.Click += PrintPreview_Click;
            }
            else
            {
                //mnuPrint.Enabled = false;
                mnuPrint.Click -= PrintPreview_Click;
            }
        }

        private void PrintPreview_Click(object sender, EventArgs e)
        {
            try
            {
                PrintDialog pd1 = new PrintDialog
                {
                    Document = Global.printDocument
                };
                if (pd1.ShowDialog() == DialogResult.OK)
                {
                    Global.printDocument.Print();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ToString());
            }

        }

        private void ПродажиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmProdaji == null || frmProdaji.IsDisposed)
            {
                frmProdaji = new Prodaji.frmProdaji
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmProdaji.Show();
            }
            else
            {
                frmProdaji.Activate();
            }
        }


        private void ОбновитькурсыВалютToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Currency c = new Currency();
            
            c.DeleteFileKurs();
            DisplayCurses();
            frmInfoSales frm = new frmInfoSales();
            frm.ShowAlert("Обновление курсов валют проведено успешно", "Курсы валют", frmInfoSales.EnmType.Success);

        }


        /// <summary>
        /// Показать курсы валют
        /// </summary>
        public void DisplayCurses()
        {
            ////здесь назначаем прорисовку курсов валют
            //foreach (Control control in Controls)
            //{
            //    if (control is MdiClient)
            //        control.Paint += FrmMain_Paint;
            //}
            SQLmodule sql = new SQLmodule();
            DataTable dt = new DataTable("Currency");

            try
            {
                
                if (set.DisplayCurrency == true)
                {
                        toolStripStatusLabelKurs.Text = ShowKurses();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Курсы валют", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void ПродажаТоваровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmTrade == null || frmTrade.IsDisposed)
            {
                frmTrade = new MAGAZIN.FrmTrade
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmTrade.WindowState = FormWindowState.Maximized;
                frmTrade.Show();
            }
            else
            {
                frmTrade.Activate();
            }
        }

        public void ЖурналПродажToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmJournalSALES == null || frmJournalSALES.IsDisposed)
            {
                frmJournalSALES = new MAGAZIN.FrmJournalSALES
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmJournalSALES.Show();
            }
            else
            {
                frmJournalSALES.Activate();
            }
        }

        private void ГрафикПродаж1СToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmGrafikProdaj == null || frmGrafikProdaj.IsDisposed)
            {
                frmGrafikProdaj = new frmGrafikProdaj
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmGrafikProdaj.Show();
            }
            else
            {
                frmGrafikProdaj.Activate();
            }
        }

        private void ОформлениеЦенниковToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmCenniki == null || frmCenniki.IsDisposed)
            {
                frmCenniki = new Cennik.FrmCennikiMain
                {
                    MdiParent = this,
                    WindowState = FormWindowState.Maximized
                };
                frmCenniki.Show();
            }
            else
            {
                frmCenniki.Activate();
            }
        }

        private void toolbtnImport_Click(object sender, EventArgs e)
        {
            MnuImport_Click(null, null);
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            ПродажаТоваровToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            ЖурналПродажToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            ТекущиеToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            ПоГруппамToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            ПродажиToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            ГрафикПродаж1СToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            ОформлениеЦенниковToolStripMenuItem_Click(null, null);
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            MnuJournalServices_Click(null, null);
        }


        private void mnuJurnalPostuplenij_Click_1(object sender, EventArgs e)
        {
            if (frmJurnalPostuplenij == null || frmJurnalPostuplenij.IsDisposed)
            {
                frmJurnalPostuplenij = new Ostatki.frmJurnalPostuplenij
                {
                    MdiParent = this,
                    WindowState= FormWindowState.Maximized
                };
                frmJurnalPostuplenij.WindowState = FormWindowState.Maximized;
                frmJurnalPostuplenij.Show();
            }
            else
            {
                frmJurnalPostuplenij.Activate();
            }
        }


        private void btnJurnalPostupl_Click_1(object sender, EventArgs e)
        {
            mnuJurnalPostuplenij_Click_1(null, null);
        }


    }
}
