﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Periods;

namespace MyShop.GARANT
{
    public partial class frmGarant : Form
    {
        DataSet ds = new DataSet();
        DataTable dt;
        BindingSource bs = new BindingSource();
        SQLmodule sql = new SQLmodule();
        const string TableName = "GARANT";
        frmGarantEdit frmEdit;
        frmGarantEdit frmAdd;
        PrintGarant pg;
        DateTime sDT;
        DateTime eDT;
        int infoWidth = 350;

        public frmGarant()
        {
            InitializeComponent();

            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;

            sDT = new DateTime(DateTime.Now.Year - 1, DateTime.Now.Month, DateTime.Now.Day);
            eDT= new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23,59,59);
            DisplayPeriodToNameForm();

        }

        private void DisplayPeriodToNameForm()
        {
            this.Text = "Журнал сервисных обращений (" + sDT.ToShortDateString() + " - " + eDT.ToShortDateString()+")";
        }

        private void FrmAdd_IsAdded()
        {
            RefreshTable();
            bs.Position = bs.Count + 1;
            bs.Filter = null;
        }

        private void FrmEdit_IsEdited()
        {
            RefreshTable();

        }

        private void ReadTableGarant()
        {

            string startDate = sql.SQLdateConverter(sDT);

            string endDate = sql.SQLdateConverter(eDT);
            
            sql.SQLselect(string.Format("SELECT * FROM GARANT WHERE Дата BETWEEN '{0}' AND '{1}';", startDate, endDate), ds, TableName);

            dt = ds.Tables[TableName];
            var keys = new DataColumn[1];
            keys[0] = dt.Columns["Код"];
            dt.PrimaryKey = keys;
        }

        private void FrmGarant_Load(object sender, EventArgs e)
        {
            bs.ListChanged += Bs_ListChanged;
            dg1.Paint += Dg1_Paint;
            ReadTableGarant();
            dg1.AutoGenerateColumns = false;
            bs.DataSource = ds;
            bs.DataMember = TableName;
            dg1.DataSource = bs;

            lblMarka.DataBindings.Add(new Binding("Text", bs, "Марка"));
            lblTypeIzd.DataBindings.Add(new Binding("Text", bs, "тип изделия"));
            lblModel.DataBindings.Add(new Binding("Text", bs, "Модель"));
            lblSerialNumber.DataBindings.Add(new Binding("Text", bs, "серийный номер"));
            lblOpisanieNeispr.DataBindings.Add(new Binding("Text", bs, "Неисправность"));
            lblVidDefekt.DataBindings.Add(new Binding("Text", bs, "видимые дефекты"));
            lblKomplekt.DataBindings.Add(new Binding("Text", bs, "Комплектация"));
            lblDataZakl.DataBindings.Add(new Binding("Text", bs, "Дата заключения сервиса"));
            lblTextZakl.DataBindings.Add(new Binding("Text", bs, "Текст заключения сервиса"));
            lblDrugieOtmetki.DataBindings.Add(new Binding("Text", bs, "Другие отметки"));


        }

        private void Dg1_Paint(object sender, PaintEventArgs e)
        {
            MK.Procedures procedures = new MK.Procedures();
            procedures.PaintNullDataString(dg1, e);
        }

        private void Bs_ListChanged(object sender, ListChangedEventArgs e)
        {
            int count=bs.Count;
            lblTotalRow.Text = count.ToString();
            if(count<1)
            {
                btnDelete.Enabled = false;
                btnEdit.Enabled = false;
                btnPrint.Enabled = false;

            }
            else
            {
                btnDelete.Enabled = true;
                btnEdit.Enabled = true;
                btnPrint.Enabled = true;

           }
        }

        private void FrmGarant_Resize(object sender, EventArgs e)
        {
            panel7.Width = this.Width - infoWidth;
            PositionDBnavigator();
            dg1.Refresh();
        }

        private void PositionDBnavigator()
        { 
            panelDBNavigator.Location = new Point((this.Width - panelDBNavigator.Width) / 2, 0);
        }

        //private void PhoneFormatPaint(object sender, PaintEventArgs e)
        //{
        //    string p = null;
        //    try
        //    {
        //        if (lblPhone.Text != null && lblPhone.Text != "")
        //        {
        //            PhoneFormat pf = new PhoneFormat();
        //            int tmp = Convert.ToInt32(lblPhone.Text);
        //            p = pf.PhoneConverter(tmp, null);
        //        }
        //        else
        //        {
        //            p = "(нет записи)";
        //        }
        //    }
        //    catch
        //    {
        //        p = "(неверный формат)";
        //    }
        //    finally
        //    {
        //        e.Graphics.FillRectangle(Brushes.DimGray, e.ClipRectangle);
        //        e.Graphics.DrawString(p, new Font("Segoe UI", 12, FontStyle.Regular), Brushes.White, 0, 0);//Segoe UI Semibold; 12pt; style=Bold 
        //    }
        //}

        private void Dg1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            int ci = dg1.Columns["Phone"].Index;
            if (e.ColumnIndex == ci && e.RowIndex >= 0 && e.Value.ToString().Length > 0)
            {
                MK.Procedures pr = new MK.Procedures();
                long p = long.Parse(pr.OnlyDigits(e.Value.ToString()));
                PhoneFormat pf = new PhoneFormat();
                e.Value = pf.PhoneConverter(p, null);
            }

        }


        private void ApplyFilter()
        {
            if (findText1.TextLenght > 0)
            {
                string txt = findText1.TextBoxFind.Text.ToString();
                //DataRow[] dr = ds.Tables[TableName].Select();
                bs.Filter = "convert([Код], 'System.String') = '" + txt + "' " +
                    "OR [ФИО] Like '*" + txt + "*' " +
                    "OR [Адрес прописки] Like '*" + txt + "*' " +
                    "OR convert([Дата], 'System.String') Like '*" + txt + "*' " +
                    "OR convert([телефон], 'System.String') Like '*" + txt + "*' " +
                    "OR [серийный номер] Like '*" + txt + "*' ";
            }
            else
            {
                bs.Filter = null;
            }

        }


        private void BtnAdd_Click(object sender, EventArgs e)
        {
            AddNewRow();
        }

        private void AddNewRow()
        {
            if (frmAdd == null || frmAdd.IsDisposed)
            {
                frmAdd = new frmGarantEdit();
                frmAdd.IsAdded += FrmAdd_IsAdded;
                frmAdd.Text = "Гарантия (новая запись)";
                frmAdd.MdiParent = Global.mainForm;
                frmAdd.Show();
            }
            else
            {
                frmAdd.Activate();
            }
        }


        private void BtnEdit_Click(object sender, EventArgs e)
        {
            EditCurrentRow();
        }

        private void Dg1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dg1.CurrentCellAddress.X>=0 & dg1.CurrentCellAddress.Y>=0)
            {
                EditCurrentRow();
            }

        }

        private int GetCurrentID()
        {
            int id = 0;
            DataRow dr = currentRow;
            id = Convert.ToInt32(dr["Код"]);
            return id;
        }

        private DataRow currentRow
        {
            get
            {
                int position = this.BindingContext[bs].Position;
                if (position > -1)
                {
                    return ((DataRowView)bs.Current).Row;
                }
                else
                {
                    return null;
                }
            }
        }

        private void EditCurrentRow()
        {

            if (frmEdit == null || frmEdit.IsDisposed)
            {
                frmEdit = new frmGarantEdit(GetCurrentID(), dt);
                frmEdit.IsEdited += FrmEdit_IsEdited;
                frmEdit.Text = "Гарантия (редактирование записи)";
                frmEdit.MdiParent = Global.mainForm;
                frmEdit.Show();
            }
            else
            {
                frmEdit.Activate();
            }
        }


        private void RefreshTable()
        {
             Cursor = Cursors.WaitCursor;
             int curPos = bs.Position;
             ds.Tables[TableName].Clear();
             ReadTableGarant();
             bs.Position = curPos;
             Cursor = Cursors.Default;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DeleteRow();
        }

        private void DeleteRow()
        {
            DialogResult result;

            result = MessageBox.Show("Удалить выбранную запись?", "Гарантия", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(result==DialogResult.Yes)
            {
                sql.DeleteRow("DELETE FROM [" + TableName + "] WHERE [Код]=" + GetCurrentID()); 
                RefreshTable();
            }
        }


        private void Dg1_KeyUp(object sender, KeyEventArgs e)
        {
            switch(e.KeyData)
            {
                case Keys.Insert:
                    AddNewRow();
                    break;
                case Keys.F2:
                    EditCurrentRow();
                    break;
                case Keys.Delete:
                    DeleteRow();
                    break;
                case Keys.F3:
                    RefreshTable();
                    ShowMessageUpdate();
                    break;
                case Keys.Control|Keys.P:
                    Print();
                    break;
                case Keys.Control | Keys.F:
                    findText1.Focus();
                    break;
                default:
                    break;
            }    
        }


        private void ShowMessageUpdate()
        {
            MAGAZIN.frmInfoSales frm = new MAGAZIN.frmInfoSales();
            frm.ShowAlert("Обновление произведено успешно", "Список сервисных обращений", MAGAZIN.frmInfoSales.EnmType.Success);
            //MessageBox.Show("Данные обновлены успешно", "Гарантия", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void НоваяЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewRow();
        }

        private void ИзменитьЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditCurrentRow();
        }

        private void УдалитьЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteRow();
        }

        private void ОбновитьТаблицуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RefreshTable();
            ShowMessageUpdate();
        }

        private void ПечатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            RefreshTable();
            ShowMessageUpdate();
        }


        private void Print()
        {
            if (dg1.Rows.Count > 0)
            {

                DataRow dr;
                dr = ds.Tables[TableName].Rows.Find(dg1.CurrentRow.Cells["ID"].Value);

                pg = new PrintGarant(dr);

                FrmPrintPreview frm = new FrmPrintPreview(pg)
                {
                    MdiParent = Global.mainForm
                };
                frm.Show();

            }
        }

        private void BtnPeriod_Click(object sender, EventArgs e)
        {
            SelectPeriod selectPeriod = new SelectPeriod(sDT, eDT);
            if(selectPeriod.ShowDialog()==DialogResult.OK)
            {
                sDT = selectPeriod.DateStart;
                eDT = selectPeriod.DateEnd;
                RefreshTable();
                DisplayPeriodToNameForm();
            }
        }

        private void splitter1_SplitterMoving(object sender, SplitterEventArgs e)
        {
            //infoWidth = panel8.Width;
        }

        private void findText1_FindTextChanged_1(object sender, EventArgs e)
        {
            if (findText1.TextLenght == 0)
            {
                bs.Filter = null;
            }
        }

        private void findText1_FindKeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ApplyFilter();
                e.Handled = true;
            }
        }

        private void findText1_FindClick_1(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            findText1.TextClear();
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
