﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MK;

namespace MyShop.GARANT
{
    public partial class frmGarantEdit : Form
    {

        public delegate void TableEdit();
        public event TableEdit IsEdited;
        public event TableEdit IsAdded;

        DataTable dt;
        int ID;
        SQLmodule sql = new SQLmodule();

        public frmGarantEdit(int kod, DataTable dataTable)
        {
            InitializeComponent();

            btnSave.TextAlign = ContentAlignment.MiddleCenter;
            btnCancel.TextAlign = ContentAlignment.MiddleCenter;

            dt = dataTable;
            ID = kod;

            if (kod>0)
            {
                //назначаем строки
                InitStringDataRow(ID);
            }
        }

        public frmGarantEdit()
        {
            InitializeComponent();

            btnSave.TextAlign = ContentAlignment.MiddleCenter;
            btnCancel.TextAlign = ContentAlignment.MiddleCenter;
            ID = 0;
        }

        private void InitStringDataRow(int ID)
        {
            DataRow dr;
            dr = dt.Rows.Find(ID);
            lblKod.Text = dr["Код"].ToString();
            lblDate.Text = dr["Дата"].ToString();
            txtFIO.Text = dr["ФИО"].ToString();
            txtAddress.Text = dr["Адрес прописки"].ToString();
            txtPassport.Text = dr["Паспорт"].ToString();
            txtTypeIzd.Text = dr["тип изделия"].ToString();
            txtMarka.Text = dr["Марка"].ToString();
            txtModel.Text = dr["Модель"].ToString();
            txtSerialNumber.Text = dr["серийный номер"].ToString();
            txtOpisanieNeispr.Text = dr["Неисправность"].ToString();
            txtVidDefekt.Text = dr["видимые дефекты"].ToString();
            txtKomplekt.Text = dr["Комплектация"].ToString();
            txtServiceDate.Text = dr["Дата заключения сервиса"].ToString();
            txtTextZakl.Text = dr["Текст заключения сервиса"].ToString();
            txtDrugieOtmetki.Text = dr["Другие отметки"].ToString();
            maskedTextPhone.Text =dr["телефон"].ToString();

        }

        private void frmGarantEdit_Resize(object sender, EventArgs e)
        {
            CenterDBpanelNavigation();
        }

        private void frmGarantEdit_Load(object sender, EventArgs e)
        {
            CenterDBpanelNavigation();
        }

        private void CenterDBpanelNavigation()
        {
            panelDBNavigation.Location = new Point((this.Width - panelDBNavigation.Width) / 2, 0);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ID == 0)
            {
                NewString();
            }
            else
            {
                UpdateString();
            }

            this.Close();
        }

        private void NewString()
        {
            Cursor = Cursors.WaitCursor;

            string SQLstr = SQLstringInsert();
            sql.InsertRow(SQLstr);
            if(IsAdded!=null) { IsAdded(); }

            Cursor = Cursors.Default;
            
        }

        private string SQLstringInsert()
        {
            int id= sql.NewID("GARANT", "Код");
            string str = null;
            Procedures pr = new Procedures();
            string phone = pr.OnlyDigits(maskedTextPhone.Text);

            str = string.Format("INSERT INTO [GARANT] ([Код], [Дата], [ФИО], [Адрес прописки], [Паспорт], [тип изделия], [Марка], [Модель], [серийный номер], " +
                "[Неисправность], [видимые дефекты], [Комплектация], [Дата заключения сервиса], [Текст заключения сервиса], [Другие отметки], [телефон]) " +
                "VALUES ({0}, '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}');", id, DateTime.Now.ToString(), txtFIO.Text, txtAddress.Text, txtPassport.Text, txtTypeIzd.Text, txtMarka.Text, txtModel.Text, txtSerialNumber.Text, txtOpisanieNeispr.Text, txtVidDefekt.Text, txtKomplekt.Text, txtServiceDate.Text, txtTextZakl.Text, txtDrugieOtmetki.Text, phone);
            return str;
        }

        private void UpdateString()
        {
            Cursor = Cursors.WaitCursor;
            Procedures pr = new Procedures();
            string phone = pr.OnlyDigits(maskedTextPhone.Text);
            string SQLupd = string.Format("UPDATE [GARANT] SET "+
                "[ФИО]='{0}', "+
                "[Адрес прописки]='{1}', "+
                "[Паспорт]='{2}', "+
                "[тип изделия]='{3}', " +
                "[Марка]='{4}', " +
                "[Модель]='{5}', " +
                "[серийный номер]='{6}', " +
                "[Неисправность]='{7}', " +
                "[видимые дефекты]='{8}', " +
                "[Комплектация]='{9}', " +
                "[Дата заключения сервиса]='{10}', " +
                "[Текст заключения сервиса]='{11}', " +
                "[Другие отметки]='{12}', " +
                "[телефон]='{13}' "+
                "WHERE [Код]={14};", txtFIO.Text, txtAddress.Text, txtPassport.Text, txtTypeIzd.Text, txtMarka.Text, txtModel.Text, txtSerialNumber.Text, txtOpisanieNeispr.Text, txtVidDefekt.Text, txtKomplekt.Text, txtServiceDate.Text, txtTextZakl.Text, txtDrugieOtmetki.Text, phone, lblKod.Text);

            sql.UpdateRow(SQLupd);

            if (IsEdited != null) { IsEdited();}

            Cursor = Cursors.Default;
        }

    }
}
