﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Drawing;

namespace MyShop.GARANT
{
    public partial class PrintGarant : System.Drawing.Printing.PrintDocument
    {
        Rekvizits r = new Rekvizits();
        DataRow _dr;
        PhoneFormat pf = new PhoneFormat();

        public PrintGarant(DataRow dr)
        {
            _dr = dr;

            InitializeComponent();

            r.Load();

            this.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintGarant_PrintPage);
        }

        private string ClientPhone(DataRow dr)
        {
            MK.Procedures mkp = new MK.Procedures();
            string ph = null;
            //try
            //{
                ph = mkp.OnlyDigits(dr["телефон"].ToString());
            if(ph!=null & ph!="")
            {
                long iph = long.Parse(ph);
                ph = pf.PhoneConverter(iph, null);
            }
            else
            {
                ph = "(нет данных)";
            }
            //}
            //catch
            //{
            //    throw new Exception("Неверный формат строки");
            //}
            return ph;
        }

        public PrintGarant(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        private void PrintGarant_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //posX- левая граница, posY - верхняя граница
            int posX = 60, posY = 50;

            Font fontTitleBold = new Font("Arial", 10, FontStyle.Bold);
            Font fontText = new Font("Arial", 9, FontStyle.Regular);
            Font fontTitleMain = new Font("Arial", 14, FontStyle.Bold);
            Font fontTextI = new Font("Arial", 9, FontStyle.Italic);

            e.Graphics.DrawString("№ " + _dr["Код"].ToString()+"-"+_dr["Дата"].ToString(), fontTitleMain, Brushes.Black, posX, posY);

            e.Graphics.DrawString(r.Name, fontTitleBold, Brushes.Black, posX+400, posY);
            posY += 22;
            e.Graphics.DrawString("УНП: " + r.UNP, fontText, Brushes.Black, posX+400, posY);
            posY += 17;
            e.Graphics.DrawString(r.Adres, fontText, Brushes.Black, posX+400, posY);
            posY += 17;
            e.Graphics.DrawString("тел./факс: " + r.Phone, fontText, Brushes.Black, posX+400, posY);
            posY += 17;
            e.Graphics.DrawString("E-mail: " + r.e_mail, fontText, Brushes.Black, posX+400, posY);
            posY += 17;
            e.Graphics.DrawString("Директору ", fontText, Brushes.Black, posX + 400, posY);
            posY += 60;

            e.Graphics.DrawString("Я, " , fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString( _dr["ФИО"].ToString(), fontTitleBold, Brushes.Black, posX+20, posY);
            posY += 20;
            e.Graphics.DrawString("проживающий(ая) по адресу: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["Адрес прописки"].ToString(), fontTitleBold, Brushes.Black, posX + 180, posY);
            posY += 20;
            e.Graphics.DrawString("паспорт: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["паспорт"].ToString(), fontTitleBold, Brushes.Black, posX + 70, posY);
            posY += 20;
            e.Graphics.DrawString("контактный телефон: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(ClientPhone(_dr), fontTitleBold, Brushes.Black, posX + 140, posY);
            posY += 20;
            e.Graphics.DrawString("прошу доставить в сервисную мастерскую для ремонта и/или технического обслуживания предоставленное мною изделие: ", fontText, Brushes.Black, posX, posY);
            posY += 20;
            e.Graphics.DrawString("тип: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["тип изделия"].ToString(), fontTitleBold, Brushes.Black, posX+40, posY);
            posY += 20;
            e.Graphics.DrawString("марка: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["Марка"].ToString(), fontTitleBold, Brushes.Black, posX+50, posY);
            posY += 20;
            e.Graphics.DrawString("модель: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["Модель"].ToString(), fontTitleBold, Brushes.Black, posX + 60, posY);
            posY += 20;
            e.Graphics.DrawString("серийный номер изделия: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["серийный номер"].ToString(), fontTitleBold, Brushes.Black, posX + 170, posY);
            posY += 20;
            e.Graphics.DrawString("Причина обращения: ", fontText, Brushes.Black, posX, posY);
            RectangleF txtF = new RectangleF(posX + 140, posY, 560, 50);
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240, 240, 240)), txtF);
            e.Graphics.DrawString(_dr["неисправность"].ToString(), fontTextI, Brushes.Black, txtF);
            posY += 55;
            e.Graphics.DrawString("Видимые дефекты: ", fontText, Brushes.Black, posX, posY);
            txtF = new RectangleF(posX + 140, posY, 560, 50);
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240, 240, 240)), txtF);
            e.Graphics.DrawString(_dr["видимые дефекты"].ToString(), fontTextI, Brushes.Black, txtF);
            posY += 55;
            e.Graphics.DrawString("Комплектация: ", fontText, Brushes.Black, posX, posY);
            txtF = new RectangleF(posX + 140, posY, 560, 33);
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240, 240, 240)), txtF);
            e.Graphics.DrawString(_dr["Комплектация"].ToString(), fontTextI, Brushes.Black, txtF);
            posY += 45;
            txtF = new RectangleF(posX, posY, 700, 33);
            string txtPret = "        Претензий по целостности, сохранности, функциональности, по срокам доставки и возврата из сервисной мастерской данного изделия к " + r.Name + " не имею.";
            e.Graphics.DrawString(txtPret, fontText, Brushes.Black, txtF);
            posY += 100;
            e.Graphics.DrawString("\"____\"_________________________20___г.", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString("______________________________________", fontText, Brushes.Black, posX+400, posY);
            posY += 16;
            e.Graphics.DrawString("дата", fontTextI, Brushes.Black, posX+100, posY);
            e.Graphics.DrawString("подпись", fontTextI, Brushes.Black, posX + 500, posY);
            posY += 50;

            e.Graphics.DrawString("М.П.", fontText, Brushes.Gray, posX + 330, posY-20);
            e.Graphics.DrawLine(new Pen(Brushes.LightGray, 1), posX, posY, 700 + e.MarginBounds.Left, posY);
            posY += 50;
            //-----------------------------------------------------------------------------------------------------------------------------------


            e.Graphics.DrawString("№ " + _dr["Код"].ToString() + "-" + _dr["Дата"].ToString(), fontTitleMain, Brushes.Black, posX, posY);

            e.Graphics.DrawString(r.Name, fontTitleBold, Brushes.Black, posX + 400, posY);
            posY += 22;
            e.Graphics.DrawString("тел./факс: " + r.Phone, fontText, Brushes.Black, posX + 400, posY);
            posY += 17;
            e.Graphics.DrawString(r.Adres, fontText, Brushes.Black, posX + 400, posY);
            posY += 17;
            e.Graphics.DrawString("УНП: " + r.UNP, fontText, Brushes.Black, posX + 400, posY);
            posY += 17;
            e.Graphics.DrawString("E-mail: " + r.e_mail, fontText, Brushes.Black, posX + 400, posY);
            posY += 30;

            e.Graphics.DrawString(_dr["ФИО"].ToString(), fontTitleBold, Brushes.Black, posX, posY);
            posY += 20;
            e.Graphics.DrawString(_dr["тип изделия"].ToString(), fontTitleBold, Brushes.Black, posX, posY);
            posY += 20;
            e.Graphics.DrawString("марка: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["Марка"].ToString(), fontTitleBold, Brushes.Black, posX + 50, posY);
            posY += 20;
            e.Graphics.DrawString("модель: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["Модель"].ToString(), fontTitleBold, Brushes.Black, posX + 60, posY);
            posY += 20;
            e.Graphics.DrawString("серийный номер изделия: ", fontText, Brushes.Black, posX, posY);
            e.Graphics.DrawString(_dr["серийный номер"].ToString(), fontTitleBold, Brushes.Black, posX + 170, posY);
            posY += 20;
            e.Graphics.DrawString("Комплектация: ", fontText, Brushes.Black, posX, posY);
            txtF = new RectangleF(posX + 140, posY, 560, 33);
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(240, 240, 240)), txtF);
            e.Graphics.DrawString(_dr["Комплектация"].ToString(), fontTextI, Brushes.Black, txtF);
            posY += 45;
            txtF = new RectangleF(posX, posY, 700, 33);
            e.Graphics.DrawString(txtPret, fontText, Brushes.Black, txtF);
            posY += 70;
            e.Graphics.DrawString("______________________________________", fontText, Brushes.Black, posX + 400, posY);
            posY += 16;
            e.Graphics.DrawString("подпись", fontTextI, Brushes.Black, posX + 500, posY);
        }
    }
}
