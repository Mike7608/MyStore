﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace MyShop
{
    class Rekvizits
    {
        public string Name;
        public string UNP;
        public string Adres;
        public string Phone;
        //public string NameBank;
        //public string R_schet;
        public string Director_FIO;
        public string GlavBuh_FIO;
        public string e_mail;
        public double StavkaNDS;

        DataSet ds = new DataSet();
        Settings set = new Settings();

        string SQlconnect;
        public Rekvizits()
        {
            SQlconnect = set.SQLconnectionString;

        }
        public void Load()
        {
            using (SqlConnection con = new SqlConnection(SQlconnect))
            {
                con.Open();
                select("D", con);//Наименование организации
                select("I", con);//адрес
                select("H", con);//УНП
                select("J", con);//телефоны
                //select("Y", con);//расчетный счет (код)
                select("168R", con);//e-mail
                select("K", con);//главный бухгалтер (код)
                select("L", con);//руководитель (код)
                select("11", con);//код ставки НДС

                string tmp;
                tmp = Id_rab("K");
                selectFIO(tmp, con);

                tmp = Id_rab("L");
                selectFIO(tmp, con);

                tmp = stringfromData("11");//получаем код ставки НДС
                selectNDS(tmp, con);//получаем ставку НДС

                con.Close();
                con.Dispose();

                Name = stringfromData("D");
                UNP = stringfromData("H");
                Adres = stringfromData("I");
                Phone = stringfromData("J");
                e_mail = stringfromData("168R");
                GlavBuh_FIO = stringfromRab(1);
                Director_FIO = stringfromRab(0);
                StavkaNDS = stavNDS();
            }

            
        }

        private void select(string id, SqlConnection con)
        {
            string sel = string.Format("SELECT id, partno, value from _1SCONST where objid='0' and id='{0}'", id);
            SqlCommand cmd = new SqlCommand(sel, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "main");
        }
    
        private string Id_rab(string id_const)
        {
            string str = null;
            if (ds.Tables["main"].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables["main"].Rows)
                {
                    if (dr["id"].ToString() == id_const.ToString())
                    {
                        str = dr["value"].ToString();
                    }
                }
            }
            return str;
        }

        private string stringfromData(string id)
        {
            string str=null;
            if (ds.Tables["main"].Rows.Count>0)
            {
                foreach(DataRow dr in ds.Tables["main"].Rows)
                {
                    if(dr["id"].ToString()==id.ToString())
                    {
                        str += dr["value"].ToString();
                    }
                }
            }
            return str;
        }

        private void selectFIO(string id, SqlConnection con)
        {
            string sel = string.Format("SELECT descr from _SC208 where id='{0}'", id);
            SqlCommand cmd = new SqlCommand(sel, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "rab");
        }


        private void selectNDS(string id, SqlConnection con)
        {
            string sel = string.Format("SELECT sp209 from _SC211 where id='{0}'", id);
            SqlCommand cmd = new SqlCommand(sel, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "NDS");
        }

        private double stavNDS()
        {
            double stavka=0;
            if(ds.Tables["NDS"].Rows.Count>0)
            {
                DataRow dr;
                dr = ds.Tables["NDS"].Rows[0];
                stavka =Convert.ToDouble(dr["sp209"]);
            }
            return stavka;
        }

        private string stringfromRab(int NumberID)
        {
            string str = null;
            if(ds.Tables["rab"].Rows.Count>0)
            {
                DataRow dr;
                dr = ds.Tables["rab"].Rows[NumberID];
                str = dr["descr"].ToString();
            }
            return str;
        }

    }
}
