﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyShop.GARANT
{
    /// <summary>
    /// Логика взаимодействия для ListGarant.xaml
    /// </summary>
    public partial class ListGarant : UserControl
    {

        public DataTable DataTable;

        public ListGarant()
        {
            InitializeComponent();



            //List<Contact> contacts = new List<Contact>()
            //{
            //    new Contact()
            //    {
            //        ID=1234,
            //        FIO="Кушнер Михаил Николаевич",
            //        Date=DateTime.Now,
            //        Address="г.Березино, ул.Октябрьская, 16",
            //        Phone="+375 33 63-65-391"

            //    },
            //    new Contact()
            //    {
            //        ID=2,
            //        FIO="Kushner Mike",
            //        Date=DateTime.Now,
            //        Address="г.Березино, ул.Октябрьская, 16",
            //        Phone="+375 33 63-65-391"
            //    }
            //};


            //**************************************************************************************
            //DataColumn colID = new DataColumn("ID");
            //DataColumn colFIO = new DataColumn("FIO");
            //DataColumn colDate = new DataColumn("Date");
            //DataColumn colAddress = new DataColumn("Address");
            //DataColumn colPhone = new DataColumn("Phone");
            //dt.Columns.Add(colID);
            //dt.Columns.Add(colFIO);
            //dt.Columns.Add(colDate);
            //dt.Columns.Add(colAddress);
            //dt.Columns.Add(colPhone);

            //DataRow dr = dt.NewRow();
            //dr["ID"] = 111;
            //dr["FIO"] = "Кушнер Михаил Николаевич";
            //dr["Date"] = DateTime.Now.ToString();
            //dr["Address"] = "г.Березино, ул.Октябрьская, 16";
            //dr["Phone"] = "375336365391";
            //dt.Rows.Add(dr);
            //**************************************************************************************


        }
        public void ShowData(DataTable dt)
        {
            DataTable = dt;
            this.LisBoxNames.ItemsSource = DataTable.DefaultView;
        }
    }

    //public class Contact
    //{
    //    public int ID { get; set; }
    //    public string FIO { get; set; }
    //    public DateTime Date { get; set; }
    //    public string Address { get; set; }
    //    public string Phone { get; set; }
    //}
}
