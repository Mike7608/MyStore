﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Odbc;
using System.Threading;

namespace MyShop
{
    class InfoTovarForm1S
    {
        //NEW.MySetting myset = new NEW.MySetting();
        //NEW.DBFreader dbf = new NEW.DBFreader();
        public DataSet dsDATA = new DataSet();
        OdbcConnection conn;

        #region "Свойства"
        public string idtov { set; get; }
        public string parentid { set; get; }
        public string code { set; get; }
        public string NameTovar { set; get; }
        public string FullNameTovar { set; get; }
        public Double CenaNonNDS { set; get; }
        public string CountryMade { set; get; }
        public string CenaRealizacii { set; get; }
        public string EdIzm { set; get; }
        public string Pack { set; get; }
        public string Description { set; get; }
        public string SCODE { set; get; }
        #endregion

        int cpDBF;
        int cpOS;

        public InfoTovarForm1S()
        {
            cpDBF = Convert.ToInt32(myset.DBFCodePage);
            cpOS = Convert.ToInt32(myset.OSCodePage);
        }

        public void Find(string idtov2)
        {
            OdbcDataAdapter da = new OdbcDataAdapter();
                
            idtov = idtov2; //idtov

            Thread t = new Thread(ReadInfoTovarFromMDB);
            t.Start();

            using (conn = new OdbcConnection(myset.DBFConnString+myset.DBFpath))
            {
                conn.Open();


                DataSet dsTemp = new DataSet();

                //загружаем нужный товар
                OdbcCommand cmdSel = new OdbcCommand(string.Format("SELECT id, parentid, code, descr as Name,  sp141 as cena0, sp148 as idcountry, sp140 as edIzm, sp48410 as idTara from SC156 where id='{0}'", idtov2), conn);
                da.SelectCommand = cmdSel;
                da.Fill(dsTemp, "Tovar");

                

                DataRow dr;
                dr = dsTemp.Tables["Tovar"].Rows[0];
                string idCountry1 = dr["idcountry"].ToString();


                parentid = dr["parentid"].ToString(); //parentid - код группы
                code = dr["code"].ToString(); // код товара
                NameTovar = ConvertCodePage(dr["Name"].ToString()); // наименование товара
                CenaNonNDS = Convert.ToDouble(dr["cena0"]); // цена товара без НДС и торговой надбавки


                //получаем нужную страну
                OdbcCommand cmd = new OdbcCommand(string.Format("SELECT descr from SC27082 where id='{0}'", idCountry1), conn);
                OdbcDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        CountryMade = ConvertCodePage(reader.GetValue(0).ToString());
                    }
                    reader.Close();
                }

                EdIzm = ConvertCodePage(EdinIzm(dr["edIzm"].ToString()));//Единица измерения
                Pack = ConvertCodePage(EdinIzm(dr["idTara"].ToString()));// тип упаковки

                OdbcCommand cmdTEMP = new OdbcCommand(string.Format("SELECT iddoc from DT11188 where sp11179='{0}'", idtov2), conn);
                da.SelectCommand = cmdTEMP;
                da.Fill(dsTemp, "TEMP");

                OdbcCommand cmdTN;

                // получаем список ТН по товару
                foreach (DataRow drTMP in dsTemp.Tables["TEMP"].Rows)
                {
                    string idTN = drTMP["iddoc"].ToString();
                    cmdTN = new OdbcCommand(string.Format("SELECT [DH11188.iddoc], [DH11188.sp27331] as data, [DH11188.sp11172] as idPost, [DH11188.sp27330] as NomerTN, [SC133.descr] as NamePost from DH11188 inner join SC133 on DH11188.sp11172=SC133.id where [DH11188.iddoc]='{0}'", idTN), conn);
                    da.SelectCommand = cmdTN;
                    da.Fill(dsDATA, "TN");
                }
                if(dsDATA.Tables.Contains("TN"))
                {
                    dbf.ConvertColumn(dsDATA.Tables["TN"].TableName, dsDATA, "NamePost");
                }


                //получаем все цены по товару
                OdbcCommand cmdCeny = new OdbcCommand(string.Format("SELECT DT48386.iddoc, DT48386.sp48380 as idtov, DT48386.sp48384 as CenaR, DT48386.sp53404 as Cena0, DH48386.sp48376 as data  from DT48386 inner join DH48386 on DT48386.iddoc=DH48386.iddoc where DT48386.sp48380='{0}'", idtov2), conn);
                da.SelectCommand = cmdCeny;
                da.Fill(dsDATA, "Ceny");

                OdbcCommand cmdConst = new OdbcCommand(string.Format("SELECT TOP 1 [1SCONST].VALUE FROM SC40814 INNER JOIN 1SCONST ON SC40814.ID = [1SCONST].OBJID WHERE [1SCONST].ID = ' VHM'  AND SC40814.parentext = '{0}' ORDER BY [1SCONST].DATE DESC; ", idtov2), conn);
                OdbcDataReader readerConst = cmdConst.ExecuteReader();
                if (readerConst.HasRows)
                {
                    while (readerConst.Read())
                    {
                        CenaRealizacii =readerConst.GetValue(0).ToString().Trim();
                    }
                    readerConst.Close();
                }

                // BLOB - полное наименование товара
                OdbcCommand cmdBLOB = new OdbcCommand(string.Format("SELECT fieldid, objid, blockno, block from 1SBLOB where fieldid='  3U' and objid='{0}'", idtov2), conn);
                da.SelectCommand = cmdBLOB;
                da.Fill(dsTemp, "BLOB");
                dbf.ConvertColumn(dsTemp.Tables["BLOB"].TableName, dsTemp, "block");
                FullNameTovar = BLOBstringDS("  3U", dsTemp.Tables["BLOB"]);

                conn.Close();
                conn.Dispose();
            }
            
        }

        private string ConvertCodePage(string str)
        {

           return dbf.ConvertCP(str, cpDBF, cpOS);
        }

        private string EdinIzm(string id)
        {

            string str0 = null;
            OdbcCommand cmd = new OdbcCommand(string.Format("SELECT descr from SC116 where id='{0}'", id), conn);
            OdbcDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    str0 = reader.GetValue(0).ToString();
                }
                reader.Close();
            }
            return str0;
        }


        /// <summary>
        /// функция возвращает строку из таблицы 1SBLOB
        /// </summary>
        /// <param name="FieldId">Идентификатор записи</param>
        /// <param name="ObjId">Код объекта/param>
        /// <returns></returns>
        private string BLOBstringDS(string FieldId, DataTable dt)
        {


            string val = null;

            if (dt.Rows.Count > 0)
            {
                try
                {
                    DataRow dr0 = dt.Rows[0];
                    string Lenstr;
                    Lenstr = dr0["block"].ToString().Substring(0, 9);
                    int iLen = HEXtoInt(Lenstr.Trim());
                    int x = 0;
                    foreach (DataRow dr in dt.Rows)
                    {
                        int y = Convert.ToInt32(dr["blockno"]);
                        if (y == x)
                        {
                            val += dr["block"].ToString();
                            x++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    val = val.Substring(9, iLen);
                }
                catch
                {
                    val = null;
                }


            }

            return val;
        }

        /// <summary>
        /// Функция конвертирует HEX значение в целое число
        /// </summary>
        /// <param name="Hex"></param>
        /// <returns></returns>
        private int HEXtoInt(string Hex)
        {
            int iLen;
            if (int.TryParse(Hex, System.Globalization.NumberStyles.HexNumber, null, out iLen))
            {

            }
            return iLen;
        }

        private void ReadInfoTovarFromMDB()
        {

            OdbcDataReader descr;
            string str = null;
            using (OdbcConnection connSQL = new OdbcConnection(myset.MainDBconnString + myset.MainDBpath))
            {
                connSQL.Open();
                OdbcCommand cmd = new OdbcCommand(string.Format("SELECT SCODE, descr from CODES WHERE idtov='{0}'", idtov), connSQL);
                descr = cmd.ExecuteReader();
                while (descr.Read())
                {
                    SCODE = descr["SCODE"].ToString();
                    Description = descr["descr"].ToString();
                }
                connSQL.Close();
            }

        }


    }
}
