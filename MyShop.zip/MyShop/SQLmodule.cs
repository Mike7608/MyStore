﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace MyShop
{
    class SQLmodule
    {
        #region === ПЕРЕМЕННЫЕ ===

        /// <summary>
        /// Строка подключения к SQL серверу
        /// </summary>
        public readonly string Connection;

        Settings set = new Settings();

        #endregion

        /// <summary>
        /// Модуль для работы с базой даннх SQLclient
        /// </summary>
        public SQLmodule()
        {
            Connection = set.SQLconnectionString;
        }

        /// <summary>
        /// Функция конвертирует дату в строковую дату для SQL выражения
        /// </summary>
        /// <param name="date">Дата в формате DateTime</param>
        /// <returns></returns>
        public string SQLdateConverter(DateTime date)
        {
            return date.ToString().Replace('.', '/');
        }

        /// <summary>
        /// Процедура получения записей по заданному значению
        /// </summary>
        /// <param name="SQLsel">SQL выражение</param>
        /// <param name="ds">DataSet</param>
        /// <param name="TableName">Наименование таблицы в DataSet</param>
        public void SQLselect(string SQLsel, DataSet ds, string TableName)
        {
            using (SqlConnection con = new SqlConnection(Connection))
            {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(SQLsel, con);            //SELECT * FROM GARANT WHERE Дата BETWEEN '01/01/2020' AND '24/11/2020';
            da.Fill(ds, TableName);
            con.Close();
            }
        }

        /// <summary>
        /// Процедура очищает таблицу от всех данных
        /// </summary>
        /// <param name="NameTable"></param>
        public void ClearTable(string NameTable)
        {
            using(SqlConnection con= new SqlConnection(Connection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM [" + NameTable + "]", con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public void SQLselect(string SQLsel, DataTable dt)
        {
            using(SqlConnection con= new SqlConnection(Connection))
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(SQLsel, con);
                da.Fill(dt);
                con.Close();
            }
        }

        /// <summary>
        /// Функция получает порядковый номер для новой строки
        /// </summary>
        /// <param name="NameTable">Название таблицы для которой проводится процедура</param>
        /// <param name="ColumnName">Название колонки с ключевым полем</param>
        /// <returns></returns>
        public int NewID(string NameTable, string ColumnName)
        {
            int ID;
            using(SqlConnection con=new SqlConnection(Connection))
            {
                try
                {
                    con.Open();
                    string SQLstr= string.Format("SELECT MAX([{0}]) FROM [{1}];", ColumnName, NameTable);
                    SqlCommand cmd = new SqlCommand(SQLstr, con);               
                    ID = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();
                }
                catch
                {
                    ID = 0;
                }
            }
            ID++;
            return ID;
        }

        /// <summary>
        /// Процедура вставки новой строки в базу данных SQL
        /// </summary>
        /// <param name="SQL"></param>
        public void InsertRow(string SQL)
        {
            using (SqlConnection con = new SqlConnection(Connection))
            {
                con.Open();
                SqlCommand cmdSQ = new SqlCommand(SQL, con);
                SqlDataReader dr1 = cmdSQ.ExecuteReader();
                con.Close();
            }
        }

        /// <summary>
        /// Процедура обновления строки в базе данных SQL
        /// </summary>
        /// <param name="SQL"></param>
        public void UpdateRow(string SQL)
        {
            InsertRow(SQL);
        }

        /// <summary>
        /// Процедура удаления строки в базе данных SQL
        /// </summary>
        /// <param name="SQL"></param>
        public void DeleteRow(string SQL)
        {
            InsertRow(SQL);
        }

        /// <summary>
        /// Процедура проверяет наличие таблицы в базе данных SQL
        /// </summary>
        /// <param name="dt">Таблица DataTable</param>
        /// <returns></returns>
        public bool IsExistingTable(DataTable dt)
        {
            bool tmp = false;
            SqlDataReader reader;

            using (SqlConnection connection = new SqlConnection(Connection))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(string.Format("SELECT OBJECT_ID(N'[dbo].[{0}]', N'U')", dt.TableName), connection);
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    if (!string.IsNullOrEmpty(reader.GetValue(0).ToString()))
                    { tmp = true; }
                }
                connection.Close();
            }

            return tmp;
        }
        /// <summary>
        /// Процедура проверяет наличие таблицы в базе данных SQL
        /// </summary>
        /// <param name="NameTable">Наименование таблицы SQL базы данных</param>
        /// <returns></returns>
        public bool IsExistingTable(string NameTable)
        {
            bool tmp = false;
            SqlDataReader reader;

            using (SqlConnection connection = new SqlConnection(Connection))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(string.Format("SELECT OBJECT_ID(N'[dbo].[{0}]', N'U')", NameTable), connection);
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    if (!string.IsNullOrEmpty(reader.GetValue(0).ToString()))
                    { tmp = true; }
                }
                connection.Close();
            }

            return tmp;
        }

        /// <summary>
        /// функция возвращает строку из таблицы 1SBLOB
        /// </summary>
        /// <param name="FieldId">Идентификатор записи</param>
        /// <param name="ObjId">Код объекта/param>
        /// <returns></returns>
        public string BLOBstring(string FieldId, string ObjId)
        {
            DataSet dsBLOB = new DataSet();
            SQLselect("SELECT * FROM _1SBLOB WHERE fieldid='" + FieldId + "' and objid='" + ObjId + "'", dsBLOB, "BLOB");
            string val = null;

            if (dsBLOB.Tables["BLOB"].Rows.Count > 0)
            {
                try
                {
                    //DataRow[] dr1 = dsBLOB.Tables["_1SBLOB"].Select("fieldid='" + FieldId + "' and objid='" + ObjId + "'");

                    string Lenstr;
                    if (dsBLOB.Tables["BLOB"].Rows.Count > 0)
                    { 

                        Lenstr = dsBLOB.Tables["BLOB"].Rows[0]["block"].ToString().Substring(0, 9);
                        int iLen = HEXtoInt(Lenstr.Trim());
                        int x = 0;
                        foreach (DataRow dr in dsBLOB.Tables["BLOB"].Rows)
                        {
                            int y = Convert.ToInt32(dr["blockno"]);
                            if (y == x)
                            {
                                val += dr["block"].ToString();
                                x++;
                            }
                            else
                            {
                                break;
                            }
                        }

                        val = val.Substring(9, iLen);

                    }
                }
                catch
                {
                    val = null;
                }


            }

            return val;
        }

        /// <summary>
        /// Функция конвертирует HEX значение в целое число
        /// </summary>
        /// <param name="Hex"></param>
        /// <returns></returns>
        private int HEXtoInt(string Hex)
        {
            int iLen;
            if (int.TryParse(Hex, System.Globalization.NumberStyles.HexNumber, null, out iLen))
            {

            }
            return iLen;
        }

        /// <summary>
        /// Процедура воборки одного значения
        /// Пример: SELECT Name FROM Table WHERE ID=1
        /// </summary>
        /// <param name="SQLselect"></param>
        /// <returns></returns>
        public object SelectOneValue(string SQLselect)
        {
            object val=null;
            using (SqlConnection con = new SqlConnection(Connection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(SQLselect, con);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        val = reader.GetValue(0).ToString();
                    }
                }
                reader.Close();         
            }
            return val;
        }

        /// <summary>
        /// Процедура устанавливает заданную колонку ключевой
        /// </summary>
        /// <param name="dt">Таблица в которой требуется установить ключевое поле</param>
        /// <param name="dc">Колонка на которую устанавливается ключевое поле</param>
        public void SetPrimaryKey(DataTable dt, DataColumn dc)
        {
            var keys = new DataColumn[1];
            keys[0] = dc;
            dt.PrimaryKey = keys;
        }
    }
}
