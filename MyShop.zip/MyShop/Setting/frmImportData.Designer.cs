﻿
namespace MyShop.Setting
{
    partial class frmImportData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnImport = new System.Windows.Forms.Button();
            this.pgb1 = new System.Windows.Forms.ProgressBar();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.checkFullClearTable = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnImport
            // 
            this.btnImport.Location = new System.Drawing.Point(32, 139);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(94, 28);
            this.btnImport.TabIndex = 0;
            this.btnImport.Text = "Старт";
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // pgb1
            // 
            this.pgb1.Location = new System.Drawing.Point(32, 60);
            this.pgb1.Name = "pgb1";
            this.pgb1.Size = new System.Drawing.Size(535, 23);
            this.pgb1.TabIndex = 1;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(29, 34);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(76, 13);
            this.lblInfo.TabIndex = 2;
            this.lblInfo.Text = "Информация:";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(473, 287);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(94, 28);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "&Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // checkFullClearTable
            // 
            this.checkFullClearTable.AutoSize = true;
            this.checkFullClearTable.Location = new System.Drawing.Point(32, 106);
            this.checkFullClearTable.Name = "checkFullClearTable";
            this.checkFullClearTable.Size = new System.Drawing.Size(222, 17);
            this.checkFullClearTable.TabIndex = 4;
            this.checkFullClearTable.Text = "Полная (чистая) загрузка всех данных";
            this.checkFullClearTable.UseVisualStyleBackColor = true;
            // 
            // frmImportData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 337);
            this.Controls.Add(this.checkFullClearTable);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.pgb1);
            this.Controls.Add(this.btnImport);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmImportData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Импорт данных";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.ProgressBar pgb1;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.CheckBox checkFullClearTable;
    }
}