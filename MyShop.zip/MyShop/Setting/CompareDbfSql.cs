﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyShop.Setting
{
    class CompareDbfSql
    {
        DataSet ds = new DataSet();
        SQLmodule sql = new SQLmodule();
        Settings set = new Settings();
        string DBFcon;
        private int _ID;
        private decimal _summ;
        private DateTime _date;
        private string _name;
        public enum CompareValue
        {
            Yes,
            No,
            NoRecords,
            NoFile
        }
        public CompareDbfSql()
        {
            sql.SQLselect("Select * from ImportsTable", ds, "Imp");
            int x = set.DBFconnectionString.IndexOf("Dbq=");
            DBFcon = set.DBFconnectionString.Substring(x+4);
        }

        public CompareValue Compare(string nameTable)
        {
            var val=CompareValue.NoFile;
            _name = nameTable;
            string path = DBFcon + "\\" + nameTable + ".dbf";
            if (File.Exists(path))
            {
                val = CompareValue.NoRecords;
                FileInfo info = new FileInfo(path);
                _date= info.CreationTime;
                _summ = info.Length;
                _ID = 0;
                DataRow[] dr=ds.Tables["Imp"].Select(string.Format("Name='{0}'", nameTable));
                foreach(DataRow d in dr)
                {
                        DateTime dateTimeSQL = (DateTime)d["Date"];
                        decimal SummSQL = (decimal)d["Summ"];
                        _ID = (int)d["id"];

                        if(dateTimeSQL.ToString()==_date.ToString() && SummSQL.ToString()==_summ.ToString())
                        {
                            val = CompareValue.Yes;
                        }
                        else
                        {
                            val = CompareValue.No;
                        }
                }
            }
            return val;
        }

        public void Update()
        {
            string str = string.Format("UPDATE [ImportsTable] SET Date='{0}', Summ={1} WHERE id={2}", _date, _summ, _ID);
            sql.UpdateRow(str);
        }

        public void Insert()
        {
            string str = string.Format("INSERT INTO [ImportsTable] ([Name], [Date], [Summ]) VALUES ('{0}', '{1}', {2})", _name, _date, _summ);
            sql.InsertRow(str);
        }
    }
}
