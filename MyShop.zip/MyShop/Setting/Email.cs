﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;

namespace MyShop.Setting
{
    class Email
    {
        Settings set = new Settings();

        /// <summary>
        /// [0] - work email address
        /// [1] - work email password
        /// [2] - work email smtp host
        /// [3] - work email smtp port
        /// </summary>
        private readonly string[] WorkEmail;

        /// <summary>
        /// список адресов получателей почты
        /// </summary>
        private readonly string[] toAddress;


        public Email()
        {

            WorkEmail = set.WorkEmail.Split(';');
            foreach(string s in WorkEmail)
            {
                s.Trim();
            }
            toAddress = set.ToAddress.Split(';');
            foreach (string s in toAddress)
            {
                s.Trim();
            }
        }

        /// <summary>
        /// Отправка сообщения на указанный адрес
        /// </summary>
        /// <param name="NameMessage">Тема сообщения</param>
        /// <param name="Message">Текст сообщения</param>
        /// <param name="toAddress">Адрес получателя</param>
        /// <returns></returns>
        public async Task SendEmailReport(string NameMessage, string Message, string toAddress)
        {
            if (WorkEmail.Length == 4)
            {
                MailAddress from = new MailAddress(WorkEmail[0], "My Store");
                MailAddress to = new MailAddress(toAddress);
                MailMessage m = new MailMessage(from, to)
                {
                    Subject = NameMessage,
                    Body = Message
                };
                SmtpClient smtp = new SmtpClient(WorkEmail[2], Convert.ToInt32(WorkEmail[3]))
                {
                    Credentials = new NetworkCredential(WorkEmail[0], WorkEmail[1]),
                    EnableSsl = true
                };
                await smtp.SendMailAsync(m);
            }

        }

        /// <summary>
        ///  Отправка сообщения на почтовые адреса указанные в настройках программы
        /// </summary>
        /// <param name="NameMessage">Тема сообщения</param>
        /// <param name="Message">Текст сообщения</param>
        public void SendEmailsReport(string NameMessage, string Message)
        {
            foreach(string email in toAddress)
            {
                SendEmailReport(NameMessage, Message, email).GetAwaiter();
            }
        }
    }
}
