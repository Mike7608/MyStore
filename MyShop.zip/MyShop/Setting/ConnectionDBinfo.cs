﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;

namespace MyShop.Setting
{
    class ConnectionDBinfo
    {
        /// <summary>
        /// Процедура проверки связи с базой данных 1С бухгалтерия
        /// </summary>
        /// <returns>Возвращает true если связь установлена</returns>
        public bool Test1CBaseConncetion(string str)
        {

            bool TrueConn;

            //Settings set = new Settings();

            System.Data.Odbc.OdbcConnection connDBF=null;
            try
            {
                connDBF = new System.Data.Odbc.OdbcConnection(str);
                connDBF.Open();
                connDBF.Close();
                TrueConn = true;
            }
            catch
            {
                if (connDBF != null) { connDBF.Close(); }
                
                TrueConn = false;

            }

            return TrueConn;
        }
    }
}
