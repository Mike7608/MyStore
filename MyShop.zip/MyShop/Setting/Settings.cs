﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyShop
{


    public class Settings
    {

        //INI ini = new INI(Directory.GetCurrentDirectory() + "\\settings.ini");

        Properties.Settings settings = new Properties.Settings();

        /// <summary>
        /// Путь выгрузки файлов предназначенных для 1С
        /// </summary>
        public string PathSaveDataFor1C
        {
            get
            {
                return settings.PathSaveDataFor1C;
            }
            set
            {
                settings.PathSaveDataFor1C = value;

            }
        }

        /// <summary>
        /// Строка подключения к базе 1С бухгалтерия
        /// </summary>
        public string DBFconnectionString
        {
            get
            {
                //return ini.GetPrivateString("1CBASE", "ConnectionString");
                return settings.BASE_1C_ConnectionString;
            }
            set
            {
                settings.BASE_1C_ConnectionString = value;

            }

        }

        /// <summary>
        /// Строка подключение к базе данных SQL
        /// </summary>
        public string SQLconnectionString
        {
            get
            {
                return settings.Server_ConnectionString;
            }
            set
            {
                settings.Server_ConnectionString = value;

            }

        }

        /// <summary>
        /// Список используемых DBF файлов 1С бухгалтерия
        /// </summary>
        public string[] ListTableDBF
        {
            get
            {
                string tmp = settings.ListTable_1C;
                string[] list = tmp.Split(',');
                int x;
                for (x = 0; x < list.Length; x++)
                {
                    string tmp0 = list[x].Trim();
                    list[x] = tmp0;
                }
                return list;
            }

        }


        /// <summary>
        /// API адрес сервера НБРБ по валютам
        /// </summary>
        public string HttpCurrency
        {
            get
            {
                return settings.CurrencyHttpAddress;
            }
            set
            {
                settings.CurrencyHttpAddress = value;
            }
        }
        /// <summary>
        /// Включаем или отключаем отображение курсов валют
        /// </summary>
        public bool DisplayCurrency
        {
            get
            {
                return settings.DisplayCurrency;
            }
            set
            {
                settings.DisplayCurrency = value;
            }
        }

        public string TypsDisplayCurrency
        {
            get
            {
                return settings.TypsDisplayCurrency;
            }
            set
            {
                settings.TypsDisplayCurrency = value;
            }
        }

        /// <summary>
        /// Индекс ценника (по списку) используемый по умолчанию
        /// </summary>
        public int PriceTagDefault
        {
            get { return settings.DefaultPriceTag; }
            set { settings.DefaultPriceTag = value; }
        }

        /// <summary>
        /// Рабочий электронный адрес
        /// </summary>
        public string WorkEmail
        {
            get
            {
                return settings.WorkEmail;
            }
            set
            {
                settings.WorkEmail = value;
            }
        }

        public float KursPerescheta
        {
            get
            {
                return settings.KursPerescheta;
            }
            set
            {
                settings.KursPerescheta = value;
            }
        }

        /// <summary>
        ///  Список адресов получателей
        /// </summary>
        public string ToAddress
        {
            get
            {
                return settings.ToAddress;

            }
            set
            {
                settings.ToAddress = value;
            }
        }

        /// <summary>
        ///  Рабочий период программы
        /// </summary>
        public DateTime[] WorkPeriod
        {
            get
            {
                string s=settings.WorkPeriod;
                string[] sm = s.Split('-');
                DateTime[] d = new DateTime[sm.Length];
                int x;
                for (x = 0; x < sm.Length; x++)
                {
                    d[x] = DateTime.Parse(sm[x]);
                }

                return d;
            }
            set
            {
                DateTime[] d = value;
                int x;
                string s=null;
                for(x=0;x<d.Length; x++)
                {
                    s += d[x].ToString();
                    if (x < d.Length-1)
                    {
                        s += "-";
                    }
                }

                settings.WorkPeriod = s;

            }
        }

        /// <summary>
        /// Показать/скрыть входную цену в форме МАГАЗИН
        /// </summary>
        public bool ShowMagazinPriceIn
        {
            get
            {
                return settings.ShowMagazinPriceIn;
            }
            set
            {
                settings.ShowMagazinPriceIn = value;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        public bool ShowMagazinPriceReal
        {
            get
            {
                return settings.ShowMagazinPriceReal;
            }
            set
            {
                settings.ShowMagazinPriceReal = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool ShoqMagazinPriceKurs
        {
            get
            {
                return settings.ShoqMagazinPriceKurs;
            }
            set
            {
                settings.ShoqMagazinPriceKurs = value;
            }
        }

        public void Save()
        {
            settings.Save();
        }
    }
}
