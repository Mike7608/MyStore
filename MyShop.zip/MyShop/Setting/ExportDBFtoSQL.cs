﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using WorkDBF;
using System.Data.SqlClient;
using System.IO;
using System.Security.Policy;

namespace MyShop
{
    class ExportDBFtoSQL
    {
        ReadDBF dbf = new ReadDBF();
        string conDBF;
        string conSQL;
        char _sep='|';
        string FileName;

        /// <summary>
        /// Разделитель колонок таблицы
        /// </summary>
        public char Separator
        {
            get
            {
                return _sep;
            }
            set
            {
                _sep = value;
            }
        }
        /// <summary>
        /// Экспорт DBF таблиц в базу данных SQL
        /// </summary>
        /// <param name="ConnectionStringDBF">строка подключения к базе DBF</param>
        /// <param name="ConnectionStringSQL">строка подключение к базе SQL</param>
        public ExportDBFtoSQL(string ConnectionStringDBF, string ConnectionStringSQL)
        {
            conDBF = ConnectionStringDBF;
            conSQL = ConnectionStringSQL;
        }

        /// <summary>
        /// Процедура экспорта DBF таблицы
        /// </summary>
        /// <param name="NameTable">имы DBF таблицы</param>
        public void Export(string NameTable)
        {

            dbf.ConnectionStringDBF = conDBF;
            DataTable dt;


            if (NameTable == "1SBKTTL")
            {
                Settings set = new Settings();
                DateTime[] dateTimes = set.WorkPeriod;
                string data1 = dateTimes[0].Year.ToString() + "/" + dateTimes[0].Month.ToString() + "/" + dateTimes[0].Day.ToString();
                string data2 = dateTimes[1].Year.ToString() + "/" + dateTimes[1].Month.ToString() + "/" + dateTimes[1].Day.ToString();

                dt = dbf.Execute("SELECT * FROM 1SBKTTL where DATE between #" + data1 + "# and #" + data2 + "#", NameTable);
            }
            else
            {
                dt = dbf.GetAll(NameTable);
            }


            if (dt != null)
            {
                SQLmodule sql = new SQLmodule();
                //удаляем таблицу если она присутствуетв в базе SQL
                if (sql.IsExistingTable(dt))
                {
                    DeleteTable(dt);
                }

                //создаем пустую таблицу
                CreateTable(dt);
                //создаем файл с данными для вставки в таблицу
                CreateFile(dt, _sep);
                //встявляем данные в таблицу SQL
                InsertData(dt.TableName, _sep);
            }

            dt.Dispose();
        }


        /// <summary>
        /// Процедура создаёт файл .csv с данными из таблицы dt
        /// </summary>
        /// <param name="dt">Таблица с данными</param>
        /// <param name="Sep">Расделитель колонок</param>
        private void CreateFile(DataTable dt, char Sep)
        {
            // получаем каталог для создания файла
            string path = Directory.GetCurrentDirectory();

            path +=  "\\Temp\\";//добавляем котолог Temp  "\\\\" + Environment.MachineName + "\\" + 

            //path = path.Replace(':', '$');

            if(Directory.Exists(path)==false)//если каталог отсутствует
            {
                //создаем каталог
                Directory.CreateDirectory(path);
            }

            FileName = path + dt.TableName +".csv";//создаем имя файла    [\\DESKTOP-6Q4Q1E5\c$\TEMP]

            // запись в файл
            using (StreamWriter sw = new StreamWriter(FileName, false, Encoding.Default))
            {
                string str= ColumnsName(dt, Sep);
                sw.WriteLine(str);//записываем название колонок
            }

            using (StreamWriter sw=new StreamWriter(FileName, true, Encoding.Default))
            {
                foreach (DataRow dr in dt.Rows)//записываем все строки по порядку
                {
                    sw.WriteLine(CreateStringRow(dr, Sep));
                }
            }

        }

        private string CreateStringRow(DataRow dr, char Sep)
        {
            string ins=null; 
            string ColValue;
            int x = 0;
            int count = dr.Table.Columns.Count;
            ColValue = null;

            foreach (DataColumn dc in dr.Table.Columns)
            {
                string tmp;
                if (dc.DataType.Name=="Double")
                {
                    tmp = dr[dc].ToString().Trim().Replace(",", ".");
                }
                else
                {
                    tmp = dr[dc].ToString().Trim().Replace(Sep, ';');
                    byte b1 = 13;
                    byte b2 = 10;
                    tmp = tmp.Replace(Convert.ToChar(b1).ToString() + Convert.ToChar(b2).ToString(), " ");
                }

                ColValue += tmp;
                x++;
                if(x<count)
                {
                    ColValue += Sep;
                }
            }

            //ColValue += "\n";
            ins += ColValue;

            return ins;
        }

        private string ColumnsName(DataTable dt, char Sep)
        {
            string ret = null;

            int x = 0;
            int count = dt.Columns.Count;
            foreach(DataColumn dc in dt.Columns)
            {
                ret += dc.ColumnName;
                x++;
                if(x<count)
                {
                    ret += Sep;
                }
            }
            //ret += "\n";
            return ret;
        }

        private void InsertData(string NameTable, char Sep)
        {
            SqlDataReader r;

            using (SqlConnection conn = new SqlConnection(conSQL))
            {

                conn.Open();
                string tmp = string.Format("BULK INSERT {0} FROM '{1}' WITH (FIRSTROW = 2, FIELDTERMINATOR = '{2}', ROWTERMINATOR = '\n', BATCHSIZE = 250000,    MAXERRORS = 2, CODEPAGE = 1251);", NameTable, FileName, Sep);
                SqlCommand cmd = new SqlCommand(tmp, conn);
                r = cmd.ExecuteReader();
                conn.Close();
            }
        }

        private void CreateTable(DataTable dt)
        {
            SqlDataReader r;

            using (SqlConnection conn = new SqlConnection(conSQL))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(CreateStringSQL(dt), conn);
                r = cmd.ExecuteReader();
                conn.Close();
            }
        }

        private void DeleteTable(DataTable dt)
        {
            SqlDataReader r;
            using(SqlConnection conn=new SqlConnection(conSQL))
            {
                conn.Open();
                SqlCommand del = new SqlCommand("DROP TABLE ["+dt.TableName+"]", conn);//удаляем таблицу
                r = del.ExecuteReader();
                conn.Close();
            }
        }

        private string CreateStringSQL(DataTable dt)
        {
            string sql="CREATE TABLE [dbo].";
            sql += "[" + dt.TableName + "] (";
            int x = 0;
            int count = dt.Columns.Count;
            foreach(DataColumn dc in dt.Columns)
            {
                string type = null;
                switch (dc.DataType.Name)
                {
                    case "String":
                        int len = (dc.MaxLength / 2)+2;
                        type = "NVARCHAR ("+len.ToString()+")";
                        break;
                    case "Double":
                        type = "FLOAT";
                        break;
                    case "DateTime":
                        type = "DATETIME";
                        break;
                }

                sql += "[" + dc.ColumnName + "] " + type + " NULL";
                x++;
                if(x<count)
                {
                    sql += ", ";
                }
            }
            sql += ")";
            return sql;
        }


    }
}
