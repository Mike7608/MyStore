﻿namespace MyShop.Setting
{
    partial class frmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelControl = new System.Windows.Forms.Panel();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnApply = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageSQLserver = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.controlPeriod1 = new Periods.ControlPeriod();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnTestConnectionServer = new System.Windows.Forms.Button();
            this.txtInfoServer = new System.Windows.Forms.TextBox();
            this.txtConnectionString = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage1C = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnVFPtestConnection = new System.Windows.Forms.Button();
            this.txtInfoDBFconnectionString = new System.Windows.Forms.TextBox();
            this.txtDBFconnectionString = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabCurrency = new System.Windows.Forms.TabPage();
            this.groupValuta = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboValutaCol3 = new System.Windows.Forms.ComboBox();
            this.comboValutaCol2 = new System.Windows.Forms.ComboBox();
            this.comboValutaCol1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkDisplayValuta = new System.Windows.Forms.CheckBox();
            this.tabPriceTag = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboFormatPriceTag = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtPathSaveData1C = new System.Windows.Forms.TextBox();
            this.btnSelectFolderFor1C = new System.Windows.Forms.Button();
            this.txtKursPrescheta = new MyShop.NumberBox();
            this.panelControl.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageSQLserver.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage1C.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabCurrency.SuspendLayout();
            this.groupValuta.SuspendLayout();
            this.tabPriceTag.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl
            // 
            this.panelControl.Controls.Add(this.btnOK);
            this.panelControl.Controls.Add(this.btnCancel);
            this.panelControl.Controls.Add(this.btnApply);
            this.panelControl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl.Location = new System.Drawing.Point(0, 492);
            this.panelControl.Name = "panelControl";
            this.panelControl.Size = new System.Drawing.Size(470, 57);
            this.panelControl.TabIndex = 0;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(203, 12);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(83, 30);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "&OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(292, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(83, 30);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Отме&на";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnApply
            // 
            this.btnApply.Enabled = false;
            this.btnApply.Location = new System.Drawing.Point(381, 12);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(83, 30);
            this.btnApply.TabIndex = 0;
            this.btnApply.Text = "&Применить";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageSQLserver);
            this.tabControl1.Controls.Add(this.tabPage1C);
            this.tabControl1.Controls.Add(this.tabCurrency);
            this.tabControl1.Controls.Add(this.tabPriceTag);
            this.tabControl1.Location = new System.Drawing.Point(7, 7);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(457, 482);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPageSQLserver
            // 
            this.tabPageSQLserver.Controls.Add(this.groupBox3);
            this.tabPageSQLserver.Controls.Add(this.groupBox1);
            this.tabPageSQLserver.Location = new System.Drawing.Point(4, 22);
            this.tabPageSQLserver.Name = "tabPageSQLserver";
            this.tabPageSQLserver.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSQLserver.Size = new System.Drawing.Size(449, 456);
            this.tabPageSQLserver.TabIndex = 0;
            this.tabPageSQLserver.Text = "SQL Server";
            this.tabPageSQLserver.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.controlPeriod1);
            this.groupBox3.Location = new System.Drawing.Point(17, 206);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(414, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Рабочий период";
            // 
            // controlPeriod1
            // 
            this.controlPeriod1.BackColor = System.Drawing.SystemColors.Control;
            this.controlPeriod1.ButtonBackColor = System.Drawing.Color.LightGray;
            this.controlPeriod1.ButtonBorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.controlPeriod1.ButtonForeColor = System.Drawing.Color.Black;
            this.controlPeriod1.CheckedBackColor = System.Drawing.SystemColors.Highlight;
            this.controlPeriod1.ControlBackColor = System.Drawing.SystemColors.Control;
            this.controlPeriod1.DateEnd = new System.DateTime(2021, 3, 31, 23, 59, 59, 0);
            this.controlPeriod1.DateStart = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            this.controlPeriod1.DefaultPeriodOnly = true;
            this.controlPeriod1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.controlPeriod1.Location = new System.Drawing.Point(24, 19);
            this.controlPeriod1.Name = "controlPeriod1";
            this.controlPeriod1.PeriodDefault = Periods.ControlPeriod.DefaultPeriod.Quarter;
            this.controlPeriod1.Size = new System.Drawing.Size(360, 66);
            this.controlPeriod1.TabIndex = 1;
            this.controlPeriod1.TextBackColor = System.Drawing.Color.LightGray;
            this.controlPeriod1.TextFont = new System.Drawing.Font("Segoe UI", 10F);
            this.controlPeriod1.TextForeColor = System.Drawing.Color.Black;
            this.controlPeriod1.ChangPeriod += new Periods.ControlPeriod.PeriodHandler(this.controlPeriod1_ChangPeriod);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnTestConnectionServer);
            this.groupBox1.Controls.Add(this.txtInfoServer);
            this.groupBox1.Controls.Add(this.txtConnectionString);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(17, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(414, 179);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Подключение к серверу";
            // 
            // btnTestConnectionServer
            // 
            this.btnTestConnectionServer.Location = new System.Drawing.Point(234, 137);
            this.btnTestConnectionServer.Name = "btnTestConnectionServer";
            this.btnTestConnectionServer.Size = new System.Drawing.Size(157, 23);
            this.btnTestConnectionServer.TabIndex = 6;
            this.btnTestConnectionServer.Text = "Проверить подключение";
            this.btnTestConnectionServer.UseVisualStyleBackColor = true;
            this.btnTestConnectionServer.Click += new System.EventHandler(this.btnTestConnectionServer_Click);
            // 
            // txtInfoServer
            // 
            this.txtInfoServer.BackColor = System.Drawing.SystemColors.Control;
            this.txtInfoServer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInfoServer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInfoServer.Location = new System.Drawing.Point(24, 73);
            this.txtInfoServer.Multiline = true;
            this.txtInfoServer.Name = "txtInfoServer";
            this.txtInfoServer.ReadOnly = true;
            this.txtInfoServer.Size = new System.Drawing.Size(367, 47);
            this.txtInfoServer.TabIndex = 5;
            // 
            // txtConnectionString
            // 
            this.txtConnectionString.Location = new System.Drawing.Point(24, 40);
            this.txtConnectionString.Name = "txtConnectionString";
            this.txtConnectionString.Size = new System.Drawing.Size(367, 20);
            this.txtConnectionString.TabIndex = 3;
            this.txtConnectionString.TextChanged += new System.EventHandler(this.txtConnectionString_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Строка подключения:";
            // 
            // tabPage1C
            // 
            this.tabPage1C.Controls.Add(this.groupBox5);
            this.tabPage1C.Controls.Add(this.groupBox2);
            this.tabPage1C.Location = new System.Drawing.Point(4, 22);
            this.tabPage1C.Name = "tabPage1C";
            this.tabPage1C.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1C.Size = new System.Drawing.Size(449, 456);
            this.tabPage1C.TabIndex = 1;
            this.tabPage1C.Text = "1C бухгалтерия v7.7";
            this.tabPage1C.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnVFPtestConnection);
            this.groupBox2.Controls.Add(this.txtInfoDBFconnectionString);
            this.groupBox2.Controls.Add(this.txtDBFconnectionString);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(19, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(413, 182);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Подключение к базе";
            // 
            // btnVFPtestConnection
            // 
            this.btnVFPtestConnection.Location = new System.Drawing.Point(233, 138);
            this.btnVFPtestConnection.Name = "btnVFPtestConnection";
            this.btnVFPtestConnection.Size = new System.Drawing.Size(160, 23);
            this.btnVFPtestConnection.TabIndex = 6;
            this.btnVFPtestConnection.Text = "Проверить подключение";
            this.btnVFPtestConnection.UseVisualStyleBackColor = true;
            this.btnVFPtestConnection.Click += new System.EventHandler(this.btnVFPtestConnection_Click);
            // 
            // txtInfoDBFconnectionString
            // 
            this.txtInfoDBFconnectionString.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInfoDBFconnectionString.Location = new System.Drawing.Point(21, 69);
            this.txtInfoDBFconnectionString.Multiline = true;
            this.txtInfoDBFconnectionString.Name = "txtInfoDBFconnectionString";
            this.txtInfoDBFconnectionString.ReadOnly = true;
            this.txtInfoDBFconnectionString.Size = new System.Drawing.Size(372, 52);
            this.txtInfoDBFconnectionString.TabIndex = 5;
            // 
            // txtDBFconnectionString
            // 
            this.txtDBFconnectionString.Location = new System.Drawing.Point(21, 39);
            this.txtDBFconnectionString.Name = "txtDBFconnectionString";
            this.txtDBFconnectionString.Size = new System.Drawing.Size(372, 20);
            this.txtDBFconnectionString.TabIndex = 4;
            this.txtDBFconnectionString.TextChanged += new System.EventHandler(this.txtDBFconnectionString_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Строка подключения:";
            // 
            // tabCurrency
            // 
            this.tabCurrency.Controls.Add(this.groupValuta);
            this.tabCurrency.Controls.Add(this.checkDisplayValuta);
            this.tabCurrency.Location = new System.Drawing.Point(4, 22);
            this.tabCurrency.Name = "tabCurrency";
            this.tabCurrency.Size = new System.Drawing.Size(449, 456);
            this.tabCurrency.TabIndex = 2;
            this.tabCurrency.Text = "Курсы валют";
            this.tabCurrency.UseVisualStyleBackColor = true;
            // 
            // groupValuta
            // 
            this.groupValuta.Controls.Add(this.txtKursPrescheta);
            this.groupValuta.Controls.Add(this.label6);
            this.groupValuta.Controls.Add(this.comboValutaCol3);
            this.groupValuta.Controls.Add(this.comboValutaCol2);
            this.groupValuta.Controls.Add(this.comboValutaCol1);
            this.groupValuta.Controls.Add(this.label5);
            this.groupValuta.Controls.Add(this.label4);
            this.groupValuta.Controls.Add(this.label3);
            this.groupValuta.Enabled = false;
            this.groupValuta.Location = new System.Drawing.Point(16, 50);
            this.groupValuta.Name = "groupValuta";
            this.groupValuta.Size = new System.Drawing.Size(416, 140);
            this.groupValuta.TabIndex = 1;
            this.groupValuta.TabStop = false;
            this.groupValuta.Text = "Какие валюты показывать";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(84, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Курс пересчёта:";
            // 
            // comboValutaCol3
            // 
            this.comboValutaCol3.FormattingEnabled = true;
            this.comboValutaCol3.Location = new System.Drawing.Point(276, 46);
            this.comboValutaCol3.Name = "comboValutaCol3";
            this.comboValutaCol3.Size = new System.Drawing.Size(121, 21);
            this.comboValutaCol3.TabIndex = 1;
            this.comboValutaCol3.SelectedIndexChanged += new System.EventHandler(this.comboValutaCol3_SelectedIndexChanged);
            // 
            // comboValutaCol2
            // 
            this.comboValutaCol2.FormattingEnabled = true;
            this.comboValutaCol2.Location = new System.Drawing.Point(149, 46);
            this.comboValutaCol2.Name = "comboValutaCol2";
            this.comboValutaCol2.Size = new System.Drawing.Size(121, 21);
            this.comboValutaCol2.TabIndex = 1;
            this.comboValutaCol2.SelectedIndexChanged += new System.EventHandler(this.comboValutaCol2_SelectedIndexChanged);
            // 
            // comboValutaCol1
            // 
            this.comboValutaCol1.FormattingEnabled = true;
            this.comboValutaCol1.Location = new System.Drawing.Point(22, 46);
            this.comboValutaCol1.Name = "comboValutaCol1";
            this.comboValutaCol1.Size = new System.Drawing.Size(121, 21);
            this.comboValutaCol1.TabIndex = 1;
            this.comboValutaCol1.SelectedIndexChanged += new System.EventHandler(this.comboValutaCol1_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(308, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Колонка 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(176, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Колонка 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Колонка 1";
            // 
            // checkDisplayValuta
            // 
            this.checkDisplayValuta.AutoSize = true;
            this.checkDisplayValuta.Location = new System.Drawing.Point(29, 27);
            this.checkDisplayValuta.Name = "checkDisplayValuta";
            this.checkDisplayValuta.Size = new System.Drawing.Size(284, 17);
            this.checkDisplayValuta.TabIndex = 0;
            this.checkDisplayValuta.Text = "Показывать курсы валют на фоне главной формы";
            this.checkDisplayValuta.UseVisualStyleBackColor = true;
            this.checkDisplayValuta.CheckedChanged += new System.EventHandler(this.checkDisplayValuta_CheckedChanged);
            // 
            // tabPriceTag
            // 
            this.tabPriceTag.Controls.Add(this.groupBox4);
            this.tabPriceTag.Location = new System.Drawing.Point(4, 22);
            this.tabPriceTag.Name = "tabPriceTag";
            this.tabPriceTag.Size = new System.Drawing.Size(449, 456);
            this.tabPriceTag.TabIndex = 3;
            this.tabPriceTag.Text = "Ценник";
            this.tabPriceTag.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboFormatPriceTag);
            this.groupBox4.Location = new System.Drawing.Point(14, 15);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(419, 83);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Формат ценника по умолчанию";
            // 
            // comboFormatPriceTag
            // 
            this.comboFormatPriceTag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFormatPriceTag.FormattingEnabled = true;
            this.comboFormatPriceTag.Location = new System.Drawing.Point(22, 31);
            this.comboFormatPriceTag.Name = "comboFormatPriceTag";
            this.comboFormatPriceTag.Size = new System.Drawing.Size(372, 21);
            this.comboFormatPriceTag.TabIndex = 0;
            this.comboFormatPriceTag.TextChanged += new System.EventHandler(this.comboFormatPriceTag_TextChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnSelectFolderFor1C);
            this.groupBox5.Controls.Add(this.txtPathSaveData1C);
            this.groupBox5.Location = new System.Drawing.Point(19, 208);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(413, 61);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Папка для выгрузки данных";
            // 
            // txtPathSaveData1C
            // 
            this.txtPathSaveData1C.Location = new System.Drawing.Point(21, 24);
            this.txtPathSaveData1C.Name = "txtPathSaveData1C";
            this.txtPathSaveData1C.Size = new System.Drawing.Size(353, 20);
            this.txtPathSaveData1C.TabIndex = 0;
            this.txtPathSaveData1C.TextChanged += new System.EventHandler(this.txtPathSaveData1C_TextChanged);
            // 
            // btnSelectFolderFor1C
            // 
            this.btnSelectFolderFor1C.Location = new System.Drawing.Point(374, 23);
            this.btnSelectFolderFor1C.Name = "btnSelectFolderFor1C";
            this.btnSelectFolderFor1C.Size = new System.Drawing.Size(25, 22);
            this.btnSelectFolderFor1C.TabIndex = 1;
            this.btnSelectFolderFor1C.Text = "...";
            this.btnSelectFolderFor1C.UseVisualStyleBackColor = true;
            this.btnSelectFolderFor1C.Click += new System.EventHandler(this.btnSelectFolderFor1C_Click);
            // 
            // txtKursPrescheta
            // 
            this.txtKursPrescheta.Location = new System.Drawing.Point(176, 94);
            this.txtKursPrescheta.Name = "txtKursPrescheta";
            this.txtKursPrescheta.Size = new System.Drawing.Size(100, 20);
            this.txtKursPrescheta.TabIndex = 4;
            this.txtKursPrescheta.Text = "0";
            this.txtKursPrescheta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtKursPrescheta.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            // 
            // frmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 549);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panelControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Настройки";
            this.Load += new System.EventHandler(this.frmSetting_Load);
            this.panelControl.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPageSQLserver.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1C.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabCurrency.ResumeLayout(false);
            this.tabCurrency.PerformLayout();
            this.groupValuta.ResumeLayout(false);
            this.groupValuta.PerformLayout();
            this.tabPriceTag.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelControl;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageSQLserver;
        private System.Windows.Forms.TabPage tabPage1C;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtConnectionString;
        private System.Windows.Forms.TextBox txtInfoServer;
        private System.Windows.Forms.Button btnTestConnectionServer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtInfoDBFconnectionString;
        private System.Windows.Forms.TextBox txtDBFconnectionString;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnVFPtestConnection;
        private System.Windows.Forms.TabPage tabCurrency;
        private System.Windows.Forms.GroupBox groupValuta;
        private System.Windows.Forms.ComboBox comboValutaCol3;
        private System.Windows.Forms.ComboBox comboValutaCol2;
        private System.Windows.Forms.ComboBox comboValutaCol1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkDisplayValuta;
        private System.Windows.Forms.GroupBox groupBox3;
        private Periods.ControlPeriod controlPeriod1;
        private System.Windows.Forms.TabPage tabPriceTag;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comboFormatPriceTag;
        private System.Windows.Forms.Label label6;
        private NumberBox txtKursPrescheta;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnSelectFolderFor1C;
        private System.Windows.Forms.TextBox txtPathSaveData1C;
    }
}