﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.Setting
{
    public partial class frmSetting : Form
    {
        bool appSet;
        Settings set = new Settings();
        delegate void SettingHandler();
        event SettingHandler ChangeSetting;
        private DateTime[] rPeriod;
        PriceTag.ListPriceTag list = new PriceTag.ListPriceTag(Application.StartupPath, "*.ptag");

        public frmSetting()
        {
            InitializeComponent();

            rPeriod = set.WorkPeriod;
            controlPeriod1.DateStart = rPeriod[0];
            controlPeriod1.DateEnd = rPeriod[1];

            ComboPriceTagFillData();//заполняем список комбобокса наименованиями ценников
        }

        private void FrmSetting_ChangeSetting()
        {
            btnApply.Enabled = true;
        }

        private void frmSetting_Load(object sender, EventArgs e)
        {
            txtConnectionString.Text = set.SQLconnectionString;
            txtInfoServer.Text = txtConnectionString.Text;
            txtDBFconnectionString.Text = set.DBFconnectionString;
            txtInfoDBFconnectionString.Text = txtDBFconnectionString.Text;
            appSet = true;
            checkDisplayValuta.Checked = set.DisplayCurrency;
            txtKursPrescheta.Value = (decimal) set.KursPerescheta;
            txtPathSaveData1C.Text = set.PathSaveDataFor1C;

            ChangeSetting += FrmSetting_ChangeSetting;

            string[] val = set.TypsDisplayCurrency.Split(',');
            comboValutaCol1.Text = val[0];
            comboValutaCol2.Text = val[1];
            comboValutaCol3.Text = val[2];

            //заполняем ComboBox-ы названиями валют
            try
            {
                if (checkDisplayValuta.Checked)
                {
                    FillComboBox();
                }
            }
            catch(Exception ex)
            {
                Cursor = Cursors.Default;
                checkDisplayValuta.Enabled = false;
                MessageBox.Show(ex.Message, "Курсы валют", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            btnApply.Enabled = false;

        }

        private void FillComboBox()
        {
            Cursor = Cursors.WaitCursor;
            Currency cur = new Currency();
            cur.GetRate(set.HttpCurrency);

            ComboBoxListCurrency(comboValutaCol1, cur.TableCurrency);
            ComboBoxListCurrency(comboValutaCol2, cur.TableCurrency);
            ComboBoxListCurrency(comboValutaCol3, cur.TableCurrency);
            Cursor = Cursors.Default;
        }

        private void ApplySetting()
        {

                set.SQLconnectionString = txtConnectionString.Text;
                txtInfoServer.Text = txtConnectionString.Text;
                Global.SqlConnectionString = txtConnectionString.Text;

                set.DBFconnectionString = txtDBFconnectionString.Text;
                txtInfoDBFconnectionString.Text = txtDBFconnectionString.Text;

                appSet = true;

                //включить или выключить отображение курса валют
                set.DisplayCurrency = checkDisplayValuta.Checked;
                if(checkDisplayValuta.Checked==true)
                {
                    string val = comboValutaCol1.Text.Substring(0, 3) + "," + comboValutaCol2.Text.Substring(0, 3) + "," + comboValutaCol3.Text.Substring(0, 3);
                    set.TypsDisplayCurrency = val;


                }

                if(rPeriod[0]!=controlPeriod1.DateStart & rPeriod[1] != controlPeriod1.DateEnd)
                {
                    DateTime[] d = new DateTime[2];
                    d[0] = controlPeriod1.DateStart;
                    d[1] = controlPeriod1.DateEnd;
                    set.WorkPeriod = d;
                    MessageBox.Show("Изменился период. Проведите импорт данных!");
                }

            if(list.ListTag!=null | list.ListTag.Count > 0)
            {
                int index = 0;

                foreach (PriceTag.Tag t in list.ListTag)
                {
                    string s = t.Name;
                    if (s == comboFormatPriceTag.Text)
                    {
                        set.PriceTagDefault = index;
                    }
                    index++;
                }
            }

            if (txtKursPrescheta.Text.Length > 0)
            {
                float k = Convert.ToSingle(txtKursPrescheta.Value);
                set.KursPerescheta = k;
                Global.KursPerescheta = k;
            }


            set.Save();
        }
        private void btnApply_Click(object sender, EventArgs e)
        {
            ApplySetting();
            btnApply.Enabled = false;
        }

        private void btnTestConnectionServer_Click(object sender, EventArgs e)
        {
            TestConnection(TestServerConnection());
        }


        private void TestConnection(bool val)
        {

            string Caption = "Test connection";
            if(val)
            {
                MessageBox.Show("Тестовое соединение выполнено успешно", Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Тестовое соединение не установлено", Caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool TestServerConnection()
        {
            Cursor = Cursors.WaitCursor;
            bool TrueConn;

            SqlConnection conn=null;

            try
            {
                conn=new SqlConnection(txtConnectionString.Text);
                conn.Open();
                conn.Close();
                TrueConn = true;
            }
            catch(Exception ex)
            {
                if (conn != null) { conn.Dispose(); }

                TrueConn = false;
                MessageBox.Show(ex.Message);
            }

            Cursor = Cursors.Default;

            return TrueConn;
        }

        private void btnVFPtestConnection_Click(object sender, EventArgs e)
        {
            //Provider=VFPOLEDB.1;Data Source="e:\DB\BKB NDS\"
            //Driver={Microsoft dBASE Driver (*.dbf)};DriverID=277;Dbq="e:\DB\BKB NDS"
            try
            {
                ConnectionDBinfo cinf = new ConnectionDBinfo();
                TestConnection(cinf.Test1CBaseConncetion(txtDBFconnectionString.Text));
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "TestDBFconnection", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(appSet==false)
            {
                if(MessageBox.Show("Сохранить изменения?","Настройки", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
                {
                    ApplySetting();
                }
            }
            
            this.Close();
        }

        private void txtConnectionString_TextChanged(object sender, EventArgs e)
        {
            EnableChangeSetting();

        }

        private void txtDBFconnectionString_TextChanged(object sender, EventArgs e)
        {
            EnableChangeSetting();
        }

        private void checkDisplayValuta_CheckedChanged(object sender, EventArgs e)
        {
            if(checkDisplayValuta.Checked)
            {
                groupValuta.Enabled = true;
                Global.mainForm.обновитькурсыВалютToolStripMenuItem.Enabled = true;
                FillComboBox();

            }
            else
            {
                groupValuta.Enabled = false;
                Global.mainForm.обновитькурсыВалютToolStripMenuItem.Enabled = false;
                
            }

            //Global.mainForm.Refresh();

            EnableChangeSetting();
        }

        private void ComboBoxListCurrency(ComboBox box, Money[] Table)
        { 
            foreach(Money m in Table)
            {
                string str = m.Abbreviation + " - " + m.Name;
                box.Items.Add(str);
            }
        }

        private void comboValutaCol1_SelectedIndexChanged(object sender, EventArgs e)
        {
            appSet = false;
            if (ChangeSetting != null & checkDisplayValuta.Checked==true)
            {
                ChangeSetting();
            }
        }

        private void comboValutaCol2_SelectedIndexChanged(object sender, EventArgs e)
        {
            appSet = false;
            if (ChangeSetting != null & checkDisplayValuta.Checked == true)
            {
                ChangeSetting();
            }
        }

        private void comboValutaCol3_SelectedIndexChanged(object sender, EventArgs e)
        {
            appSet = false;
            if (ChangeSetting != null & checkDisplayValuta.Checked == true)
            {
                ChangeSetting();
            }
        }



        private void controlPeriod1_ChangPeriod()
        {
            btnApply.Enabled = true;
        }


        private void ComboPriceTagFillData()
        {
                if (list.ListTag.Count > 0)
                {
                    foreach (PriceTag.Tag t in list.ListTag)
                    {
                        comboFormatPriceTag.Items.Add(t.Name);
                    }
                }

                try
                {
                    comboFormatPriceTag.Text = list.ListTag[set.PriceTagDefault].Name;
                }
                catch
                {
                    comboFormatPriceTag.Text = "нет данных";
                }
        }



        private void comboFormatPriceTag_TextChanged(object sender, EventArgs e)
        {
            EnableChangeSetting();
        }

        private void txtKursPrescheta_TextChanged(object sender, EventArgs e)
        {
            btnApply.Enabled = true;
        }

        private void btnSelectFolderFor1C_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog()== DialogResult.OK)
            {
                txtPathSaveData1C.Text = fbd.SelectedPath;
                set.PathSaveDataFor1C = txtPathSaveData1C.Text;
            }
        }

        private void txtPathSaveData1C_TextChanged(object sender, EventArgs e)
        {
            EnableChangeSetting();
        }

        private void EnableChangeSetting()
        {
            appSet = false;
            if (ChangeSetting != null)
            {
                ChangeSetting();
            }
        }
    }
}
