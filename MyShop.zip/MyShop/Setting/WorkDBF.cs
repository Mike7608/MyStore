﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkDBF
{
    class ReadDBF
    {
        private OdbcConnection Conn = null;
        private string _conn;

        public enum CodePage
        {
            DBF=866,
            WINDOWS=1251
        }

        public string ConnectionStringDBF
        {
            set { _conn = value; }
            get { return _conn; }
        }

        public DataTable Execute(string Command, string NameTable)
        {
            DataTable dt = null;
            if (Conn != null)
            {
                try
                {
                    Conn.ConnectionString = ConnectionStringDBF;
                    Conn.Open();
                    dt = new DataTable();
                    dt.TableName = "_"+ NameTable;
                    OdbcCommand oCmd = Conn.CreateCommand();
                    oCmd.CommandText = Command;
                    dt.Load(oCmd.ExecuteReader());
                    Conn.Close();

                    ConvertCP(dt);//конвертируем из 866 кодовой страницы в 1251 (windows)
                }
                catch (Exception e)
                {
                    throw new Exception("class ReadDBF\r\n" + e.Message);
                }
            }
            return dt;
        }


        /// <summary>
        /// Процедура конветрирует кодовою страницу в заданной таблице
        /// </summary>
        /// <param name="NameCol"></param>
        private void ConvertCP(DataTable dt)
        {
            try
            {
                int x, totalRow;
                totalRow = dt.Rows.Count;

                for (x = 0; x < totalRow; x++)
                {
                    DataRow dr;
                    dr = dt.Rows[x];
                    int cc = dt.Columns.Count;
                    for (int i = 0; i < cc; i++)
                    {
                        if (dr[i].GetType().Name == "String")
                        {
                            string ConvStr, str1;
                            str1 = dr[i].ToString();
                            ConvStr = ConvertCP(str1, CodePage.DBF, CodePage.WINDOWS);
                            dr[i] = ConvStr;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("class ReadDBF\r\n"+ e.Message);
            }

        }

        /// <summary>
        /// Функция конвертирует строку из 866 кодировки в 1251
        /// </summary>
        /// <param name="Str"></param>
        /// <param name="CodePageIn"></param>
        /// <param name="CodePageOut"></param>
        /// <returns></returns>
        public string ConvertCP(string Str, CodePage cpDBF, CodePage cpWindows)
        {
            Encoding scrCP = Encoding.GetEncoding(cpDBF.GetHashCode());
            Encoding dstCP = Encoding.GetEncoding(cpWindows.GetHashCode());
            byte[] srcByte = scrCP.GetBytes(Str);
            string dstString = dstCP.GetString(srcByte);
            return dstString;
        }

        public DataTable GetAll(string NameTable)
        {
            return Execute("SELECT * FROM " + NameTable, NameTable);
        }

        public ReadDBF()
        {
            _conn = "Driver={Microsoft dBASE Driver (*.dbf)};DriverID=277;Collate=Machine;NULL=NO;DELETED=NO;Exclusive=No;SourceType=DBF;BACKGROUNDFETCH=NO;Dbq=";

            this.Conn = new OdbcConnection();


            //Conn.ConnectionString = @"Driver={Microsoft dBase  Driver (*.dbf)};" +
            //       "SourceType=DBF;Exclusive=No;" +
            //       "Collate=Machine;NULL=NO;DELETED=NO;" +
            //       "BACKGROUNDFETCH=NO;";
        }

    }
}
