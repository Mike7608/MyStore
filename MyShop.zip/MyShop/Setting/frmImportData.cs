﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyShop.Setting
{
    public partial class frmImportData : Form
    {
        //public frmMain frmMain;
        Settings set = new Settings();

        public frmImportData()
        {
            InitializeComponent();


        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            if (checkFullClearTable.Checked)
            {
                SQLmodule sqlmod = new SQLmodule();
                sqlmod.ClearTable("ImportsTable");
                checkFullClearTable.Enabled = false;
            }

            btnExit.Enabled = false;
            btnImport.Enabled = false;
            btnImport.Refresh();

            ImportTable(set.ListTableDBF);

            LoadRemains();

            checkFullClearTable.Checked = false;
            checkFullClearTable.Enabled = true;
        }

        /// <summary>
        /// Процедура загрузки остатков товаров
        /// </summary>
        private void LoadRemains()//загружаем остатки
        {
            lblInfo.Text = "Получаем последние остатки товаров";
            Remains r = new Remains();
            r.Added += R_Added;
            r.NoAdded += R_NoAdded;
            r.LoadData();
            lblInfo.Text = "Последние остатки товаров получены";
            ControlCollection controlCollection = new ControlCollection(Global.mainForm);

        }

        private void R_NoAdded()
        {
            Global.mainForm.товарыToolStripMenuItem.Enabled = false;
            Global.mainForm.mnuCenniki.Enabled = false;
            Global.mainForm.mnuMagazin.Enabled = false;
        }

        private void R_Added()
        {
            Global.mainForm.товарыToolStripMenuItem.Enabled = true;
            Global.mainForm.mnuCenniki.Enabled = true;
            Global.mainForm.mnuMagazin.Enabled = true;
        }
        /// <summary>
        /// Процедура импорта данных (таблиц DBF) из 1С в SQLserver
        /// </summary>
        /// <param name="List"></param>
        private void ImportTable(string[] List)
        {
            ConnectionDBinfo cinf = new ConnectionDBinfo();
            if(cinf.Test1CBaseConncetion(set.DBFconnectionString))
            {
                pgb1.Value = 0;
                try
                {
                    Cursor = Cursors.WaitCursor;
                    ExportDBFtoSQL exp = new ExportDBFtoSQL(set.DBFconnectionString, set.SQLconnectionString);
                    exp.Separator = '|';
                    pgb1.Maximum = List.Length;

                    CompareDbfSql compare = new CompareDbfSql();

                    foreach (string tmp in List)
                    {
                        var c=compare.Compare(tmp);
                            lblInfo.Text = "Импорт таблицы данных: " + tmp;
                            Refresh();
                        switch(c)
                        {
                            case CompareDbfSql.CompareValue.No:
                                exp.Export(tmp);
                                pgb1.Value++;
                                //pgb1.Refresh();
                                Refresh();
                                compare.Update();
                                break;
                            case CompareDbfSql.CompareValue.NoRecords:
                                exp.Export(tmp);
                                pgb1.Value++;
                                //pgb1.Refresh();
                                Refresh();
                                compare.Insert();
                                break;
                            case CompareDbfSql.CompareValue.Yes:
                                pgb1.Value++;
                                //pgb1.Refresh();
                                Refresh();
                                break;
                            case CompareDbfSql.CompareValue.NoFile:
                                throw new Exception("Файл не найден или недоступен. Проверьте правильность пути к базе 1С бухгалтерия");
                                //break;
                        }
                    }

                    lblInfo.Text = "Импорт данных выполнен успешно";
                    Refresh();
                }
                catch( Exception e)
                {
                    MessageBox.Show(e.Message);
                }
                finally
                {
                    btnImport.Enabled = true;
                    Cursor = Cursors.Default;
                }
            }
            else
            {
                MessageBox.Show("Отсутствует связь с базой данных 1С бухгалтерия", "Импорт", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            btnExit.Enabled = true;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
